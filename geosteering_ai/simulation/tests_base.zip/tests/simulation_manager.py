# -*- coding: utf-8 -*-
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║  geosteering_ai/simulation/tests/simulation_manager.py                    ║
# ║  ---------------------------------------------------------------------    ║
# ║  Projeto     : Geosteering AI v2.0                                        ║
# ║  Subsistema  : Simulation Manager — GUI PyQt (entrypoint)                 ║
# ║  Autor       : Daniel Leal                                                ║
# ║  Criação     : 2026-04-18                                                 ║
# ║  Status      : Produção                                                   ║
# ║  Framework   : PyQt6 (fallback PySide6/PyQt5) + matplotlib                ║
# ║  Dependências: numpy, scipy, matplotlib, geosteering_ai.simulation        ║
# ║  ---------------------------------------------------------------------    ║
# ║  FINALIDADE                                                               ║
# ║    Janela principal do aplicativo Simulation Manager. Expõe 4 abas:      ║
# ║    (1) Parâmetros — configuração da simulação e geração de perfis;      ║
# ║    (2) Simulador  — backend, workers sandbox, execução;                 ║
# ║    (3) Benchmark  — Config A/B + experimento 30k;                       ║
# ║    (4) Resultados — plots interativos (EM, ρ, geosinais) + export.      ║
# ║                                                                           ║
# ║  EXECUÇÃO                                                                 ║
# ║    python -m geosteering_ai.simulation.tests.simulation_manager          ║
# ║                                                                           ║
# ║  RESPONSABILIDADES DO MÓDULO                                              ║
# ║    • MainWindow + 4 tabs com signals/slots interligados                  ║
# ║    • Coleta dos parâmetros dos widgets → SimRequest/BenchmarkSettings    ║
# ║    • Despacho das simulações em SimulationThread / BenchmarkThread       ║
# ║    • Atualização de progress bar + log + throughput                      ║
# ║    • Gate de permissão (desabilita botões durante execução)              ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
"""Simulation Manager — entrypoint GUI PyQt.

Programa executável único que agrega todas as funcionalidades descritas
no plano do Simulation Manager. Orquestra os módulos internos
``sm_qt_compat``, ``sm_model_gen``, ``sm_workers``, ``sm_benchmark``,
``sm_plots`` e ``sm_io``.

Example:
    Execução direta::

        $ python -m geosteering_ai.simulation.tests.simulation_manager

Note:
    Requer que pelo menos um binding Qt esteja instalado. Se ausente, o
    programa emite mensagem clara de instalação e termina com exit code 1.
"""
from __future__ import annotations

import os
import sys
from dataclasses import asdict
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

from .sm_qt_compat import (
    ALIGN_CENTER,
    QT_AVAILABLE,
    QT_BINDING,
    QT_IMPORT_ERROR,
    Qt,
    QtCore,
    QtGui,
    QtWidgets,
    Signal,
    check_qt_available,
)

# Se Qt não estiver disponível, abortamos imediatamente ao rodar `python -m ...`.
# Imports dos módulos pesados (matplotlib, numba via simulate_multi) ocorrem
# apenas quando Qt estiver disponível — evita ImportError cascading.
if QT_AVAILABLE:
    from .sm_benchmark import (
        CANONICAL_BENCHMARK_MODELS,
        BenchmarkSettings,
        BenchmarkThread,
        BenchRecord,
    )
    from .sm_io import compute_nmeds_per_angle, write_dat_from_tensor, write_out_file
    from .sm_model_gen import GENERATORS_AVAILABLE, GenConfig, generate_models
    from .sm_plots import (
        COMPONENT_NAMES,
        EMCanvas,
        plot_benchmark_compare,
        plot_em_profile,
        plot_geosignals,
        plot_resistivity_profile,
    )
    from .sm_workers import SimRequest, SimulationThread


# ──────────────────────────────────────────────────────────────────────────
# Helpers de UI
# ──────────────────────────────────────────────────────────────────────────


def _qline(default: str = "", placeholder: str = "") -> "QtWidgets.QLineEdit":
    """Atalho para criar ``QLineEdit`` com placeholder + valor inicial."""
    w = QtWidgets.QLineEdit()
    w.setText(default)
    if placeholder:
        w.setPlaceholderText(placeholder)
    return w


def _spin_int(default: int, lo: int, hi: int, step: int = 1) -> "QtWidgets.QSpinBox":
    w = QtWidgets.QSpinBox()
    w.setRange(lo, hi)
    w.setSingleStep(step)
    w.setValue(default)
    return w


def _spin_float(
    default: float, lo: float, hi: float, step: float = 0.1, decimals: int = 3
) -> "QtWidgets.QDoubleSpinBox":
    w = QtWidgets.QDoubleSpinBox()
    w.setRange(lo, hi)
    w.setDecimals(decimals)
    w.setSingleStep(step)
    w.setValue(default)
    return w


def _parse_float_list(text: str, default: List[float]) -> List[float]:
    """Interpreta "1.0, 2.0, 3.0" → [1.0, 2.0, 3.0]; devolve default se vazio."""
    if not text or not text.strip():
        return list(default)
    try:
        return [float(t.strip()) for t in text.replace(";", ",").split(",") if t.strip()]
    except ValueError:
        return list(default)


# ══════════════════════════════════════════════════════════════════════════
# Aba 1 — Parâmetros
# ══════════════════════════════════════════════════════════════════════════


class ParametersTab(QtWidgets.QWidget):
    """Aba de parâmetros da simulação e geração estocástica.

    Coleta todos os parâmetros físicos (frequências, ângulos, TR, h1, tj,
    p_med) e de geração (n_modelos, ρₕ min/max, λ min/max, isotropia,
    filtro Hankel, gerador de números aleatórios).
    """

    def __init__(self, parent: Optional[QtWidgets.QWidget] = None) -> None:
        super().__init__(parent)
        # Nota: Layout principal é aplicado no final via ``outer = QVBoxLayout(self)``.
        # Não criar layout aqui — aplicar dois layouts ao mesmo widget dispara
        # warning "QLayout: Attempting to add QLayout to widget which already has a layout".

        # Grupo 1 — Geometria de aquisição
        grp_geom = QtWidgets.QGroupBox("Geometria da Ferramenta")
        geom_form = QtWidgets.QFormLayout(grp_geom)

        self.spin_nf = _spin_int(1, 1, 32)
        self.spin_nang = _spin_int(1, 1, 32)
        self.spin_ntr = _spin_int(1, 1, 32)
        self.edit_freqs = _qline("20000", "Ex.: 20000, 40000 (Hz)")
        self.edit_angles = _qline("0", "Ex.: 0, 30, 60 (graus)")
        self.edit_trs = _qline("1.0", "Ex.: 0.5, 1.0, 1.5 (m)")
        self.spin_h1 = _spin_float(10.0, 0.1, 500.0, 0.5, 3)
        self.spin_tj = _spin_float(120.0, 1.0, 5000.0, 1.0, 2)
        self.spin_pmed = _spin_float(0.2, 0.01, 10.0, 0.01, 3)

        geom_form.addRow("Nº de frequências (nf):", self.spin_nf)
        geom_form.addRow("Nº de ângulos (ntheta):", self.spin_nang)
        geom_form.addRow("Nº de pares TR:", self.spin_ntr)
        geom_form.addRow("Frequências (Hz):", self.edit_freqs)
        geom_form.addRow("Ângulos de dip (graus):", self.edit_angles)
        geom_form.addRow("Espaçamentos TR (m):", self.edit_trs)
        geom_form.addRow("Altura h1 (m):", self.spin_h1)
        geom_form.addRow("Janela tj (m):", self.spin_tj)
        geom_form.addRow("Passo p_med (m):", self.spin_pmed)

        # Grupo 2 — Geração estocástica
        grp_gen = QtWidgets.QGroupBox("Geração Estocástica de Modelos")
        gen_form = QtWidgets.QFormLayout(grp_gen)

        self.spin_nmodels = _spin_int(2000, 1, 10_000_000, 100)
        self.combo_generator = QtWidgets.QComboBox()
        for g in GENERATORS_AVAILABLE:
            self.combo_generator.addItem(g)
        self.combo_generator.setCurrentText("sobol")
        self.check_aniso = QtWidgets.QCheckBox("Perfil anisotrópico (TIV)")
        self.check_aniso.setChecked(True)
        self.spin_lambda_min = _spin_float(1.0, 1.0, 5.0, 0.05, 3)
        self.spin_lambda_max = _spin_float(1.4142, 1.0, 5.0, 0.05, 4)
        self.spin_rho_min = _spin_float(1.0, 0.001, 1e6, 1.0, 3)
        self.spin_rho_max = _spin_float(1800.0, 0.001, 1e6, 10.0, 3)
        self.combo_rho_distr = QtWidgets.QComboBox()
        self.combo_rho_distr.addItems(["loguni", "uniform"])
        self.spin_min_thick = _spin_float(0.5, 0.01, 100.0, 0.1, 2)
        self.spin_nlayers_min = _spin_int(3, 3, 200)
        self.spin_nlayers_max = _spin_int(31, 3, 200)
        self.spin_nlayers_fixed = _spin_int(0, 0, 200)  # 0 ⇒ None

        gen_form.addRow("Qtde de modelos:", self.spin_nmodels)
        gen_form.addRow("Gerador aleatório:", self.combo_generator)
        gen_form.addRow("", self.check_aniso)
        gen_form.addRow("λ mínimo (TIV):", self.spin_lambda_min)
        gen_form.addRow("λ máximo (TIV):", self.spin_lambda_max)
        gen_form.addRow("ρ mínimo (Ω·m):", self.spin_rho_min)
        gen_form.addRow("ρ máximo (Ω·m):", self.spin_rho_max)
        gen_form.addRow("Distribuição de ρₕ:", self.combo_rho_distr)
        gen_form.addRow("Espessura mínima (m):", self.spin_min_thick)
        gen_form.addRow("Nº camadas mínimo:", self.spin_nlayers_min)
        gen_form.addRow("Nº camadas máximo:", self.spin_nlayers_max)
        gen_form.addRow("Nº camadas fixo (0=auto):", self.spin_nlayers_fixed)

        # Grupo 3 — Filtro Hankel
        grp_filt = QtWidgets.QGroupBox("Filtro Hankel")
        filt_form = QtWidgets.QFormLayout(grp_filt)
        self.combo_filter = QtWidgets.QComboBox()
        self.combo_filter.addItems(["werthmuller_201pt", "kong_61pt", "anderson_801pt"])
        filt_form.addRow("Filtro:", self.combo_filter)

        root = QtWidgets.QVBoxLayout()
        root.addWidget(grp_geom)
        root.addWidget(grp_gen)
        root.addWidget(grp_filt)
        root.addStretch(1)
        container = QtWidgets.QWidget()
        container.setLayout(root)
        scroll = QtWidgets.QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(container)

        outer = QtWidgets.QVBoxLayout(self)
        outer.addWidget(scroll)

    # API pública da aba
    def collect_freqs(self) -> List[float]:
        """Retorna a lista de frequências em Hz."""
        return _parse_float_list(self.edit_freqs.text(), [20000.0])[
            : self.spin_nf.value()
        ]

    def collect_angles(self) -> List[float]:
        return _parse_float_list(self.edit_angles.text(), [0.0])[: self.spin_nang.value()]

    def collect_trs(self) -> List[float]:
        return _parse_float_list(self.edit_trs.text(), [1.0])[: self.spin_ntr.value()]

    def build_gen_config(self) -> GenConfig:
        """Constrói ``GenConfig`` a partir dos widgets."""
        fixed = self.spin_nlayers_fixed.value()
        return GenConfig(
            total_depth=float(self.spin_tj.value()),
            n_layers_min=int(self.spin_nlayers_min.value()),
            n_layers_max=int(self.spin_nlayers_max.value()) + 1,
            n_layers_fixed=int(fixed) if fixed >= 3 else None,
            rho_h_min=float(self.spin_rho_min.value()),
            rho_h_max=float(self.spin_rho_max.value()),
            rho_h_distribution=self.combo_rho_distr.currentText(),
            anisotropic=bool(self.check_aniso.isChecked()),
            lambda_min=float(self.spin_lambda_min.value()),
            lambda_max=float(self.spin_lambda_max.value()),
            min_thickness=float(self.spin_min_thick.value()),
            generator=self.combo_generator.currentText(),
        )


# ══════════════════════════════════════════════════════════════════════════
# Aba 2 — Simulador
# ══════════════════════════════════════════════════════════════════════════


class SimulatorTab(QtWidgets.QWidget):
    """Aba de escolha do backend, paralelismo e execução."""

    request_start = Signal()
    request_stop = Signal()

    def __init__(self, parent: Optional[QtWidgets.QWidget] = None) -> None:
        super().__init__(parent)
        ncpu = os.cpu_count() or 8

        grp_backend = QtWidgets.QGroupBox("Backend")
        backend_form = QtWidgets.QFormLayout(grp_backend)
        self.combo_backend = QtWidgets.QComboBox()
        self.combo_backend.addItems(["numba", "fortran"])
        self.edit_fortran_bin = _qline(
            str(Path.cwd() / "Fortran_Gerador" / "tatu.x"),
            "Caminho absoluto para tatu.x",
        )
        self.btn_browse_fortran = QtWidgets.QPushButton("…")
        self.btn_browse_fortran.setMaximumWidth(30)
        self.btn_browse_fortran.clicked.connect(self._browse_fortran)

        row_fort = QtWidgets.QHBoxLayout()
        row_fort.addWidget(self.edit_fortran_bin)
        row_fort.addWidget(self.btn_browse_fortran)
        wrap_fort = QtWidgets.QWidget()
        wrap_fort.setLayout(row_fort)
        backend_form.addRow("Simulador:", self.combo_backend)
        backend_form.addRow("Binário tatu.x:", wrap_fort)

        grp_par = QtWidgets.QGroupBox(
            "Paralelismo (Central Master-Plan, Parallel Execution)"
        )
        par_form = QtWidgets.QFormLayout(grp_par)
        self.spin_workers = _spin_int(max(1, ncpu // 4), 1, 256)
        self.spin_threads = _spin_int(4, 1, 256)
        self.lbl_ncpu = QtWidgets.QLabel(f"CPU cores disponíveis: {ncpu}")
        par_form.addRow("Nº de workers sandbox:", self.spin_workers)
        par_form.addRow("Nº de threads/worker:", self.spin_threads)
        par_form.addRow("", self.lbl_ncpu)

        grp_out = QtWidgets.QGroupBox("Saída")
        out_form = QtWidgets.QFormLayout(grp_out)
        self.edit_output_dir = _qline(str(Path.cwd() / "sm_output"), "Diretório de saída")
        self.btn_browse_out = QtWidgets.QPushButton("…")
        self.btn_browse_out.setMaximumWidth(30)
        self.btn_browse_out.clicked.connect(self._browse_out)
        self.check_save_dat = QtWidgets.QCheckBox("Salvar arquivo .dat (binário 22-col)")
        self.check_save_out = QtWidgets.QCheckBox("Salvar arquivo .out (metadados)")
        row_out = QtWidgets.QHBoxLayout()
        row_out.addWidget(self.edit_output_dir)
        row_out.addWidget(self.btn_browse_out)
        wrap_out = QtWidgets.QWidget()
        wrap_out.setLayout(row_out)
        out_form.addRow("Diretório:", wrap_out)
        out_form.addRow("", self.check_save_dat)
        out_form.addRow("", self.check_save_out)

        grp_exec = QtWidgets.QGroupBox("Execução")
        exec_row = QtWidgets.QHBoxLayout(grp_exec)
        self.btn_start = QtWidgets.QPushButton("▶ Iniciar Simulação")
        self.btn_stop = QtWidgets.QPushButton("■ Parar")
        self.btn_stop.setEnabled(False)
        self.progress = QtWidgets.QProgressBar()
        self.progress.setRange(0, 100)
        self.lbl_throughput = QtWidgets.QLabel("Throughput: — mod/h")
        exec_row.addWidget(self.btn_start)
        exec_row.addWidget(self.btn_stop)
        exec_row.addWidget(self.progress)
        exec_row.addWidget(self.lbl_throughput)

        self.btn_start.clicked.connect(self.request_start.emit)
        self.btn_stop.clicked.connect(self.request_stop.emit)

        self.log_view = QtWidgets.QPlainTextEdit()
        self.log_view.setReadOnly(True)
        self.log_view.setPlaceholderText("Log de execução aparecerá aqui.")
        self.log_view.setMaximumBlockCount(5000)

        root = QtWidgets.QVBoxLayout(self)
        root.addWidget(grp_backend)
        root.addWidget(grp_par)
        root.addWidget(grp_out)
        root.addWidget(grp_exec)
        root.addWidget(self.log_view, 1)

    def _browse_fortran(self) -> None:
        path, _ = QtWidgets.QFileDialog.getOpenFileName(
            self, "Selecionar binário tatu.x", str(Path.cwd())
        )
        if path:
            self.edit_fortran_bin.setText(path)

    def _browse_out(self) -> None:
        path = QtWidgets.QFileDialog.getExistingDirectory(
            self, "Selecionar diretório de saída", str(Path.cwd())
        )
        if path:
            self.edit_output_dir.setText(path)

    def append_log(self, msg: str) -> None:
        self.log_view.appendPlainText(msg)

    def set_running(self, running: bool) -> None:
        self.btn_start.setEnabled(not running)
        self.btn_stop.setEnabled(running)


# ══════════════════════════════════════════════════════════════════════════
# Aba 3 — Benchmark
# ══════════════════════════════════════════════════════════════════════════


class BenchmarkTab(QtWidgets.QWidget):
    """Aba de benchmarks Config A/B + experimento 30k."""

    request_start = Signal()
    request_stop = Signal()

    def __init__(self, parent: Optional[QtWidgets.QWidget] = None) -> None:
        super().__init__(parent)
        ncpu = os.cpu_count() or 8

        grp_exp = QtWidgets.QGroupBox("Experimentos a executar")
        exp_layout = QtWidgets.QVBoxLayout(grp_exp)
        self.check_cfg_a = QtWidgets.QCheckBox(
            "Config A — 1 freq (20 kHz) · 1 TR · 1 dip · 600 pos"
        )
        self.check_cfg_b = QtWidgets.QCheckBox(
            "Config B — 2 freqs (20/40 kHz) · 1 TR · 2 dips (0/30°) · 600 pos"
        )
        self.check_30k = QtWidgets.QCheckBox(
            "Experimento 30k modelos aleatórios (20 camadas, alta ρ)"
        )
        self.check_cfg_a.setChecked(True)
        self.check_cfg_b.setChecked(True)
        exp_layout.addWidget(self.check_cfg_a)
        exp_layout.addWidget(self.check_cfg_b)
        exp_layout.addWidget(self.check_30k)

        grp_models = QtWidgets.QGroupBox("Modelos canônicos (Config A/B)")
        mdl_layout = QtWidgets.QVBoxLayout(grp_models)
        self.model_checks: Dict[str, QtWidgets.QCheckBox] = {}
        for m in CANONICAL_BENCHMARK_MODELS:
            cb = QtWidgets.QCheckBox(m)
            cb.setChecked(True)
            self.model_checks[m] = cb
            mdl_layout.addWidget(cb)

        grp_bk = QtWidgets.QGroupBox("Backends a comparar")
        bk_layout = QtWidgets.QHBoxLayout(grp_bk)
        self.check_numba = QtWidgets.QCheckBox("Numba JIT")
        self.check_numba.setChecked(True)
        self.check_fortran = QtWidgets.QCheckBox("Fortran tatu.x")
        self.check_fortran.setChecked(True)
        bk_layout.addWidget(self.check_numba)
        bk_layout.addWidget(self.check_fortran)

        grp_par = QtWidgets.QGroupBox("Paralelismo")
        par_form = QtWidgets.QFormLayout(grp_par)
        self.spin_workers_numba = _spin_int(max(1, ncpu // 4), 1, 256)
        self.spin_threads_numba = _spin_int(4, 1, 256)
        self.spin_workers_fortran = _spin_int(max(1, ncpu // 2), 1, 256)
        self.spin_threads_fortran = _spin_int(2, 1, 256)
        self.spin_n_iter = _spin_int(3, 1, 100)
        self.spin_fort_subset = _spin_int(300, 1, 30000)
        par_form.addRow("Workers Numba:", self.spin_workers_numba)
        par_form.addRow("Threads/worker Numba:", self.spin_threads_numba)
        par_form.addRow("Workers Fortran:", self.spin_workers_fortran)
        par_form.addRow("Threads/worker Fortran:", self.spin_threads_fortran)
        par_form.addRow("n_iter (Config A/B):", self.spin_n_iter)
        par_form.addRow("Subset Fortran (30k):", self.spin_fort_subset)

        grp_exec = QtWidgets.QGroupBox("Execução do Benchmark")
        exec_row = QtWidgets.QHBoxLayout(grp_exec)
        self.btn_start = QtWidgets.QPushButton("▶ Iniciar Benchmark")
        self.btn_stop = QtWidgets.QPushButton("■ Parar")
        self.btn_stop.setEnabled(False)
        self.progress = QtWidgets.QProgressBar()
        self.progress.setRange(0, 100)
        self.lbl_current = QtWidgets.QLabel("(aguardando)")
        exec_row.addWidget(self.btn_start)
        exec_row.addWidget(self.btn_stop)
        exec_row.addWidget(self.progress)
        exec_row.addWidget(self.lbl_current)
        self.btn_start.clicked.connect(self.request_start.emit)
        self.btn_stop.clicked.connect(self.request_stop.emit)

        self.log_view = QtWidgets.QPlainTextEdit()
        self.log_view.setReadOnly(True)
        self.log_view.setPlaceholderText("Log de benchmark aparecerá aqui.")
        self.log_view.setMaximumBlockCount(5000)

        # Tabela de resultados
        self.table = QtWidgets.QTableWidget(0, 8)
        self.table.setHorizontalHeaderLabels(
            [
                "Modelo",
                "Config",
                "n_models",
                "Numba ms/mod",
                "Fortran ms/mod",
                "Numba mod/h",
                "Fortran mod/h",
                "Speedup",
            ]
        )
        self.table.horizontalHeader().setStretchLastSection(True)

        grid = QtWidgets.QGridLayout(self)
        grid.addWidget(grp_exp, 0, 0, 1, 2)
        grid.addWidget(grp_models, 1, 0)
        grid.addWidget(grp_bk, 1, 1)
        grid.addWidget(grp_par, 2, 0, 1, 2)
        grid.addWidget(grp_exec, 3, 0, 1, 2)
        grid.addWidget(self.log_view, 4, 0, 1, 2)
        grid.addWidget(self.table, 5, 0, 1, 2)
        grid.setRowStretch(4, 1)
        grid.setRowStretch(5, 1)

    def selected_models(self) -> List[str]:
        return [m for m, cb in self.model_checks.items() if cb.isChecked()]

    def append_log(self, msg: str) -> None:
        self.log_view.appendPlainText(msg)

    def set_running(self, running: bool) -> None:
        self.btn_start.setEnabled(not running)
        self.btn_stop.setEnabled(running)

    def populate_table(self, records: List[BenchRecord]) -> None:
        self.table.setRowCount(0)
        for r in records:
            row = self.table.rowCount()
            self.table.insertRow(row)
            vals = [
                r.model_name,
                r.config,
                str(r.n_models),
                f"{r.numba_ms_per_model:.2f}",
                f"{r.fortran_ms_per_model:.2f}",
                f"{r.numba_mod_h:,.0f}",
                f"{r.fortran_mod_h:,.0f}",
                f"{r.speedup:.2f}×",
            ]
            for col, v in enumerate(vals):
                item = QtWidgets.QTableWidgetItem(v)
                item.setTextAlignment(ALIGN_CENTER if ALIGN_CENTER else 0x4)
                self.table.setItem(row, col, item)


# ══════════════════════════════════════════════════════════════════════════
# Aba 4 — Resultados / Plots
# ══════════════════════════════════════════════════════════════════════════


class ResultsTab(QtWidgets.QWidget):
    """Aba de plotagem interativa de resultados e benchmarks."""

    def __init__(self, parent: Optional[QtWidgets.QWidget] = None) -> None:
        super().__init__(parent)

        # Painel esquerdo — controles
        controls = QtWidgets.QGroupBox("Controles de Plot")
        ctrl_layout = QtWidgets.QFormLayout(controls)

        self.combo_source = QtWidgets.QComboBox()
        self.combo_source.addItems(["Simulação atual", "Benchmark (Numba vs Fortran)"])

        self.combo_model_key = QtWidgets.QComboBox()

        self.list_components = QtWidgets.QListWidget()
        self.list_components.setSelectionMode(
            QtWidgets.QAbstractItemView.SelectionMode.MultiSelection
            if hasattr(QtWidgets.QAbstractItemView, "SelectionMode")
            else QtWidgets.QAbstractItemView.MultiSelection
        )
        for c in COMPONENT_NAMES:
            item = QtWidgets.QListWidgetItem(c)
            self.list_components.addItem(item)
            if c in ("Hxx", "Hzz"):
                item.setSelected(True)

        self.combo_plot_kind = QtWidgets.QComboBox()
        self.combo_plot_kind.addItems(
            [
                "Componentes EM",
                "Perfil de Resistividade",
                "Geosinais (USD/UAD/UHR/UHA)",
                "Benchmark compare (Numba vs Fortran)",
            ]
        )

        self.btn_plot = QtWidgets.QPushButton("Plotar")
        self.btn_save = QtWidgets.QPushButton("Salvar figura PNG")

        ctrl_layout.addRow("Fonte:", self.combo_source)
        ctrl_layout.addRow("Modelo / Célula:", self.combo_model_key)
        ctrl_layout.addRow("Componentes EM:", self.list_components)
        ctrl_layout.addRow("Tipo de plot:", self.combo_plot_kind)
        ctrl_layout.addRow(self.btn_plot)
        ctrl_layout.addRow(self.btn_save)

        # Painel direito — canvas
        self.canvas = EMCanvas(self, figsize=(12, 8))

        splitter = QtWidgets.QSplitter(
            Qt.Orientation.Horizontal if hasattr(Qt, "Orientation") else Qt.Horizontal
        )
        splitter.addWidget(controls)
        splitter.addWidget(self.canvas)
        splitter.setStretchFactor(1, 1)

        root = QtWidgets.QHBoxLayout(self)
        root.addWidget(splitter)

        # Estado interno
        self._current_sim: Optional[Dict[str, Any]] = None
        self._benchmark_plot_data: Dict[Tuple[str, str], Dict[str, Any]] = {}

        self.btn_plot.clicked.connect(self._on_plot)
        self.btn_save.clicked.connect(self._on_save)
        self.combo_source.currentIndexChanged.connect(self._refresh_keys)

    # ── Atualização de fontes ────────────────────────────────────────────
    def set_current_simulation(self, result: Dict[str, Any]) -> None:
        self._current_sim = result
        self._refresh_keys()

    def set_benchmark_plot_data(
        self, data: Dict[Tuple[str, str], Dict[str, Any]]
    ) -> None:
        self._benchmark_plot_data = data
        self._refresh_keys()

    def _refresh_keys(self) -> None:
        self.combo_model_key.clear()
        if self.combo_source.currentIndex() == 0:
            # Simulação atual — entrada única
            if self._current_sim is not None:
                self.combo_model_key.addItem("(simulação atual)")
        else:
            for m, c in self._benchmark_plot_data.keys():
                self.combo_model_key.addItem(f"{m} / Config {c}")

    # ── Plot + Save ─────────────────────────────────────────────────────
    def _selected_components(self) -> List[str]:
        items = self.list_components.selectedItems()
        return [it.text() for it in items] if items else ["Hxx", "Hzz"]

    def _on_plot(self) -> None:
        kind = self.combo_plot_kind.currentText()
        comps = self._selected_components()

        if self.combo_source.currentIndex() == 0:
            sim = self._current_sim
            if not sim:
                return
            H = sim.get("H_stack")
            z_obs = sim.get("z_obs")
            freqs = sim.get("freqs", [20000.0])
            trs = sim.get("trs", [1.0])
            dips = sim.get("dips", [0.0])
            if H is None or H.size == 0:
                return
            # Usa primeiro modelo do stack
            H0 = H[0] if H.ndim == 6 else H
            if kind == "Componentes EM":
                plot_em_profile(
                    self.canvas,
                    H0,
                    z_obs,
                    freqs,
                    trs,
                    dips,
                    comps,
                    title=f"Simulação — {comps}",
                )
            elif kind == "Geosinais (USD/UAD/UHR/UHA)":
                plot_geosignals(
                    self.canvas,
                    H0,
                    z_obs,
                    freqs,
                    trs,
                    dips,
                    title="Geosinais — Simulação",
                )
            elif kind == "Perfil de Resistividade":
                md = sim.get("model", {})
                plot_resistivity_profile(
                    self.canvas,
                    md.get("rho_h", []),
                    md.get("rho_v", []),
                    md.get("thicknesses", []),
                    title=md.get("title", "Perfil"),
                )
            else:
                # Benchmark compare sem dados Fortran — só Numba
                plot_benchmark_compare(
                    self.canvas,
                    H0,
                    None,
                    z_obs,
                    freqs,
                    trs,
                    dips,
                    comps,
                    title="Somente Numba (sem benchmark ativo)",
                )
        else:
            # Fonte = benchmark
            key_text = self.combo_model_key.currentText()
            if not key_text or "/" not in key_text:
                return
            parts = key_text.split("/")
            model_name = parts[0].strip()
            config = parts[1].replace("Config", "").strip()
            entry = self._benchmark_plot_data.get((model_name, config))
            if entry is None:
                return
            freqs = entry.get("freqs", [20000.0])
            trs = entry.get("trs", [1.0])
            dips = entry.get("dips", [0.0])
            H_n = entry.get("H_numba")
            H_f = entry.get("H_fortran")
            md = entry.get("model", {})
            positions_z = entry.get("positions_z")
            z_obs_2d = None
            if positions_z is not None:
                z_obs_2d = np.broadcast_to(positions_z, (len(dips), positions_z.shape[0]))

            if kind == "Perfil de Resistividade":
                plot_resistivity_profile(
                    self.canvas,
                    md.get("rho_h", []),
                    md.get("rho_v", []),
                    md.get("thicknesses", []),
                    title=f"{md.get('title', model_name)} — Config {config}",
                )
            elif kind == "Componentes EM" and H_n is not None:
                plot_em_profile(
                    self.canvas,
                    H_n,
                    z_obs_2d,
                    freqs,
                    trs,
                    dips,
                    comps,
                    title=f"{model_name} — Config {config} (Numba)",
                )
            elif kind == "Geosinais (USD/UAD/UHR/UHA)" and H_n is not None:
                plot_geosignals(
                    self.canvas,
                    H_n,
                    z_obs_2d,
                    freqs,
                    trs,
                    dips,
                    title=f"{model_name} — Config {config}",
                )
            else:
                plot_benchmark_compare(
                    self.canvas,
                    H_n,
                    H_f,
                    z_obs_2d,
                    freqs,
                    trs,
                    dips,
                    comps,
                    title=f"Benchmark — {model_name} · Config {config}",
                )

    def _on_save(self) -> None:
        path, _ = QtWidgets.QFileDialog.getSaveFileName(
            self, "Salvar figura", "plot.png", "PNG (*.png);;PDF (*.pdf);;SVG (*.svg)"
        )
        if path:
            self.canvas.save(path)


# ══════════════════════════════════════════════════════════════════════════
# Janela principal
# ══════════════════════════════════════════════════════════════════════════


class MainWindow(QtWidgets.QMainWindow):
    """Janela principal que agrega as 4 abas e orquestra signals/slots."""

    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle(f"Simulation Manager — Geosteering AI v2.0 ({QT_BINDING})")
        self.resize(1280, 820)

        self.tab_params = ParametersTab()
        self.tab_sim = SimulatorTab()
        self.tab_bench = BenchmarkTab()
        self.tab_results = ResultsTab()

        tabs = QtWidgets.QTabWidget()
        tabs.addTab(self.tab_params, "1 · Parâmetros")
        tabs.addTab(self.tab_sim, "2 · Simulador")
        tabs.addTab(self.tab_bench, "3 · Benchmark")
        tabs.addTab(self.tab_results, "4 · Resultados")
        self.setCentralWidget(tabs)

        # Status bar
        self.status = self.statusBar()
        self.status.showMessage("Pronto.")

        # Threads
        self._sim_thread: Optional[SimulationThread] = None
        self._bench_thread: Optional[BenchmarkThread] = None

        # Wiring
        self.tab_sim.request_start.connect(self._start_simulation)
        self.tab_sim.request_stop.connect(self._stop_simulation)
        self.tab_bench.request_start.connect(self._start_benchmark)
        self.tab_bench.request_stop.connect(self._stop_benchmark)

    # ── Simulação ────────────────────────────────────────────────────────
    def _start_simulation(self) -> None:
        if self._sim_thread and self._sim_thread.isRunning():
            QtWidgets.QMessageBox.warning(
                self, "Simulação em curso", "Aguarde o término antes de iniciar outra."
            )
            return
        try:
            params = self.tab_params
            sim = self.tab_sim
            freqs = params.collect_freqs() or [20000.0]
            trs = params.collect_trs() or [1.0]
            dips = params.collect_angles() or [0.0]
            # Grade de medição: 600 pontos padrão via tj/p_med/cos(dip=0)
            import math

            cos_d = max(1e-6, math.cos(math.radians(abs(dips[0]))))
            n_pos = max(
                1,
                int(
                    math.ceil(params.spin_tj.value() / (params.spin_pmed.value() * cos_d))
                ),
            )
            positions_z = np.linspace(
                0.0, params.spin_tj.value(), n_pos, dtype=np.float64
            )

            gen_cfg = params.build_gen_config()
            n_models = int(params.spin_nmodels.value())
            sim.append_log(
                f"Gerando {n_models} modelos (generator={gen_cfg.generator})..."
            )
            models = generate_models(gen_cfg, n_models=n_models, rng_seed=42)
            sim.append_log(f"  → {len(models)} perfis prontos.")

            output_dir = sim.edit_output_dir.text().strip() or str(
                Path.cwd() / "sm_output"
            )
            os.makedirs(output_dir, exist_ok=True)
            fortran_bin = sim.edit_fortran_bin.text().strip()
            if sim.combo_backend.currentText() == "fortran" and not os.path.isfile(
                fortran_bin
            ):
                QtWidgets.QMessageBox.critical(
                    self,
                    "tatu.x não encontrado",
                    f"O binário Fortran não foi encontrado em {fortran_bin!r}.",
                )
                return

            req = SimRequest(
                frequencies_hz=freqs,
                tr_spacings_m=trs,
                dip_degs=dips,
                positions_z=positions_z,
                backend=sim.combo_backend.currentText(),
                n_workers=int(sim.spin_workers.value()),
                n_threads=int(sim.spin_threads.value()),
                hankel_filter=params.combo_filter.currentText(),
                h1=float(params.spin_h1.value()),
                tj=float(params.spin_tj.value()),
                p_med=float(params.spin_pmed.value()),
                fortran_binary=fortran_bin,
                save_raw=sim.check_save_dat.isChecked() or sim.check_save_out.isChecked(),
                output_dir=output_dir,
                output_filename="sim_output",
            )

            self._sim_thread = SimulationThread(req, models, parent=self)
            self._sim_thread.log.connect(sim.append_log)
            self._sim_thread.progress_update.connect(self._on_sim_progress)
            self._sim_thread.finished_all.connect(
                lambda d: self._on_sim_finished(d, req, models)
            )
            self._sim_thread.error.connect(self._on_sim_error)
            sim.set_running(True)
            sim.progress.setValue(0)
            sim.append_log("Iniciando simulação...")
            self._sim_thread.start()
        except Exception as exc:
            QtWidgets.QMessageBox.critical(self, "Erro", str(exc))

    def _stop_simulation(self) -> None:
        if self._sim_thread and self._sim_thread.isRunning():
            self._sim_thread.request_stop()
            self.tab_sim.append_log(
                "Solicitação de parada enviada (parada ocorrerá entre chunks)."
            )

    def _on_sim_progress(self, done: int, total: int, mod_h: float) -> None:
        pct = int(100.0 * done / max(total, 1))
        self.tab_sim.progress.setValue(pct)
        self.tab_sim.lbl_throughput.setText(f"Throughput: {mod_h:,.0f} mod/h")
        self.status.showMessage(f"{done}/{total} modelos · {mod_h:,.0f} mod/h")
        if done % 100 == 0 or done == total:
            self.tab_sim.append_log(
                f"  Progresso: {done}/{total} modelos · {mod_h:,.0f} mod/h"
            )

    def _on_sim_finished(
        self,
        result: Dict[str, Any],
        req: "SimRequest",
        models: List[dict],
    ) -> None:
        self.tab_sim.set_running(False)
        self.tab_sim.progress.setValue(100)
        elapsed = float(result.get("elapsed", 0.0))
        mod_h = float(result.get("throughput_mod_h", 0.0))
        self.tab_sim.append_log(
            f"Simulação concluída em {elapsed:.1f}s — {mod_h:,.0f} mod/h"
        )
        # Export opcional
        try:
            if req.backend == "numba" and self.tab_sim.check_save_dat.isChecked():
                H_stack = result.get("H_stack")
                z_obs = result.get("z_obs")
                if H_stack is not None and H_stack.size and z_obs is not None:
                    dat_path = os.path.join(req.output_dir, f"{req.output_filename}.dat")
                    write_dat_from_tensor(dat_path, H_stack, z_obs)
                    self.tab_sim.append_log(f"  .dat salvo em {dat_path}")
            if req.backend == "numba" and self.tab_sim.check_save_out.isChecked():
                nmeds = compute_nmeds_per_angle(req.tj, req.p_med, req.dip_degs)
                out_path = os.path.join(req.output_dir, f"{req.output_filename}.out")
                write_out_file(
                    out_path,
                    n_dips=len(req.dip_degs),
                    n_freqs=len(req.frequencies_hz),
                    nmaxmodel=len(models),
                    angles=req.dip_degs,
                    freqs_hz=req.frequencies_hz,
                    nmeds_per_angle=nmeds,
                )
                self.tab_sim.append_log(f"  .out salvo em {out_path}")
        except Exception as exc:
            self.tab_sim.append_log(f"  [AVISO] Falha ao exportar artefatos: {exc}")

        # Passa para aba Resultados
        plot_bundle = {
            "backend": req.backend,
            "H_stack": result.get("H_stack"),
            "z_obs": result.get("z_obs"),
            "freqs": req.frequencies_hz,
            "trs": req.tr_spacings_m,
            "dips": req.dip_degs,
            "model": models[0] if models else {},
        }
        self.tab_results.set_current_simulation(plot_bundle)

    def _on_sim_error(self, msg: str) -> None:
        self.tab_sim.set_running(False)
        self.tab_sim.append_log(f"[ERRO] {msg}")
        QtWidgets.QMessageBox.critical(self, "Erro na simulação", msg[:800])

    # ── Benchmark ────────────────────────────────────────────────────────
    def _start_benchmark(self) -> None:
        if self._bench_thread and self._bench_thread.isRunning():
            QtWidgets.QMessageBox.warning(
                self, "Benchmark em curso", "Aguarde o término."
            )
            return
        try:
            bt = self.tab_bench
            sim = self.tab_sim
            params = self.tab_params
            fortran_bin = sim.edit_fortran_bin.text().strip()
            if bt.check_fortran.isChecked() and not os.path.isfile(fortran_bin):
                QtWidgets.QMessageBox.critical(
                    self,
                    "tatu.x não encontrado",
                    f"Binário Fortran não encontrado em {fortran_bin!r}.",
                )
                return
            output_dir = sim.edit_output_dir.text().strip() or str(
                Path.cwd() / "sm_output"
            )
            os.makedirs(output_dir, exist_ok=True)

            settings = BenchmarkSettings(
                run_config_a=bt.check_cfg_a.isChecked(),
                run_config_b=bt.check_cfg_b.isChecked(),
                run_30k=bt.check_30k.isChecked(),
                models=bt.selected_models() or CANONICAL_BENCHMARK_MODELS,
                n_iter=int(bt.spin_n_iter.value()),
                fortran_subset=int(bt.spin_fort_subset.value()),
                n_workers_numba=int(bt.spin_workers_numba.value()),
                n_threads_numba=int(bt.spin_threads_numba.value()),
                n_workers_fortran=int(bt.spin_workers_fortran.value()),
                n_threads_fortran=int(bt.spin_threads_fortran.value()),
                fortran_binary=fortran_bin,
                run_numba=bt.check_numba.isChecked(),
                run_fortran=bt.check_fortran.isChecked(),
                hankel_filter=params.combo_filter.currentText(),
                h1=float(params.spin_h1.value()),
                tj=float(params.spin_tj.value()),
                p_med=float(params.spin_pmed.value()),
                output_dir=output_dir,
            )

            self._bench_thread = BenchmarkThread(settings, parent=self)
            self._bench_thread.log.connect(bt.append_log)
            self._bench_thread.progress.connect(self._on_bench_progress)
            self._bench_thread.finished_all.connect(self._on_bench_finished)
            self._bench_thread.error.connect(self._on_bench_error)
            bt.set_running(True)
            bt.progress.setValue(0)
            bt.lbl_current.setText("iniciando...")
            self._bench_thread.start()
        except Exception as exc:
            QtWidgets.QMessageBox.critical(self, "Erro", str(exc))

    def _stop_benchmark(self) -> None:
        if self._bench_thread and self._bench_thread.isRunning():
            # BenchmarkThread não implementa stop cooperativo fino —
            # sinaliza e aguarda término do chunk atual.
            self.tab_bench.append_log(
                "Parada solicitada — aguardando célula atual terminar..."
            )

    def _on_bench_progress(self, i: int, n: int, label: str) -> None:
        pct = int(100.0 * i / max(n, 1))
        self.tab_bench.progress.setValue(pct)
        self.tab_bench.lbl_current.setText(label)
        self.status.showMessage(f"Benchmark {i}/{n} — {label}")

    def _on_bench_finished(self, records: list, plot_data: dict) -> None:
        self.tab_bench.set_running(False)
        self.tab_bench.progress.setValue(100)
        self.tab_bench.append_log(f"Benchmark concluído — {len(records)} células.")
        self.tab_bench.populate_table(records)
        self.tab_results.set_benchmark_plot_data(plot_data)

    def _on_bench_error(self, msg: str) -> None:
        self.tab_bench.set_running(False)
        self.tab_bench.append_log(f"[ERRO] {msg}")
        QtWidgets.QMessageBox.critical(self, "Erro no benchmark", msg[:800])


# ══════════════════════════════════════════════════════════════════════════
# Entry point
# ══════════════════════════════════════════════════════════════════════════


def main() -> int:
    """Entry point CLI: inicia a aplicação PyQt."""
    check_qt_available()
    # Multiprocessing seguro em macOS (necessário para ProcessPoolExecutor)
    import multiprocessing

    try:
        multiprocessing.set_start_method("spawn", force=False)
    except RuntimeError:
        pass

    app = QtWidgets.QApplication(sys.argv)
    app.setApplicationName("Simulation Manager")
    app.setOrganizationName("Geosteering AI")
    window = MainWindow()
    window.show()
    return app.exec() if hasattr(app, "exec") else app.exec_()


if __name__ == "__main__":
    sys.exit(main())
