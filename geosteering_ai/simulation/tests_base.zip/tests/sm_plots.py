# -*- coding: utf-8 -*-
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║  geosteering_ai/simulation/tests/sm_plots.py                              ║
# ║  ---------------------------------------------------------------------    ║
# ║  Projeto     : Geosteering AI v2.0                                        ║
# ║  Subsistema  : Simulation Manager — Plots EM e Resistividade              ║
# ║  Autor       : Daniel Leal                                                ║
# ║  Criação     : 2026-04-18                                                 ║
# ║  Status      : Produção                                                   ║
# ║  Framework   : matplotlib + Qt backend (FigureCanvasQTAgg)                ║
# ║  Dependências: matplotlib ≥ 3.5, numpy                                    ║
# ║  ---------------------------------------------------------------------    ║
# ║  FINALIDADE                                                               ║
# ║    Encapsula o canvas matplotlib + helpers de plotagem para os campos    ║
# ║    eletromagnéticos (Hxx..Hzz, 9 componentes), perfis de resistividade   ║
# ║    (ρh, ρv) e geosinais derivados (USD/UAD/UHR/UHA). Comparação lado-a-  ║
# ║    lado entre Numba e Fortran quando ambos estão disponíveis.             ║
# ║                                                                           ║
# ║  API PÚBLICA                                                              ║
# ║    • EMCanvas      — QWidget com FigureCanvasQTAgg encapsulado           ║
# ║    • plot_em_profile(canvas, ...)      — plot em canvas existente        ║
# ║    • plot_resistivity_profile(canvas, ...)                                ║
# ║    • plot_benchmark_compare(canvas, ...) — Numba vs Fortran sobreposto   ║
# ║    • COMPONENT_NAMES                   — nomes canônicos Hxx..Hzz        ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
"""Plotagem de campos EM e perfis geológicos com canvas Qt-embedded.

O módulo fornece ``EMCanvas`` — um ``QWidget`` com figura matplotlib
redimensionável — e funções utilitárias para os tipos de plot mais
comuns no Simulation Manager (perfil, campo EM, comparação benchmark).
"""
from __future__ import annotations

from typing import Any, List, Optional, Sequence

import numpy as np

from .sm_qt_compat import QtCore, QtWidgets

# Import matplotlib com backend Qt — fallback leve se matplotlib ausente
try:
    import matplotlib

    matplotlib.use("QtAgg", force=False)
    from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg
    from matplotlib.figure import Figure

    _HAS_MPL = True
except Exception:  # pragma: no cover
    _HAS_MPL = False
    FigureCanvasQTAgg = object  # type: ignore
    Figure = object  # type: ignore


COMPONENT_NAMES = [
    "Hxx",
    "Hxy",
    "Hxz",
    "Hyx",
    "Hyy",
    "Hyz",
    "Hzx",
    "Hzy",
    "Hzz",
]


# ──────────────────────────────────────────────────────────────────────────
# Canvas Qt-embedded
# ──────────────────────────────────────────────────────────────────────────


class EMCanvas(QtWidgets.QWidget):
    """Canvas matplotlib embutido em ``QWidget`` para uso em abas PyQt.

    Attributes:
        figure: ``matplotlib.figure.Figure`` — acesso direto para customização.
        canvas: ``FigureCanvasQTAgg`` — widget Qt renderizador.
    """

    def __init__(
        self, parent: Optional[QtWidgets.QWidget] = None, figsize=(10, 6)
    ) -> None:
        super().__init__(parent)
        if not _HAS_MPL:
            # Placeholder leve quando matplotlib não está instalado
            layout = QtWidgets.QVBoxLayout(self)
            layout.addWidget(
                QtWidgets.QLabel(
                    "matplotlib não instalado — plots desabilitados.\n"
                    "Instale com: pip install matplotlib"
                )
            )
            self.figure = None
            self.canvas = None
            return

        self.figure = Figure(figsize=figsize, constrained_layout=True)
        self.canvas = FigureCanvasQTAgg(self.figure)
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self.canvas)

    def clear(self) -> None:
        """Limpa a figura atual."""
        if self.figure is None:
            return
        self.figure.clear()
        self.canvas.draw_idle()

    def draw(self) -> None:
        """Dispara redesenho imediato."""
        if self.canvas is not None:
            self.canvas.draw_idle()

    def save(self, path: str, dpi: int = 150) -> None:
        """Salva o conteúdo atual em disco (PNG/PDF/SVG via extensão)."""
        if self.figure is not None:
            self.figure.savefig(path, dpi=dpi, bbox_inches="tight")


# ──────────────────────────────────────────────────────────────────────────
# Plots
# ──────────────────────────────────────────────────────────────────────────


def plot_resistivity_profile(
    canvas: EMCanvas,
    rho_h: Sequence[float],
    rho_v: Sequence[float],
    thicknesses: Sequence[float],
    title: str = "Perfil de Resistividade",
) -> None:
    """Desenha ρₕ/ρᵥ como steps em profundidade (primeira camada no topo)."""
    if canvas.figure is None:
        return
    canvas.figure.clear()
    ax = canvas.figure.add_subplot(1, 1, 1)

    rho_h = np.asarray(rho_h, dtype=np.float64)
    rho_v = np.asarray(rho_v, dtype=np.float64)
    thick = np.asarray(thicknesses, dtype=np.float64)

    n = len(rho_h)
    # Depths: boundaries das camadas internas (n-2 espessuras → n interfaces)
    if n >= 3 and len(thick) == n - 2:
        top = 0.0
        boundaries = [top]
        for t in thick:
            boundaries.append(boundaries[-1] + t)
        depths = [boundaries[0] - 5.0] + boundaries + [boundaries[-1] + 5.0]
    else:
        # Perfil arbitrário — distribui uniformemente
        depths = np.linspace(0.0, 1.0, n + 1).tolist()

    # Constrói steps (matplotlib 'steps-pre')
    y_edges = np.array(depths, dtype=np.float64)
    centers = 0.5 * (y_edges[:-1] + y_edges[1:])
    ax.step(rho_h, centers, where="mid", color="tab:blue", label=r"$\rho_h$", lw=2)
    ax.step(
        rho_v, centers, where="mid", color="tab:orange", label=r"$\rho_v$", lw=2, ls="--"
    )
    ax.set_xscale("log")
    ax.set_xlabel(r"Resistividade ($\Omega\cdot m$)")
    ax.set_ylabel("Profundidade (m)")
    ax.invert_yaxis()
    ax.grid(True, which="both", ls=":", alpha=0.6)
    ax.legend()
    ax.set_title(title)
    canvas.draw()


def plot_em_profile(
    canvas: EMCanvas,
    H_tensor: np.ndarray,
    z_obs: np.ndarray,
    freqs: Sequence[float],
    trs: Sequence[float],
    dips: Sequence[float],
    components: Sequence[str] = ("Hxx", "Hzz"),
    title: str = "Campos EM",
) -> None:
    """Plota componentes EM (|H|, Re, Im) em função da profundidade.

    ``H_tensor`` tem shape ``(nTR, nAng, n_pos, nf, 9)`` vindo de
    :class:`geosteering_ai.simulation.MultiSimulationResult`. Para cenários
    multi-dim, varre todas as combinações (nTR × nAng × nf) no mesmo painel
    com legendas rotuladas.
    """
    if canvas.figure is None:
        return
    canvas.figure.clear()

    H = np.asarray(H_tensor)
    if H.ndim != 5:
        # Shape alternativo — aborta com mensagem na figura
        ax = canvas.figure.add_subplot(1, 1, 1)
        ax.text(
            0.5,
            0.5,
            f"H_tensor shape inesperado: {H.shape}",
            ha="center",
            transform=ax.transAxes,
        )
        canvas.draw()
        return

    nTR, nAng, n_pos, nf, _ = H.shape
    n_comp = max(1, len(components))
    axes = canvas.figure.subplots(n_comp, 2, squeeze=False)

    comp_idx = {name: i for i, name in enumerate(COMPONENT_NAMES)}

    for row, cname in enumerate(components):
        idx = comp_idx.get(cname, 0)
        ax_mag = axes[row][0]
        ax_phase = axes[row][1]
        for itr in range(nTR):
            for iang in range(nAng):
                for ifq in range(nf):
                    label = (
                        f"TR={trs[itr]}m · θ={dips[iang]}° · f={freqs[ifq]/1e3:.1f}kHz"
                    )
                    # z_obs shape (nAng, n_pos) — pode ser None
                    if z_obs is not None and z_obs.ndim == 2:
                        z = z_obs[iang]
                    elif z_obs is not None and z_obs.ndim == 1:
                        z = z_obs
                    else:
                        z = np.arange(n_pos)
                    H_sel = H[itr, iang, :, ifq, idx]
                    mag = np.abs(H_sel)
                    phase = np.degrees(np.angle(H_sel))
                    ax_mag.plot(mag, z, label=label, lw=1.2)
                    ax_phase.plot(phase, z, label=label, lw=1.2)
        ax_mag.set_xlabel(f"|{cname}| (A/m)")
        ax_mag.set_ylabel("z (m)")
        ax_mag.invert_yaxis()
        ax_mag.grid(True, ls=":", alpha=0.6)
        ax_mag.set_xscale("log")
        ax_phase.set_xlabel(f"Fase {cname} (°)")
        ax_phase.invert_yaxis()
        ax_phase.grid(True, ls=":", alpha=0.6)
        if row == 0:
            ax_mag.legend(fontsize=7, loc="best")
    canvas.figure.suptitle(title, fontsize=12)
    canvas.draw()


def plot_benchmark_compare(
    canvas: EMCanvas,
    H_numba: Optional[np.ndarray],
    H_fortran: Optional[np.ndarray],
    z_obs: np.ndarray,
    freqs: Sequence[float],
    trs: Sequence[float],
    dips: Sequence[float],
    components: Sequence[str] = ("Hxx", "Hzz"),
    title: str = "Benchmark — Numba vs Fortran",
) -> None:
    """Plota sobreposição Numba (linha) vs Fortran (pontos) para comparação.

    Se um dos tensores for ``None``, somente o outro é renderizado.
    """
    if canvas.figure is None:
        return
    canvas.figure.clear()
    H_list = [(H_numba, "Numba", "-", 1.5, None), (H_fortran, "Fortran", "", 0, "o")]
    H_list = [(h, lbl, ls, lw, mk) for h, lbl, ls, lw, mk in H_list if h is not None]
    if not H_list:
        ax = canvas.figure.add_subplot(1, 1, 1)
        ax.text(0.5, 0.5, "Sem dados para comparar.", ha="center", transform=ax.transAxes)
        canvas.draw()
        return

    ref = H_list[0][0]
    if ref.ndim != 5:
        ax = canvas.figure.add_subplot(1, 1, 1)
        ax.text(
            0.5,
            0.5,
            f"Shape H inesperado: {ref.shape}",
            ha="center",
            transform=ax.transAxes,
        )
        canvas.draw()
        return
    nTR, nAng, n_pos, nf, _ = ref.shape
    comp_idx = {name: i for i, name in enumerate(COMPONENT_NAMES)}
    axes = canvas.figure.subplots(len(components), 1, squeeze=False)

    for row, cname in enumerate(components):
        idx = comp_idx.get(cname, 0)
        ax = axes[row][0]
        for H, lbl, ls, lw, mk in H_list:
            for itr in range(nTR):
                for iang in range(nAng):
                    for ifq in range(nf):
                        if z_obs is not None and z_obs.ndim == 2:
                            z = z_obs[iang]
                        elif z_obs is not None and z_obs.ndim == 1:
                            z = z_obs
                        else:
                            z = np.arange(H.shape[2])
                        if H.shape[0] <= itr or H.shape[1] <= iang or H.shape[3] <= ifq:
                            continue
                        mag = np.abs(H[itr, iang, :, ifq, idx])
                        suffix = (
                            f" TR={trs[itr]} θ={dips[iang]} " f"f={freqs[ifq]/1e3:.1f}k"
                        )
                        if mk:
                            ax.plot(
                                mag,
                                z,
                                marker=mk,
                                ms=3,
                                ls="none",
                                label=f"{lbl}{suffix}",
                            )
                        else:
                            ax.plot(mag, z, ls=ls, lw=lw, label=f"{lbl}{suffix}")
        ax.set_xlabel(f"|{cname}| (A/m)")
        ax.set_ylabel("z (m)")
        ax.invert_yaxis()
        ax.set_xscale("log")
        ax.grid(True, ls=":", alpha=0.6)
        if row == 0:
            ax.legend(fontsize=6, loc="best", ncol=2)
    canvas.figure.suptitle(title, fontsize=12)
    canvas.draw()


def plot_geosignals(
    canvas: EMCanvas,
    H_tensor: np.ndarray,
    z_obs: np.ndarray,
    freqs: Sequence[float],
    trs: Sequence[float],
    dips: Sequence[float],
    title: str = "Geosinais (USD / UAD / UHR / UHA)",
) -> None:
    """Plota geosinais derivados dos componentes tensoriais.

    Convenção padrão:
      * **USD** = log10(|Hxx| / |Hyy|)   — Up-Side-Detection
      * **UAD** = fase(Hxx) − fase(Hyy)  — phase-shift antisimmetric
      * **UHR** = log10(|Hxz|/|Hzz|)     — harmonic resistivity proxy
      * **UHA** = fase(Hxz) − fase(Hzz)  — harmonic anisotropy
    """
    if canvas.figure is None:
        return
    canvas.figure.clear()
    H = np.asarray(H_tensor)
    if H.ndim != 5:
        ax = canvas.figure.add_subplot(1, 1, 1)
        ax.text(
            0.5,
            0.5,
            f"Shape H inesperado: {H.shape}",
            ha="center",
            transform=ax.transAxes,
        )
        canvas.draw()
        return
    nTR, nAng, n_pos, nf, _ = H.shape
    axes = canvas.figure.subplots(2, 2, squeeze=False)

    def _safe_log10(x: np.ndarray) -> np.ndarray:
        return np.log10(np.clip(x, 1e-30, None))

    for itr in range(nTR):
        for iang in range(nAng):
            for ifq in range(nf):
                if z_obs is not None and z_obs.ndim == 2:
                    z = z_obs[iang]
                elif z_obs is not None and z_obs.ndim == 1:
                    z = z_obs
                else:
                    z = np.arange(n_pos)
                Hxx = H[itr, iang, :, ifq, 0]
                Hyy = H[itr, iang, :, ifq, 4]
                Hxz = H[itr, iang, :, ifq, 2]
                Hzz = H[itr, iang, :, ifq, 8]
                lbl = f"TR={trs[itr]} θ={dips[iang]} f={freqs[ifq]/1e3:.1f}k"
                usd = _safe_log10(np.abs(Hxx) / np.clip(np.abs(Hyy), 1e-30, None))
                uad = np.degrees(np.angle(Hxx) - np.angle(Hyy))
                uhr = _safe_log10(np.abs(Hxz) / np.clip(np.abs(Hzz), 1e-30, None))
                uha = np.degrees(np.angle(Hxz) - np.angle(Hzz))
                axes[0][0].plot(usd, z, label=lbl, lw=1.2)
                axes[0][1].plot(uad, z, label=lbl, lw=1.2)
                axes[1][0].plot(uhr, z, label=lbl, lw=1.2)
                axes[1][1].plot(uha, z, label=lbl, lw=1.2)

    for ax, name in zip(
        [axes[0][0], axes[0][1], axes[1][0], axes[1][1]],
        ["USD", "UAD (°)", "UHR", "UHA (°)"],
    ):
        ax.set_xlabel(name)
        ax.set_ylabel("z (m)")
        ax.invert_yaxis()
        ax.grid(True, ls=":", alpha=0.6)
    axes[0][0].legend(fontsize=6, loc="best")
    canvas.figure.suptitle(title, fontsize=12)
    canvas.draw()


__all__ = [
    "COMPONENT_NAMES",
    "EMCanvas",
    "plot_benchmark_compare",
    "plot_em_profile",
    "plot_geosignals",
    "plot_resistivity_profile",
]
