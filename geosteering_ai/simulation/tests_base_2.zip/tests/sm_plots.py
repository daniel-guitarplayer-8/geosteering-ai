# -*- coding: utf-8 -*-
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║  geosteering_ai/simulation/tests/sm_plots.py                              ║
# ║  ---------------------------------------------------------------------    ║
# ║  Projeto     : Geosteering AI v2.0                                        ║
# ║  Subsistema  : Simulation Manager — Plots EM e Resistividade              ║
# ║  Autor       : Daniel Leal                                                ║
# ║  Criação     : 2026-04-18                                                 ║
# ║  Atualizado  : 2026-04-18 (PlotStyle + tensor 3×6 + modos físicos)       ║
# ║  Status      : Produção                                                   ║
# ║  Framework   : matplotlib + Qt backend (FigureCanvasQTAgg)                ║
# ║  Dependências: matplotlib ≥ 3.5, numpy                                    ║
# ║  ---------------------------------------------------------------------    ║
# ║  FINALIDADE                                                               ║
# ║    Encapsula o canvas matplotlib + helpers de plotagem para os campos    ║
# ║    eletromagnéticos (Hxx..Hzz, 9 componentes), perfis de resistividade   ║
# ║    (ρh, ρv) e geosinais derivados (USD/UAD/UHR/UHA). Comparação lado-a-  ║
# ║    lado entre Numba e Fortran quando ambos estão disponíveis.             ║
# ║                                                                           ║
# ║  MODOS DE PLOT IMPLEMENTADOS                                              ║
# ║    ┌────────────────────────────┬────────────────────────────────────┐   ║
# ║    │  Tensor H — 3×6 Re/Im      │  plot_tensor_full (referência)     │   ║
# ║    │  Magnitude + Fase          │  plot_em_profile (mag/phase)       │   ║
# ║    │  Re/Im por componente      │  plot_em_profile (kind="reim")     │   ║
# ║    │  Amplitude dB (log)        │  plot_em_profile (kind="db")       │   ║
# ║    │  Anisotropia λ²=ρᵥ/ρₕ      │  plot_anisotropy                  │   ║
# ║    │  Benchmark overlay         │  plot_benchmark_compare            │   ║
# ║    │  Geosinais USD/UAD/UHR/UHA │  plot_geosignals                   │   ║
# ║    │  Perfil ρₕ/ρᵥ + camadas    │  plot_resistivity_profile          │   ║
# ║    └────────────────────────────┴────────────────────────────────────┘   ║
# ║                                                                           ║
# ║  API PÚBLICA                                                              ║
# ║    • PlotStyle dataclass — parametrização global de estilo (cores, dpi,  ║
# ║       font size, line width, grid, precisão de eixos)                    ║
# ║    • EMCanvas      — QWidget com FigureCanvasQTAgg encapsulado            ║
# ║    • apply_style(style) — aplica PlotStyle ao matplotlib rcParams        ║
# ║    • plot_tensor_full(canvas, ...)      — grid 3×6 Re/Im (referência)   ║
# ║    • plot_em_profile(canvas, ..., kind) — mag/phase, reim, db           ║
# ║    • plot_resistivity_profile(canvas, ...)                                ║
# ║    • plot_benchmark_compare(canvas, ...) — Numba vs Fortran sobreposto   ║
# ║    • plot_geosignals(canvas, ...)        — USD/UAD/UHR/UHA grid         ║
# ║    • plot_anisotropy(canvas, ...)        — λ = √(ρᵥ/ρₕ) perfil          ║
# ║    • COMPONENT_NAMES                      — nomes canônicos Hxx..Hzz    ║
# ║    • PLOT_KINDS                           — lista de modos físicos      ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
"""Plotagem de campos EM e perfis geológicos com canvas Qt-embedded.

O módulo fornece ``EMCanvas`` — um ``QWidget`` com figura matplotlib
redimensionável — e funções utilitárias para os tipos de plot mais
comuns no Simulation Manager (perfil, campo EM, comparação benchmark,
grid tensor 3×6 Re/Im como referência visual do paper).

Exemplo de uso::

    >>> style = PlotStyle(dpi=150, line_width=1.8, font_size=11)
    >>> apply_style(style)
    >>> plot_tensor_full(canvas, H_tensor, z_obs, freqs, trs, dips,
    ...                  title="Oklahoma 15 cam · TR1 · θ=0° · f=6 kHz",
    ...                  style=style)

Note:
    Todos os labels/valores formatados usam ponto (``.``) como separador
    decimal (jamais vírgula), em linha com a convenção científica e os
    testes automatizados da suite.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, List, Optional, Sequence, Tuple

import numpy as np

from .sm_qt_compat import QtWidgets

# Import matplotlib com backend Qt — fallback leve se matplotlib ausente
try:
    import matplotlib

    matplotlib.use("QtAgg", force=False)
    from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg
    from matplotlib.figure import Figure

    _HAS_MPL = True
except Exception:  # pragma: no cover
    _HAS_MPL = False
    FigureCanvasQTAgg = object  # type: ignore
    Figure = object  # type: ignore


# ──────────────────────────────────────────────────────────────────────────
# Constantes — nomes canônicos do tensor H
# ──────────────────────────────────────────────────────────────────────────
COMPONENT_NAMES: List[str] = [
    "Hxx",
    "Hxy",
    "Hxz",
    "Hyx",
    "Hyy",
    "Hyz",
    "Hzx",
    "Hzy",
    "Hzz",
]

# Modos físicos suportados pelo plot_em_profile
PLOT_KINDS: List[str] = [
    "Magnitude + Fase",
    "Re + Im",
    "Magnitude (dB)",
    "Só Re",
    "Só Im",
    "Só Magnitude",
    "Só Fase",
]


# ──────────────────────────────────────────────────────────────────────────
# PlotStyle — parametrização global
# ──────────────────────────────────────────────────────────────────────────


@dataclass
class PlotStyle:
    """Parâmetros de estilo para todas as figuras do Simulation Manager.

    Attributes:
        dpi: Resolução em pontos por polegada (padrão 100). Valores 120–200
            são recomendados para apresentações; 300+ para publicação.
        font_family: Família tipográfica (``"DejaVu Sans"`` por padrão no
            matplotlib, ``"Helvetica"`` em macOS, ``"Arial"`` em Windows).
        font_size: Tamanho base em pontos — títulos/labels escalam a partir
            deste valor.
        line_width: Espessura padrão das linhas de plot (mag, fase, Re, Im).
        grid: Habilita grid de fundo.
        grid_alpha: Transparência do grid (0.0-1.0).
        color_real: Cor das curvas de parte real do tensor H.
        color_imag: Cor das curvas de parte imaginária.
        color_mag: Cor das curvas de magnitude.
        color_phase: Cor das curvas de fase.
        color_rho_h: Cor de ρₕ nos perfis de resistividade.
        color_rho_v: Cor de ρᵥ nos perfis (tracejado).
        color_numba: Cor para curvas Numba em comparação benchmark.
        color_fortran: Cor para marcadores Fortran em comparação.
        color_layer_boundary: Cor das linhas horizontais de interfaces.
        axis_precision: Nº de casas decimais nos ticks dos eixos.
        show_layer_boundaries: Se ``True``, desenha interfaces pontilhadas.
        palette: Nome de paleta matplotlib para curvas multi-freq/multi-TR
            (``"tab10"``, ``"viridis"``, ``"cividis"``, ``"Set1"``...).
        background: Cor de fundo do painel de plot.
        tight_layout: Se ``True``, usa ``constrained_layout=True`` nos axes.
    """

    dpi: int = 100
    font_family: str = "DejaVu Sans"
    font_size: int = 10
    line_width: float = 1.6
    grid: bool = True
    grid_alpha: float = 0.35
    color_real: str = "#1f4ea8"
    color_imag: str = "#a3272f"
    color_mag: str = "#1f4ea8"
    color_phase: str = "#a3272f"
    color_rho_h: str = "#1f77b4"
    color_rho_v: str = "#ff7f0e"
    color_numba: str = "#1f77b4"
    color_fortran: str = "#d62728"
    color_layer_boundary: str = "#7f7f7f"
    axis_precision: int = 4
    show_layer_boundaries: bool = True
    palette: str = "tab10"
    background: str = "#ffffff"
    tight_layout: bool = True

    # ── Customizações adicionais (2026-04-18) ────────────────────────────
    # use_latex: ativa rcParams['text.usetex']. Exige LaTeX instalado
    #   (pdflatex, dvipng). Default False — usuário habilita em Preferências.
    # use_mathtext: sempre renderiza $…$ com fonte Computer Modern do
    #   matplotlib nativo (sem dependência externa). Default True.
    # legend_location / title_location: posicionamento consistente em todos
    #   os plots (legendas e títulos).
    # minor_ticks: ativa eixos menores para leitura mais fina.
    # spine_width: espessura das bordas do axes.
    # line_style: estilo de linha padrão ("-", "--", "-.", ":").
    use_latex: bool = False
    use_mathtext: bool = True
    legend_location: str = "best"
    title_location: str = "center"
    minor_ticks: bool = False
    spine_width: float = 1.0
    line_style: str = "-"
    marker_size: float = 4.0
    marker_style: str = "o"


def apply_style(style: PlotStyle) -> None:
    """Aplica um ``PlotStyle`` globalmente aos rcParams do matplotlib.

    Args:
        style: Instância de ``PlotStyle`` contendo as preferências.

    Note:
        Esta função modifica o estado global do matplotlib. Todas as
        figuras criadas após esta chamada herdam o novo estilo.
    """
    if not _HAS_MPL:
        return
    rc = {
        "figure.dpi": style.dpi,
        "savefig.dpi": max(style.dpi, 150),
        "font.family": style.font_family,
        "font.size": style.font_size,
        "axes.labelsize": style.font_size,
        "axes.titlesize": style.font_size + 1,
        "xtick.labelsize": max(6, style.font_size - 2),
        "ytick.labelsize": max(6, style.font_size - 2),
        "legend.fontsize": max(6, style.font_size - 2),
        "lines.linewidth": style.line_width,
        "lines.linestyle": style.line_style,
        "lines.markersize": style.marker_size,
        "axes.grid": style.grid,
        "grid.alpha": style.grid_alpha,
        "axes.facecolor": style.background,
        "figure.facecolor": style.background,
        "axes.linewidth": style.spine_width,
        "axes.titlelocation": style.title_location,
        "legend.loc": style.legend_location,
        "axes.formatter.use_locale": False,
        "axes.unicode_minus": True,
        "xtick.minor.visible": style.minor_ticks,
        "ytick.minor.visible": style.minor_ticks,
    }
    # LaTeX externo (requer TeX no PATH). Usuário assume responsabilidade
    # de instalar o ambiente. Se o render falhar no runtime, matplotlib
    # emite warnings e o plot ainda funciona com mathtext nativo.
    if style.use_latex:
        rc["text.usetex"] = True
        rc["text.latex.preamble"] = (
            r"\usepackage{amsmath}\usepackage{amssymb}\usepackage{siunitx}"
        )
    else:
        rc["text.usetex"] = False
        # Mathtext nativo (renderização de $…$ com Computer Modern). Ativa
        # mesmo quando use_latex=False para suportar legendas com
        # expressões como r"$\rho_h$", r"$\lambda$".
        rc["mathtext.default"] = "regular" if not style.use_mathtext else "it"
        rc["mathtext.fontset"] = "dejavusans"
    matplotlib.rcParams.update(rc)


# ──────────────────────────────────────────────────────────────────────────
# Canvas Qt-embedded
# ──────────────────────────────────────────────────────────────────────────


class EMCanvas(QtWidgets.QWidget):
    """Canvas matplotlib embutido em ``QWidget`` para uso em abas PyQt.

    Attributes:
        figure: ``matplotlib.figure.Figure`` — acesso direto para customização.
        canvas: ``FigureCanvasQTAgg`` — widget Qt renderizador.
        style: ``PlotStyle`` — cache local (pode ser substituído em tempo
            de execução; a próxima chamada de plot honra o novo estilo).
    """

    def __init__(
        self,
        parent: Optional[QtWidgets.QWidget] = None,
        figsize: Tuple[float, float] = (10, 6),
        style: Optional[PlotStyle] = None,
    ) -> None:
        super().__init__(parent)
        self.style = style or PlotStyle()
        if not _HAS_MPL:
            layout = QtWidgets.QVBoxLayout(self)
            layout.addWidget(
                QtWidgets.QLabel(
                    "matplotlib não instalado — plots desabilitados.\n"
                    "Instale com: pip install matplotlib"
                )
            )
            self.figure = None
            self.canvas = None
            return

        self.figure = Figure(figsize=figsize, constrained_layout=True, dpi=self.style.dpi)
        self.canvas = FigureCanvasQTAgg(self.figure)
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self.canvas)

    def clear(self) -> None:
        """Limpa a figura atual."""
        if self.figure is None:
            return
        self.figure.clear()
        self.canvas.draw_idle()

    def draw(self) -> None:
        """Dispara redesenho imediato."""
        if self.canvas is not None:
            self.canvas.draw_idle()

    def set_style(self, style: PlotStyle) -> None:
        """Atualiza o estilo e o dpi da figura sem recriar o canvas."""
        self.style = style
        if self.figure is not None:
            try:
                self.figure.set_dpi(style.dpi)
                self.figure.set_facecolor(style.background)
            except Exception:
                pass

    def save(self, path: str, dpi: Optional[int] = None) -> None:
        """Salva o conteúdo atual em disco (PNG/PDF/SVG via extensão)."""
        if self.figure is not None:
            self.figure.savefig(
                path,
                dpi=dpi or max(self.style.dpi, 150),
                bbox_inches="tight",
                facecolor=self.style.background,
            )


# ──────────────────────────────────────────────────────────────────────────
# Utilidades internas
# ──────────────────────────────────────────────────────────────────────────


def _boundaries_from_thicknesses(
    thicknesses: Sequence[float], top: float = 0.0
) -> np.ndarray:
    """Gera vetor de topos das interfaces a partir de espessuras das
    camadas internas (n-2 valores para n camadas, conforme convenção
    tatu.x / TIV).
    """
    thick = np.asarray(thicknesses, dtype=np.float64)
    if thick.size == 0:
        return np.array([top], dtype=np.float64)
    bounds = [top]
    for t in thick:
        bounds.append(bounds[-1] + float(t))
    return np.asarray(bounds, dtype=np.float64)


def _draw_layer_boundaries(
    ax: Any, thicknesses: Sequence[float], style: PlotStyle, top: float = 0.0
) -> None:
    """Desenha linhas horizontais finas nas interfaces das camadas.

    Aceita listas, tuplas e ``np.ndarray`` — evita ``bool(array)`` ambíguo.
    """
    if not style.show_layer_boundaries:
        return
    thick_arr = (
        np.asarray(thicknesses, dtype=np.float64)
        if thicknesses is not None
        else np.array([])
    )
    if thick_arr.size == 0:
        return
    bounds = _boundaries_from_thicknesses(thick_arr.tolist(), top=top)
    for b in bounds:
        ax.axhline(
            y=float(b),
            color=style.color_layer_boundary,
            lw=0.6,
            ls="--",
            alpha=0.55,
            zorder=0,
        )


def _axis_formatter(precision: int) -> Any:
    """Formatter matplotlib com `precision` casas decimais e ponto."""
    from matplotlib.ticker import FormatStrFormatter

    return FormatStrFormatter(f"%.{max(0, int(precision))}f")


def _palette_colors(n: int, palette: str) -> List[str]:
    """Retorna ``n`` cores distintas a partir do nome de paleta."""
    if not _HAS_MPL or n <= 0:
        return ["#1f77b4"]
    try:
        cmap = matplotlib.colormaps.get_cmap(palette)
    except Exception:
        cmap = matplotlib.colormaps.get_cmap("tab10")
    if hasattr(cmap, "N") and cmap.N <= 20:
        return [matplotlib.colors.to_hex(cmap(i % cmap.N)) for i in range(n)]
    return [matplotlib.colors.to_hex(cmap(i / max(n - 1, 1))) for i in range(n)]


def _safe_log10(x: np.ndarray) -> np.ndarray:
    """log10 protegido contra zeros (clip em 1e-30)."""
    return np.log10(np.clip(x, 1e-30, None))


# ──────────────────────────────────────────────────────────────────────────
# Plot — perfil de resistividade
# ──────────────────────────────────────────────────────────────────────────


def plot_resistivity_profile(
    canvas: EMCanvas,
    rho_h: Sequence[float],
    rho_v: Sequence[float],
    thicknesses: Sequence[float],
    title: str = "Perfil de Resistividade",
    style: Optional[PlotStyle] = None,
) -> None:
    """Desenha ρₕ/ρᵥ como steps em profundidade (primeira camada no topo)."""
    if canvas.figure is None:
        return
    style = style or canvas.style
    apply_style(style)
    canvas.figure.clear()
    ax = canvas.figure.add_subplot(1, 1, 1)

    rho_h_arr = np.asarray(rho_h, dtype=np.float64)
    rho_v_arr = np.asarray(rho_v, dtype=np.float64)
    thick_arr = np.asarray(thicknesses, dtype=np.float64)

    n = len(rho_h_arr)
    if n >= 3 and len(thick_arr) == n - 2:
        top = 0.0
        boundaries = [top]
        for t in thick_arr:
            boundaries.append(boundaries[-1] + float(t))
        depths = [boundaries[0] - 5.0] + boundaries + [boundaries[-1] + 5.0]
    else:
        depths = np.linspace(0.0, 1.0, n + 1).tolist()

    y_edges = np.array(depths, dtype=np.float64)
    centers = 0.5 * (y_edges[:-1] + y_edges[1:])

    _draw_layer_boundaries(ax, thick_arr, style)
    ax.step(
        rho_h_arr,
        centers,
        where="mid",
        color=style.color_rho_h,
        label=r"$\rho_h$",
        lw=style.line_width + 0.3,
    )
    ax.step(
        rho_v_arr,
        centers,
        where="mid",
        color=style.color_rho_v,
        label=r"$\rho_v$",
        lw=style.line_width + 0.3,
        ls="--",
    )
    ax.set_xscale("log")
    ax.set_xlabel(r"Resistividade ($\Omega\cdot m$)")
    ax.set_ylabel("Profundidade (m)")
    ax.invert_yaxis()
    ax.grid(True, which="both", ls=":", alpha=style.grid_alpha)
    ax.legend(loc="best")
    ax.set_title(title)
    canvas.draw()


# ──────────────────────────────────────────────────────────────────────────
# Plot — Tensor H completo 3×6 Re/Im (grid de referência)
# ──────────────────────────────────────────────────────────────────────────


def plot_tensor_full(
    canvas: EMCanvas,
    H_tensor: np.ndarray,
    z_obs: Optional[np.ndarray],
    freqs: Sequence[float],
    trs: Sequence[float],
    dips: Sequence[float],
    title: str = "Tensor H — componentes Re/Im",
    thicknesses: Optional[Sequence[float]] = None,
    rho_h: Optional[Sequence[float]] = None,
    rho_v: Optional[Sequence[float]] = None,
    style: Optional[PlotStyle] = None,
    include_resistivity: bool = True,
) -> None:
    """Plota o tensor H em grid 3×6 com Re/Im pareados por componente.

    Layout inspirado na figura de referência do pacote (imagem anexa
    pelo usuário): coluna esquerda opcional com perfil de resistividade,
    demais colunas agrupadas em pares (Re, Im) para cada componente
    ``Hxx, Hxy, Hxz, Hyx, Hyy, Hyz, Hzx, Hzy, Hzz``.

    Args:
        canvas: ``EMCanvas`` destino.
        H_tensor: Tensor complexo ``(nTR, nAng, n_pos, nf, 9)``.
        z_obs: Profundidades ``(nAng, n_pos)`` ou ``(n_pos,)``.
        freqs: Frequências (Hz).
        trs: Espaçamentos TR (m).
        dips: Ângulos de dip (graus).
        title: Título principal.
        thicknesses: Espessuras das camadas internas (para linhas guia).
        rho_h, rho_v: Vetores de resistividade (para coluna auxiliar).
        style: Override opcional do ``PlotStyle`` (default = canvas.style).
        include_resistivity: Se ``True`` (e ``rho_h`` fornecido), inclui
            coluna adicional com o perfil de resistividade à esquerda.
    """
    if canvas.figure is None:
        return
    style = style or canvas.style
    apply_style(style)
    canvas.figure.clear()

    H = np.asarray(H_tensor)
    if H.ndim != 5:
        ax = canvas.figure.add_subplot(1, 1, 1)
        ax.text(
            0.5,
            0.5,
            f"H_tensor shape inesperado: {H.shape}",
            ha="center",
            transform=ax.transAxes,
        )
        canvas.draw()
        return

    nTR, nAng, n_pos, nf, _ = H.shape
    have_rho = include_resistivity and rho_h is not None and len(rho_h) > 0

    # Grid: 3 linhas × (1 col. ρ + 6 pares Re/Im = 6 cols × 2 componentes)
    # Implementação: se have_rho, usamos GridSpec com coluna esquerda mais
    # larga. Caso contrário, simplificamos para 3×6 com 2 subplots por célula.
    n_comp_rows = 3  # Hxx/Hxy/Hxz, Hyx/Hyy/Hyz, Hzx/Hzy/Hzz
    pair_cols = 3  # 3 componentes por linha × 2 (Re+Im) = 6 colunas
    total_cols = 2 * pair_cols + (1 if have_rho else 0)

    from matplotlib.gridspec import GridSpec

    width_ratios = (
        [1.4] + [1.0] * (2 * pair_cols) if have_rho else [1.0] * (2 * pair_cols)
    )
    gs = GridSpec(
        n_comp_rows,
        total_cols,
        figure=canvas.figure,
        width_ratios=width_ratios,
        wspace=0.32,
        hspace=0.38,
    )

    # Cores
    c_real = style.color_real
    c_imag = style.color_imag

    # Coluna opcional ρ
    if have_rho:
        ax_rho = canvas.figure.add_subplot(gs[:, 0])
        thick_arr = (
            np.asarray(thicknesses, dtype=np.float64)
            if thicknesses is not None
            else np.array([], dtype=np.float64)
        )
        rh = np.asarray(rho_h, dtype=np.float64)
        rv = np.asarray(rho_v, dtype=np.float64) if rho_v is not None else rh.copy()
        if rh.size >= 3 and thick_arr.size == rh.size - 2:
            bounds = [0.0]
            for t in thick_arr:
                bounds.append(bounds[-1] + float(t))
            depths = [bounds[0] - 5.0] + bounds + [bounds[-1] + 5.0]
        else:
            depths = np.linspace(0.0, 1.0, rh.size + 1).tolist()
        y_edges = np.asarray(depths, dtype=np.float64)
        centers = 0.5 * (y_edges[:-1] + y_edges[1:])
        _draw_layer_boundaries(ax_rho, thick_arr, style)
        ax_rho.step(
            rh,
            centers,
            where="mid",
            color=style.color_rho_h,
            label=r"$\rho_h$",
            lw=style.line_width + 0.2,
        )
        ax_rho.step(
            rv,
            centers,
            where="mid",
            color=style.color_rho_v,
            label=r"$\rho_v$",
            lw=style.line_width + 0.2,
            ls="--",
        )
        ax_rho.set_xscale("log")
        ax_rho.set_xlabel(r"Resistividade ($\Omega\cdot m$)")
        ax_rho.set_ylabel("Profundidade (m)")
        ax_rho.set_title(r"$\rho_h$ e $\rho_v$ (modelo verdadeiro)")
        ax_rho.invert_yaxis()
        ax_rho.grid(True, which="both", ls=":", alpha=style.grid_alpha)
        ax_rho.legend(loc="lower right", fontsize=max(6, style.font_size - 2))

    # Seleciona primeira combinação (iTR=0, iAng=0, ifq=0) para o grid.
    # Usuário altera via controles da aba (_on_plot passa H recortado).
    itr = 0
    iang = 0
    ifq = 0

    if z_obs is None:
        z = np.arange(n_pos, dtype=np.float64)
    elif z_obs.ndim == 2:
        z = z_obs[iang] if z_obs.shape[0] > iang else z_obs[0]
    else:
        z = np.asarray(z_obs, dtype=np.float64)

    thick_arr = (
        np.asarray(thicknesses, dtype=np.float64)
        if thicknesses is not None
        else np.array([], dtype=np.float64)
    )

    comp_order = [
        ["Hxx", "Hxy", "Hxz"],
        ["Hyx", "Hyy", "Hyz"],
        ["Hzx", "Hzy", "Hzz"],
    ]
    for row in range(n_comp_rows):
        for col_pair in range(pair_cols):
            comp_name = comp_order[row][col_pair]
            idx = COMPONENT_NAMES.index(comp_name)
            base_col = (1 if have_rho else 0) + 2 * col_pair
            ax_re = canvas.figure.add_subplot(gs[row, base_col])
            ax_im = canvas.figure.add_subplot(gs[row, base_col + 1])
            H_sel = H[itr, iang, :, ifq, idx]
            _draw_layer_boundaries(ax_re, thick_arr, style)
            _draw_layer_boundaries(ax_im, thick_arr, style)
            ax_re.plot(H_sel.real, z, color=c_real, lw=style.line_width)
            ax_im.plot(H_sel.imag, z, color=c_imag, lw=style.line_width)
            ax_re.set_title(f"Re$({{{comp_name}}})$")
            ax_im.set_title(f"Im$({{{comp_name}}})$")
            ax_re.invert_yaxis()
            ax_im.invert_yaxis()
            ax_re.grid(True, ls=":", alpha=style.grid_alpha)
            ax_im.grid(True, ls=":", alpha=style.grid_alpha)
            ax_re.xaxis.set_major_formatter(_axis_formatter(style.axis_precision))
            ax_im.xaxis.set_major_formatter(_axis_formatter(style.axis_precision))
            if row == n_comp_rows - 1:
                ax_re.set_xlabel("Amplitude")
                ax_im.set_xlabel("Amplitude")

    # Título global: inclui info de TR, dip, f
    try:
        ft = freqs[ifq] / 1e3 if ifq < len(freqs) else 0.0
        lbl = (
            f"{title}  |  TR={trs[itr]:.2f} m  |  "
            f"θ={dips[iang]:g}°  |  f={ft:.1f} kHz"
        )
    except Exception:
        lbl = title
    canvas.figure.suptitle(lbl, fontsize=style.font_size + 2)
    canvas.draw()


# ──────────────────────────────────────────────────────────────────────────
# Plot — EM profile (mag/phase, Re/Im, dB)
# ──────────────────────────────────────────────────────────────────────────


def plot_em_profile(
    canvas: EMCanvas,
    H_tensor: np.ndarray,
    z_obs: Optional[np.ndarray],
    freqs: Sequence[float],
    trs: Sequence[float],
    dips: Sequence[float],
    components: Sequence[str] = ("Hxx", "Hzz"),
    title: str = "Campos EM",
    kind: str = "Magnitude + Fase",
    style: Optional[PlotStyle] = None,
    thicknesses: Optional[Sequence[float]] = None,
) -> None:
    """Plota componentes EM em função da profundidade em múltiplos modos.

    Args:
        kind: Um dos valores em :data:`PLOT_KINDS`. Determina o layout
            (2-col: Magnitude + Fase, ou Re + Im, ou 1-col: só Magnitude / Fase / Re / Im / dB).
    """
    if canvas.figure is None:
        return
    style = style or canvas.style
    apply_style(style)
    canvas.figure.clear()

    H = np.asarray(H_tensor)
    if H.ndim != 5:
        ax = canvas.figure.add_subplot(1, 1, 1)
        ax.text(
            0.5,
            0.5,
            f"H_tensor shape inesperado: {H.shape}",
            ha="center",
            transform=ax.transAxes,
        )
        canvas.draw()
        return

    nTR, nAng, n_pos, nf, _ = H.shape
    n_comp = max(1, len(components))
    # layout de colunas
    two_cols = kind in ("Magnitude + Fase", "Re + Im")
    ncols = 2 if two_cols else 1
    axes = canvas.figure.subplots(n_comp, ncols, squeeze=False)

    comp_idx = {name: i for i, name in enumerate(COMPONENT_NAMES)}
    n_curves = nTR * nAng * nf
    colors = _palette_colors(n_curves, style.palette)
    thick_arr = (
        np.asarray(thicknesses, dtype=np.float64)
        if thicknesses is not None
        else np.array([], dtype=np.float64)
    )

    for row, cname in enumerate(components):
        idx = comp_idx.get(cname, 0)
        ax_a = axes[row][0]
        ax_b = axes[row][1] if two_cols else None
        if thick_arr.size:
            _draw_layer_boundaries(ax_a, thick_arr, style)
            if ax_b is not None:
                _draw_layer_boundaries(ax_b, thick_arr, style)
        curve = 0
        for itr in range(nTR):
            for iang in range(nAng):
                for ifq in range(nf):
                    label = (
                        f"TR={trs[itr]:.2f} m · θ={dips[iang]:g}° · "
                        f"f={freqs[ifq] / 1e3:.1f} kHz"
                    )
                    if z_obs is not None and np.asarray(z_obs).ndim == 2:
                        z = np.asarray(z_obs)[iang]
                    elif z_obs is not None and np.asarray(z_obs).ndim == 1:
                        z = np.asarray(z_obs)
                    else:
                        z = np.arange(n_pos, dtype=np.float64)
                    H_sel = H[itr, iang, :, ifq, idx]
                    mag = np.abs(H_sel)
                    phase = np.degrees(np.angle(H_sel))
                    color = colors[curve % len(colors)]
                    curve += 1
                    if kind == "Magnitude + Fase":
                        ax_a.plot(mag, z, label=label, lw=style.line_width, color=color)
                        ax_b.plot(phase, z, label=label, lw=style.line_width, color=color)
                    elif kind == "Re + Im":
                        ax_a.plot(
                            H_sel.real, z, label=label, lw=style.line_width, color=color
                        )
                        ax_b.plot(
                            H_sel.imag, z, label=label, lw=style.line_width, color=color
                        )
                    elif kind == "Magnitude (dB)":
                        db = 20.0 * _safe_log10(mag)
                        ax_a.plot(db, z, label=label, lw=style.line_width, color=color)
                    elif kind == "Só Re":
                        ax_a.plot(
                            H_sel.real, z, label=label, lw=style.line_width, color=color
                        )
                    elif kind == "Só Im":
                        ax_a.plot(
                            H_sel.imag, z, label=label, lw=style.line_width, color=color
                        )
                    elif kind == "Só Magnitude":
                        ax_a.plot(mag, z, label=label, lw=style.line_width, color=color)
                    elif kind == "Só Fase":
                        ax_a.plot(phase, z, label=label, lw=style.line_width, color=color)

        # Labels e formatação
        if kind == "Magnitude + Fase":
            ax_a.set_xlabel(f"|{cname}| (A/m)")
            ax_a.set_xscale("log")
            ax_b.set_xlabel(f"Fase {cname} (°)")
        elif kind == "Re + Im":
            ax_a.set_xlabel(f"Re({cname})")
            ax_b.set_xlabel(f"Im({cname})")
        elif kind == "Magnitude (dB)":
            ax_a.set_xlabel(f"|{cname}| (dB)")
        elif kind == "Só Re":
            ax_a.set_xlabel(f"Re({cname})")
        elif kind == "Só Im":
            ax_a.set_xlabel(f"Im({cname})")
        elif kind == "Só Magnitude":
            ax_a.set_xlabel(f"|{cname}| (A/m)")
            ax_a.set_xscale("log")
        elif kind == "Só Fase":
            ax_a.set_xlabel(f"Fase {cname} (°)")
        for ax in (ax_a, ax_b):
            if ax is None:
                continue
            ax.set_ylabel("Profundidade (m)")
            ax.invert_yaxis()
            ax.grid(True, ls=":", alpha=style.grid_alpha)
            ax.xaxis.set_major_formatter(_axis_formatter(style.axis_precision))
        if row == 0 and n_curves <= 12:
            ax_a.legend(loc="best", fontsize=max(6, style.font_size - 3))
    canvas.figure.suptitle(title, fontsize=style.font_size + 2)
    canvas.draw()


# ──────────────────────────────────────────────────────────────────────────
# Plot — benchmark compare (Numba vs Fortran)
# ──────────────────────────────────────────────────────────────────────────


def plot_benchmark_compare(
    canvas: EMCanvas,
    H_numba: Optional[np.ndarray],
    H_fortran: Optional[np.ndarray],
    z_obs: Optional[np.ndarray],
    freqs: Sequence[float],
    trs: Sequence[float],
    dips: Sequence[float],
    components: Sequence[str] = ("Hxx", "Hzz"),
    title: str = "Benchmark — Numba vs Fortran",
    style: Optional[PlotStyle] = None,
    thicknesses: Optional[Sequence[float]] = None,
) -> None:
    """Plota sobreposição Numba (linha) vs Fortran (pontos) para comparação."""
    if canvas.figure is None:
        return
    style = style or canvas.style
    apply_style(style)
    canvas.figure.clear()
    H_list: List[Tuple[np.ndarray, str, str, float, Optional[str], str]] = []
    if H_numba is not None:
        H_list.append((H_numba, "Numba", "-", style.line_width, None, style.color_numba))
    if H_fortran is not None:
        H_list.append((H_fortran, "Fortran", "", 0.0, "o", style.color_fortran))
    if not H_list:
        ax = canvas.figure.add_subplot(1, 1, 1)
        ax.text(0.5, 0.5, "Sem dados para comparar.", ha="center", transform=ax.transAxes)
        canvas.draw()
        return

    ref = H_list[0][0]
    if ref.ndim != 5:
        ax = canvas.figure.add_subplot(1, 1, 1)
        ax.text(
            0.5,
            0.5,
            f"Shape H inesperado: {ref.shape}",
            ha="center",
            transform=ax.transAxes,
        )
        canvas.draw()
        return
    nTR, nAng, n_pos, nf, _ = ref.shape
    comp_idx = {name: i for i, name in enumerate(COMPONENT_NAMES)}
    axes = canvas.figure.subplots(len(components), 1, squeeze=False)
    thick_arr = (
        np.asarray(thicknesses, dtype=np.float64)
        if thicknesses is not None
        else np.array([], dtype=np.float64)
    )

    for row, cname in enumerate(components):
        idx = comp_idx.get(cname, 0)
        ax = axes[row][0]
        if thick_arr.size:
            _draw_layer_boundaries(ax, thick_arr, style)
        for H, lbl, ls, lw, mk, color in H_list:
            for itr in range(min(nTR, H.shape[0])):
                for iang in range(min(nAng, H.shape[1])):
                    for ifq in range(min(nf, H.shape[3])):
                        if z_obs is not None and np.asarray(z_obs).ndim == 2:
                            z = np.asarray(z_obs)[iang]
                        elif z_obs is not None and np.asarray(z_obs).ndim == 1:
                            z = np.asarray(z_obs)
                        else:
                            z = np.arange(H.shape[2], dtype=np.float64)
                        mag = np.abs(H[itr, iang, :, ifq, idx])
                        suffix = (
                            f" TR={trs[itr]:.2f} θ={dips[iang]:g}° "
                            f"f={freqs[ifq] / 1e3:.1f}k"
                        )
                        if mk:
                            ax.plot(
                                mag,
                                z,
                                marker=mk,
                                ms=3,
                                ls="none",
                                color=color,
                                label=f"{lbl}{suffix}",
                            )
                        else:
                            ax.plot(
                                mag,
                                z,
                                ls=ls,
                                lw=lw,
                                color=color,
                                label=f"{lbl}{suffix}",
                            )
        ax.set_xlabel(f"|{cname}| (A/m)")
        ax.set_ylabel("Profundidade (m)")
        ax.invert_yaxis()
        ax.set_xscale("log")
        ax.grid(True, ls=":", alpha=style.grid_alpha)
        ax.xaxis.set_major_formatter(_axis_formatter(style.axis_precision))
        if row == 0:
            ax.legend(loc="best", fontsize=max(6, style.font_size - 3), ncol=2)
    canvas.figure.suptitle(title, fontsize=style.font_size + 2)
    canvas.draw()


# ──────────────────────────────────────────────────────────────────────────
# Plot — geosinais USD/UAD/UHR/UHA
# ──────────────────────────────────────────────────────────────────────────


def plot_geosignals(
    canvas: EMCanvas,
    H_tensor: np.ndarray,
    z_obs: Optional[np.ndarray],
    freqs: Sequence[float],
    trs: Sequence[float],
    dips: Sequence[float],
    title: str = "Geosinais (USD / UAD / UHR / UHA)",
    style: Optional[PlotStyle] = None,
    thicknesses: Optional[Sequence[float]] = None,
) -> None:
    """Plota geosinais derivados dos componentes tensoriais.

    Convenção padrão:
      * **USD** = log10(|Hxx| / |Hyy|)   — Up-Side-Detection
      * **UAD** = fase(Hxx) − fase(Hyy)  — phase-shift antisimmetric
      * **UHR** = log10(|Hxz|/|Hzz|)     — harmonic resistivity proxy
      * **UHA** = fase(Hxz) − fase(Hzz)  — harmonic anisotropy
    """
    if canvas.figure is None:
        return
    style = style or canvas.style
    apply_style(style)
    canvas.figure.clear()
    H = np.asarray(H_tensor)
    if H.ndim != 5:
        ax = canvas.figure.add_subplot(1, 1, 1)
        ax.text(
            0.5,
            0.5,
            f"Shape H inesperado: {H.shape}",
            ha="center",
            transform=ax.transAxes,
        )
        canvas.draw()
        return
    nTR, nAng, n_pos, nf, _ = H.shape
    axes = canvas.figure.subplots(2, 2, squeeze=False)
    n_curves = nTR * nAng * nf
    colors = _palette_colors(n_curves, style.palette)
    thick_arr = (
        np.asarray(thicknesses, dtype=np.float64)
        if thicknesses is not None
        else np.array([], dtype=np.float64)
    )

    curve = 0
    for itr in range(nTR):
        for iang in range(nAng):
            for ifq in range(nf):
                if z_obs is not None and np.asarray(z_obs).ndim == 2:
                    z = np.asarray(z_obs)[iang]
                elif z_obs is not None and np.asarray(z_obs).ndim == 1:
                    z = np.asarray(z_obs)
                else:
                    z = np.arange(n_pos, dtype=np.float64)
                Hxx = H[itr, iang, :, ifq, 0]
                Hyy = H[itr, iang, :, ifq, 4]
                Hxz = H[itr, iang, :, ifq, 2]
                Hzz = H[itr, iang, :, ifq, 8]
                lbl = (
                    f"TR={trs[itr]:.2f} θ={dips[iang]:g}° "
                    f"f={freqs[ifq] / 1e3:.1f} kHz"
                )
                color = colors[curve % len(colors)]
                curve += 1
                usd = _safe_log10(np.abs(Hxx) / np.clip(np.abs(Hyy), 1e-30, None))
                uad = np.degrees(np.angle(Hxx) - np.angle(Hyy))
                uhr = _safe_log10(np.abs(Hxz) / np.clip(np.abs(Hzz), 1e-30, None))
                uha = np.degrees(np.angle(Hxz) - np.angle(Hzz))
                axes[0][0].plot(usd, z, label=lbl, lw=style.line_width, color=color)
                axes[0][1].plot(uad, z, label=lbl, lw=style.line_width, color=color)
                axes[1][0].plot(uhr, z, label=lbl, lw=style.line_width, color=color)
                axes[1][1].plot(uha, z, label=lbl, lw=style.line_width, color=color)

    for ax, name in zip(
        [axes[0][0], axes[0][1], axes[1][0], axes[1][1]],
        ["USD", "UAD (°)", "UHR", "UHA (°)"],
    ):
        ax.set_xlabel(name)
        ax.set_ylabel("Profundidade (m)")
        ax.invert_yaxis()
        ax.grid(True, ls=":", alpha=style.grid_alpha)
        ax.xaxis.set_major_formatter(_axis_formatter(style.axis_precision))
        if thick_arr.size:
            _draw_layer_boundaries(ax, thick_arr, style)
    if n_curves <= 12:
        axes[0][0].legend(loc="best", fontsize=max(6, style.font_size - 3))
    canvas.figure.suptitle(title, fontsize=style.font_size + 2)
    canvas.draw()


# ──────────────────────────────────────────────────────────────────────────
# Plot — anisotropia λ = √(ρᵥ/ρₕ)
# ──────────────────────────────────────────────────────────────────────────


def plot_anisotropy(
    canvas: EMCanvas,
    rho_h: Sequence[float],
    rho_v: Sequence[float],
    thicknesses: Sequence[float],
    title: str = "Fator de Anisotropia λ = √(ρᵥ/ρₕ)",
    style: Optional[PlotStyle] = None,
) -> None:
    """Plota o perfil de anisotropia λ em função da profundidade."""
    if canvas.figure is None:
        return
    style = style or canvas.style
    apply_style(style)
    canvas.figure.clear()
    ax = canvas.figure.add_subplot(1, 1, 1)

    rh = np.asarray(rho_h, dtype=np.float64)
    rv = np.asarray(rho_v, dtype=np.float64)
    thick_arr = (
        np.asarray(thicknesses, dtype=np.float64)
        if thicknesses is not None
        else np.array([], dtype=np.float64)
    )
    n = rh.size
    if rv.size != n:
        rv = np.resize(rv, n)
    lam = np.sqrt(np.clip(rv / np.clip(rh, 1e-12, None), 1.0, None))

    if n >= 3 and thick_arr.size == n - 2:
        bounds = [0.0]
        for t in thick_arr:
            bounds.append(bounds[-1] + float(t))
        depths = [bounds[0] - 5.0] + bounds + [bounds[-1] + 5.0]
    else:
        depths = np.linspace(0.0, 1.0, n + 1).tolist()
    y_edges = np.asarray(depths, dtype=np.float64)
    centers = 0.5 * (y_edges[:-1] + y_edges[1:])

    _draw_layer_boundaries(ax, thick_arr, style)
    ax.step(lam, centers, where="mid", color=style.color_rho_v, lw=style.line_width + 0.3)
    ax.set_xlabel(r"$\lambda = \sqrt{\rho_v/\rho_h}$")
    ax.set_ylabel("Profundidade (m)")
    ax.invert_yaxis()
    ax.grid(True, ls=":", alpha=style.grid_alpha)
    ax.set_title(title)
    canvas.draw()


__all__ = [
    "COMPONENT_NAMES",
    "EMCanvas",
    "PLOT_KINDS",
    "PlotStyle",
    "apply_style",
    "plot_anisotropy",
    "plot_benchmark_compare",
    "plot_em_profile",
    "plot_geosignals",
    "plot_resistivity_profile",
    "plot_tensor_full",
]
