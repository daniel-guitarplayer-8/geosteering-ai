# -*- coding: utf-8 -*-
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║  geosteering_ai/simulation/tests/simulation_manager.py                    ║
# ║  ---------------------------------------------------------------------    ║
# ║  Projeto     : Geosteering AI v2.0                                        ║
# ║  Subsistema  : Simulation Manager — GUI PyQt (entrypoint)                 ║
# ║  Autor       : Daniel Leal                                                ║
# ║  Criação     : 2026-04-18                                                 ║
# ║  Atualizado  : 2026-04-18 (dark theme · tabs · experiment dialog)        ║
# ║  Status      : Produção                                                   ║
# ║  Framework   : PyQt6 (fallback PySide6/PyQt5) + matplotlib                ║
# ║  Dependências: numpy, scipy, matplotlib, geosteering_ai.simulation        ║
# ║  ---------------------------------------------------------------------    ║
# ║  FINALIDADE                                                               ║
# ║    Janela principal do Simulation Manager com tema dark (VSCode-         ║
# ║    inspired) e navegação por abas superiores. Ao inicializar, o         ║
# ║    usuário obrigatoriamente cria ou abre um "experimento" — arquivo    ║
# ║    ``*.exp.json`` contendo todos os parâmetros (geometria, geração,     ║
# ║    backend, benchmark, preferências). Após o experimento estar         ║
# ║    carregado, as abas ficam habilitadas.                                ║
# ║                                                                           ║
# ║  ABAS (QTabWidget no topo)                                                ║
# ║    (1) Parâmetros — geometria + filtro Hankel + geração estocástica    ║
# ║    (2) Simulador  — backend, workers sandbox, execução, log            ║
# ║    (3) Benchmark  — Config A/B/C + experimento 30k                      ║
# ║    (4) Resultados — plots + seletor de modelo (simulação ou benchmark) ║
# ║    (5) Preferências — caminhos manuais + plot style + LaTeX             ║
# ║                                                                           ║
# ║  CONFIG C (modelos canônicos)                                             ║
# ║    Cada modelo canônico tem parâmetros próprios (freq/TR/dip) lidos   ║
# ║    de CANONICAL_MODEL_CONFIGS no sm_benchmark, baseados nos scripts     ║
# ║    de validação (bench_numba_vs_fortran_local.py, buildValidamodels.py). ║
# ║    O usuário pode habilitar modelos individualmente e customizar seus   ║
# ║    parâmetros via diálogo dedicado.                                     ║
# ║                                                                           ║
# ║  EXECUÇÃO                                                                 ║
# ║    python -m geosteering_ai.simulation.tests.simulation_manager          ║
# ╚═══════════════════════════════════════════════════════════════════════════╝
"""Simulation Manager — entrypoint GUI PyQt (tema escuro VSCode + tabs).

Programa executável único com tema escuro VSCode-style, navegação por abas
superiores, e sistema de experimentos persistidos em ``.exp.json``.

Example:
    Execução direta::

        $ python -m geosteering_ai.simulation.tests.simulation_manager

Note:
    Requer que pelo menos um binding Qt esteja instalado. Se ausente, o
    programa emite mensagem clara de instalação e termina com exit code 1.
"""
from __future__ import annotations

import json
import os
import platform
import sys
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

from .sm_qt_compat import (
    ALIGN_CENTER,
    ALIGN_RIGHT,
    ALIGN_VCENTER,
    ORIENT_H,
    QT_AVAILABLE,
    QT_BINDING,
    QtCore,
    QtGui,
    QtWidgets,
    Signal,
    check_qt_available,
    enforce_c_locale,
    format_float,
    make_double_spin,
)

if QT_AVAILABLE:
    from .sm_benchmark import (
        CANONICAL_BENCHMARK_MODELS,
        BenchmarkSettings,
        BenchmarkThread,
        BenchRecord,
        default_canonical_config,
    )
    from .sm_io import compute_nmeds_per_angle, write_dat_from_tensor, write_out_file
    from .sm_model_gen import GENERATORS_AVAILABLE, GenConfig, generate_models
    from .sm_plots import (
        COMPONENT_NAMES,
        PLOT_KINDS,
        EMCanvas,
        PlotStyle,
        apply_style,
        plot_anisotropy,
        plot_benchmark_compare,
        plot_em_profile,
        plot_geosignals,
        plot_resistivity_profile,
        plot_tensor_full,
    )
    from .sm_workers import SimRequest, SimulationThread


# ══════════════════════════════════════════════════════════════════════════
# Detecção automática de paths
# ══════════════════════════════════════════════════════════════════════════


def find_geosteering_ai_root(start: Optional[Path] = None) -> Optional[Path]:
    """Busca ascendente por ``geosteering_ai/__init__.py``."""
    start = (start or Path.cwd()).resolve()
    for parent in [start, *start.parents]:
        candidate = parent / "geosteering_ai" / "__init__.py"
        if candidate.is_file():
            return parent / "geosteering_ai"
        if (parent / "__init__.py").is_file() and parent.name == "geosteering_ai":
            return parent
    return None


def find_tatu_binary(start: Optional[Path] = None) -> Optional[Path]:
    """Tenta localizar ``tatu.x`` na árvore do projeto."""
    start = (start or Path.cwd()).resolve()
    for parent in [start, *start.parents]:
        cand = parent / "Fortran_Gerador" / "tatu.x"
        if cand.is_file():
            return cand
    return None


# ══════════════════════════════════════════════════════════════════════════
# QSettings + paths
# ══════════════════════════════════════════════════════════════════════════


def _qsettings() -> Any:
    return QtCore.QSettings("Geosteering AI", "Simulation Manager")


def _bool(v: Any, default: bool = True) -> bool:
    if isinstance(v, bool):
        return v
    if isinstance(v, str):
        return v.strip().lower() in ("1", "true", "yes", "on")
    if isinstance(v, (int, float)):
        return bool(v)
    return default


def load_plot_style() -> PlotStyle:
    s = _qsettings()
    default = PlotStyle()
    try:
        return PlotStyle(
            dpi=int(s.value("plot/dpi", default.dpi)),
            font_family=str(s.value("plot/font_family", default.font_family)),
            font_size=int(s.value("plot/font_size", default.font_size)),
            line_width=float(s.value("plot/line_width", default.line_width)),
            grid=_bool(s.value("plot/grid", default.grid)),
            grid_alpha=float(s.value("plot/grid_alpha", default.grid_alpha)),
            color_real=str(s.value("plot/color_real", default.color_real)),
            color_imag=str(s.value("plot/color_imag", default.color_imag)),
            color_mag=str(s.value("plot/color_mag", default.color_mag)),
            color_phase=str(s.value("plot/color_phase", default.color_phase)),
            color_rho_h=str(s.value("plot/color_rho_h", default.color_rho_h)),
            color_rho_v=str(s.value("plot/color_rho_v", default.color_rho_v)),
            color_numba=str(s.value("plot/color_numba", default.color_numba)),
            color_fortran=str(s.value("plot/color_fortran", default.color_fortran)),
            color_layer_boundary=str(
                s.value("plot/color_layer_boundary", default.color_layer_boundary)
            ),
            axis_precision=int(s.value("plot/axis_precision", default.axis_precision)),
            show_layer_boundaries=_bool(
                s.value("plot/show_layer_boundaries", default.show_layer_boundaries)
            ),
            palette=str(s.value("plot/palette", default.palette)),
            background=str(s.value("plot/background", default.background)),
            tight_layout=_bool(s.value("plot/tight_layout", default.tight_layout)),
            use_latex=_bool(s.value("plot/use_latex", default.use_latex), default=False),
            use_mathtext=_bool(s.value("plot/use_mathtext", default.use_mathtext)),
            legend_location=str(s.value("plot/legend_location", default.legend_location)),
            title_location=str(s.value("plot/title_location", default.title_location)),
            minor_ticks=_bool(
                s.value("plot/minor_ticks", default.minor_ticks), default=False
            ),
            spine_width=float(s.value("plot/spine_width", default.spine_width)),
            line_style=str(s.value("plot/line_style", default.line_style)),
            marker_size=float(s.value("plot/marker_size", default.marker_size)),
            marker_style=str(s.value("plot/marker_style", default.marker_style)),
        )
    except Exception:
        return default


def save_plot_style(style: PlotStyle) -> None:
    s = _qsettings()
    for k, v in asdict(style).items():
        s.setValue(f"plot/{k}", v)


def load_paths() -> Dict[str, str]:
    s = _qsettings()
    detected_pkg = find_geosteering_ai_root()
    detected_tatu = find_tatu_binary()
    return {
        "geosteering_ai": str(
            s.value("paths/geosteering_ai", str(detected_pkg) if detected_pkg else "")
        ),
        "tatu_binary": str(
            s.value("paths/tatu_binary", str(detected_tatu) if detected_tatu else "")
        ),
        "python_binary": str(s.value("paths/python_binary", sys.executable)),
        "output_dir": str(s.value("paths/output_dir", str(Path.cwd() / "sm_output"))),
    }


def save_paths(paths: Dict[str, str]) -> None:
    s = _qsettings()
    for k, v in paths.items():
        s.setValue(f"paths/{k}", v)


# ══════════════════════════════════════════════════════════════════════════
# Experimento (.exp.json)
# ══════════════════════════════════════════════════════════════════════════


@dataclass
class ExperimentState:
    """Estado persistível de um experimento Simulation Manager.

    Attributes:
        name: Nome human-readable do experimento.
        description: Descrição livre.
        created_at: ISO-8601 do instante de criação.
        updated_at: ISO-8601 da última edição.
        file_path: Caminho absoluto do arquivo ``.exp.json``. Pode ser
            vazio se o experimento ainda não foi salvo.
        output_dir: Diretório de saída (artefatos .dat/.out/plots).
        parameters: dict com todos os parâmetros (geometria, geração,
            filtro, benchmark, plot_style). Formato JSON serializável.
    """

    name: str = "Experimento sem título"
    description: str = ""
    created_at: str = ""
    updated_at: str = ""
    file_path: str = ""
    output_dir: str = ""
    parameters: Dict[str, Any] = field(default_factory=dict)

    def to_json(self) -> str:
        """Serializa em JSON indentado (preserva ordem de chaves)."""
        return json.dumps(asdict(self), indent=2, ensure_ascii=False)

    @classmethod
    def from_file(cls, path: str) -> "ExperimentState":
        """Carrega estado de um arquivo ``.exp.json``."""
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return cls(**data)

    def save(self, path: Optional[str] = None) -> str:
        """Salva em disco. Retorna o caminho final utilizado."""
        import datetime

        target = path or self.file_path
        if not target:
            raise ValueError("Caminho do experimento não definido.")
        self.file_path = target
        now = datetime.datetime.now().isoformat(timespec="seconds")
        if not self.created_at:
            self.created_at = now
        self.updated_at = now
        os.makedirs(os.path.dirname(target) or ".", exist_ok=True)
        with open(target, "w", encoding="utf-8") as f:
            f.write(self.to_json())
        return target


# ══════════════════════════════════════════════════════════════════════════
# Stylesheet — Dark theme (VSCode-inspired)
# ══════════════════════════════════════════════════════════════════════════

APP_STYLESHEET = """
/* ═══════════════════════════════════════════════════════════════════
   Dark theme — VSCode-inspired
   Background principal:  #1e1e1e   (editor bg)
   Superficies elevadas:  #252526   (sidebar/panel bg)
   Bordas / separadores:  #3c3c3c
   Texto base:            #d4d4d4
   Texto muted:           #a5a5a5
   Texto apagado:         #858585
   Acento azul:           #007acc   (VSCode blue)
   Acento hover:          #1e8fe6
   Alerta/stop vermelho:  #e5414e
═══════════════════════════════════════════════════════════════════ */

QMainWindow, QDialog, QWidget {
    background: #1e1e1e;
    color: #d4d4d4;
    font-size: 13px;
    selection-background-color: #094771;
    selection-color: #ffffff;
}

QLabel { color: #d4d4d4; background: transparent; }
QLabel[role="heading"] {
    font-size: 16px; font-weight: 600; color: #ffffff;
    padding: 2px 0 6px 0;
}
QLabel[role="section"] {
    font-size: 11px; color: #a5a5a5; letter-spacing: 0.4px;
    text-transform: uppercase; padding: 6px 0 2px 0;
}
QLabel[role="hint"] {
    color: #858585; font-size: 11px; padding: 2px 0;
}

/* ─── Painéis e grupos ─────────────────────────────────────────── */
QWidget#Panel {
    background: #252526; border-radius: 6px;
    border: 1px solid #3c3c3c;
}
QGroupBox {
    background: #252526; border: 1px solid #3c3c3c;
    border-radius: 6px; margin-top: 16px; padding: 10px;
    font-weight: 600; color: #d4d4d4;
}
QGroupBox::title {
    subcontrol-origin: margin; left: 12px; padding: 0 6px;
    color: #a5a5a5;
}

/* ─── Campos de entrada ─────────────────────────────────────────── */
QLineEdit, QDoubleSpinBox, QSpinBox, QPlainTextEdit, QTextEdit {
    background: #1e1e1e; border: 1px solid #3c3c3c;
    border-radius: 4px; padding: 4px 8px; color: #d4d4d4;
    selection-background-color: #264f78; selection-color: #ffffff;
}
QLineEdit:focus, QDoubleSpinBox:focus, QSpinBox:focus,
QComboBox:focus, QPlainTextEdit:focus, QTextEdit:focus {
    border: 1px solid #007acc;
}
QLineEdit:disabled, QDoubleSpinBox:disabled, QSpinBox:disabled,
QComboBox:disabled { color: #6a6a6a; background: #2a2a2a; }

QDoubleSpinBox::up-button, QSpinBox::up-button,
QDoubleSpinBox::down-button, QSpinBox::down-button {
    background: #2d2d2d; border: 1px solid #3c3c3c;
    border-radius: 2px;
}
QDoubleSpinBox::up-arrow, QSpinBox::up-arrow {
    image: none; width: 0; height: 0;
    border-left: 4px solid transparent; border-right: 4px solid transparent;
    border-bottom: 5px solid #d4d4d4;
}
QDoubleSpinBox::down-arrow, QSpinBox::down-arrow {
    image: none; width: 0; height: 0;
    border-left: 4px solid transparent; border-right: 4px solid transparent;
    border-top: 5px solid #d4d4d4;
}

/* ─── ComboBox — garantir contraste e sem clipping de texto ──────── */
QComboBox {
    background: #1e1e1e; border: 1px solid #3c3c3c;
    border-radius: 4px; padding: 5px 30px 5px 10px;     /* padding-right reserva espaço para a seta */
    color: #d4d4d4; min-height: 26px; min-width: 120px;
}
QComboBox:hover { border: 1px solid #007acc; }
QComboBox:on { /* quando a popup está aberta */
    border: 1px solid #007acc; background: #2a2a2a;
}
QComboBox::drop-down {
    subcontrol-origin: padding; subcontrol-position: top right;
    width: 22px; border: none; background: transparent;
}
QComboBox::down-arrow {
    image: none; width: 0; height: 0;
    border-left: 5px solid transparent; border-right: 5px solid transparent;
    border-top: 6px solid #d4d4d4;
    margin-right: 6px;
}
QComboBox::down-arrow:on { border-top-color: #ffffff; }

/* ── CRÍTICO: a lista popup do ComboBox usa QListView internamente.
      Estilizar ambos explicitamente garante legibilidade em Qt5/Qt6. ── */
QComboBox QAbstractItemView,
QComboBox QListView {
    background: #252526; color: #d4d4d4;
    border: 1px solid #3c3c3c; outline: 0;
    selection-background-color: #094771;
    selection-color: #ffffff;
    padding: 2px;
    min-width: 160px;
}
QComboBox QAbstractItemView::item,
QComboBox QListView::item {
    padding: 6px 14px; min-height: 26px;
    color: #d4d4d4; background: transparent;
    border: none;
}
QComboBox QAbstractItemView::item:selected,
QComboBox QListView::item:selected {
    background: #094771; color: #ffffff;
}
QComboBox QAbstractItemView::item:hover,
QComboBox QListView::item:hover {
    background: #37373d; color: #ffffff;
}

/* ─── Botões ─────────────────────────────────────────────────────── */
QPushButton {
    background: #2d2d30; border: 1px solid #3c3c3c;
    border-radius: 4px; padding: 6px 14px; min-height: 22px;
    color: #d4d4d4;
}
QPushButton:hover { background: #37373d; border: 1px solid #007acc; }
QPushButton:pressed { background: #1e1e1e; }
QPushButton:disabled { color: #6a6a6a; background: #262626; border-color: #333; }
QPushButton[role="primary"] {
    background: #007acc; color: #ffffff; border: 1px solid #1c97ea;
    font-weight: 600;
}
QPushButton[role="primary"]:hover { background: #1e8fe6; }
QPushButton[role="primary"]:pressed { background: #005a9e; }
QPushButton[role="primary"]:disabled {
    background: #30475c; color: #8ab9d8; border-color: #2a3f50;
}
QPushButton[role="danger"] {
    background: #e5414e; color: #ffffff; border: 1px solid #b8333e; font-weight: 600;
}
QPushButton[role="danger"]:hover  { background: #f05560; }
QPushButton[role="danger"]:disabled { background: #5a2a2f; color: #b47478; border-color: #3a1d21; }
QPushButton[role="ghost"] {
    background: transparent; color: #a5a5a5; border: 1px solid transparent;
}
QPushButton[role="ghost"]:hover { color: #ffffff; background: #2d2d30; }

/* ─── CheckBox / RadioButton ─────────────────────────────────────── */
QCheckBox, QRadioButton { color: #d4d4d4; background: transparent; spacing: 6px; }
QCheckBox::indicator, QRadioButton::indicator {
    width: 14px; height: 14px;
    background: #1e1e1e; border: 1px solid #666; border-radius: 2px;
}
QCheckBox::indicator:checked {
    background: #007acc; border: 1px solid #007acc;
    image: none;
}
QCheckBox::indicator:hover, QRadioButton::indicator:hover { border: 1px solid #007acc; }
QRadioButton::indicator { border-radius: 7px; }
QRadioButton::indicator:checked { background: #007acc; border: 1px solid #007acc; }

/* ─── Tabs ───────────────────────────────────────────────────────── */
QTabWidget::pane {
    background: #1e1e1e; border: 1px solid #3c3c3c; border-top: 0;
    top: -1px;
}
QTabBar::tab {
    background: #2d2d30; color: #a5a5a5;
    border: 1px solid #3c3c3c; border-bottom: none;
    border-top-left-radius: 4px; border-top-right-radius: 4px;
    padding: 8px 18px; margin-right: 2px; min-width: 120px;
}
QTabBar::tab:selected {
    background: #1e1e1e; color: #ffffff;
    border-bottom: 2px solid #007acc;
}
QTabBar::tab:hover:!selected {
    background: #37373d; color: #d4d4d4;
}
QTabBar::tab:disabled { color: #555555; background: #222222; }

/* ─── Progress & Status ─────────────────────────────────────────── */
QProgressBar {
    border: 1px solid #3c3c3c; border-radius: 4px; height: 14px;
    text-align: center; background: #252526; color: #d4d4d4;
}
QProgressBar::chunk { background: #007acc; border-radius: 3px; }
QStatusBar { background: #007acc; color: #ffffff; border-top: 1px solid #0a6cb4; }
QStatusBar QLabel { color: #ffffff; }

/* ─── Tabela ─────────────────────────────────────────────────────── */
QTableWidget {
    background: #1e1e1e; alternate-background-color: #252526;
    border: 1px solid #3c3c3c; border-radius: 4px;
    gridline-color: #3c3c3c; color: #d4d4d4;
}
QTableWidget::item:selected { background: #094771; color: #ffffff; }
QHeaderView::section {
    background: #2d2d30; color: #d4d4d4; padding: 6px 10px;
    border: none; border-bottom: 1px solid #3c3c3c; font-weight: 600;
}

/* ─── Log ────────────────────────────────────────────────────────── */
QPlainTextEdit#LogView {
    background: #0b0b0b; color: #e6e6e6;
    font-family: "Menlo", "Consolas", "Monaco", monospace;
    font-size: 12px; border-radius: 4px; padding: 8px;
    border: 1px solid #3c3c3c;
}

/* ─── Scroll ─────────────────────────────────────────────────────── */
QScrollArea, QScrollArea > QWidget > QWidget { background: transparent; }
QScrollBar:vertical {
    background: #252526; width: 12px; margin: 4px 2px;
}
QScrollBar::handle:vertical {
    background: #3e3e42; border-radius: 4px; min-height: 28px;
}
QScrollBar::handle:vertical:hover { background: #4e4e52; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0px; }
QScrollBar:horizontal {
    background: #252526; height: 12px; margin: 2px 4px;
}
QScrollBar::handle:horizontal {
    background: #3e3e42; border-radius: 4px; min-width: 28px;
}

/* ─── ToolBar ────────────────────────────────────────────────────── */
QToolBar {
    background: #252526; border-bottom: 1px solid #3c3c3c; spacing: 6px;
    padding: 6px;
}
QToolBar QToolButton {
    padding: 6px 10px; border-radius: 4px; color: #d4d4d4;
}
QToolBar QToolButton:hover { background: #37373d; }

/* ─── ListWidget ─────────────────────────────────────────────────── */
QListWidget {
    background: #1e1e1e; border: 1px solid #3c3c3c; border-radius: 4px;
    color: #d4d4d4; outline: 0;
}
QListWidget::item { padding: 4px 8px; }
QListWidget::item:selected { background: #094771; color: #ffffff; }
QListWidget::item:hover:!selected { background: #2a2d2e; }

/* ─── Splitter ───────────────────────────────────────────────────── */
QSplitter::handle { background: #3c3c3c; }
QSplitter::handle:horizontal { width: 1px; }
QSplitter::handle:vertical   { height: 1px; }

/* ─── Tooltip ────────────────────────────────────────────────────── */
QToolTip {
    background: #252526; color: #d4d4d4;
    border: 1px solid #3c3c3c; padding: 6px 8px;
    border-radius: 4px;
}

/* ─── MessageBox buttons ─────────────────────────────────────────── */
QDialogButtonBox QPushButton { min-width: 80px; }
"""


# ══════════════════════════════════════════════════════════════════════════
# Helpers de UI
# ══════════════════════════════════════════════════════════════════════════


def _qline(default: str = "", placeholder: str = "") -> "QtWidgets.QLineEdit":
    w = QtWidgets.QLineEdit()
    w.setText(default)
    if placeholder:
        w.setPlaceholderText(placeholder)
    return w


def _spin_int(default: int, lo: int, hi: int, step: int = 1) -> "QtWidgets.QSpinBox":
    w = QtWidgets.QSpinBox()
    try:
        c_locale = (
            QtCore.QLocale(QtCore.QLocale.Language.C)
            if hasattr(QtCore.QLocale, "Language")
            else QtCore.QLocale.c()
        )
        try:
            c_locale.setNumberOptions(QtCore.QLocale.NumberOption.OmitGroupSeparator)
        except Exception:
            pass
        w.setLocale(c_locale)
    except Exception:
        pass
    w.setRange(lo, hi)
    w.setSingleStep(step)
    w.setValue(default)
    return w


def _spin_float(
    default: float,
    lo: float,
    hi: float,
    step: float = 0.1,
    decimals: int = 3,
    suffix: str = "",
) -> "QtWidgets.QDoubleSpinBox":
    return make_double_spin(default, lo, hi, step, decimals, suffix)


def _combo(items: List[str], default: Optional[str] = None) -> "QtWidgets.QComboBox":
    """Cria ``QComboBox`` com size adjust policy adequado para evitar clipping.

    - ``AdjustToContents`` força o combo a ter largura suficiente para o maior item.
    - ``setMinimumContentsLength`` garante largura mínima mesmo em listas curtas.
    - View popup herda o stylesheet global (dark com seleção azul).
    """
    w = QtWidgets.QComboBox()
    try:
        policy = getattr(QtWidgets.QComboBox.SizeAdjustPolicy, "AdjustToContents", None)
        if policy is None:
            policy = QtWidgets.QComboBox.AdjustToContents
        w.setSizeAdjustPolicy(policy)
    except Exception:
        pass
    w.setMinimumContentsLength(max(8, max((len(s) for s in items), default=8)))
    for it in items:
        w.addItem(it)
    if default is not None:
        idx = w.findText(default)
        if idx >= 0:
            w.setCurrentIndex(idx)
    return w


def _parse_float_list(text: str, default: List[float]) -> List[float]:
    """Interpreta "1.0, 2.0, 3.0" → [1.0, 2.0, 3.0]; devolve default se vazio."""
    if not text or not text.strip():
        return list(default)
    try:
        raw = text.replace(";", ",")
        parts = [t.strip() for t in raw.split(",") if t.strip()]
        return [float(p) for p in parts]
    except ValueError:
        return list(default)


def _frame_shape(name: str) -> Any:
    shape_enum = getattr(QtWidgets.QFrame, "Shape", None)
    if shape_enum is not None:
        return getattr(shape_enum, name)
    return getattr(QtWidgets.QFrame, name)


def _frame_shadow(name: str) -> Any:
    shadow_enum = getattr(QtWidgets.QFrame, "Shadow", None)
    if shadow_enum is not None:
        return getattr(shadow_enum, name)
    return getattr(QtWidgets.QFrame, name)


def _hsep() -> "QtWidgets.QFrame":
    sep = QtWidgets.QFrame()
    sep.setFrameShape(_frame_shape("HLine"))
    sep.setFrameShadow(_frame_shadow("Sunken"))
    sep.setStyleSheet("color:#3c3c3c;")
    return sep


def _heading(text: str, role: str = "heading") -> "QtWidgets.QLabel":
    lbl = QtWidgets.QLabel(text)
    lbl.setProperty("role", role)
    lbl.setWordWrap(True)
    return lbl


def _centered_form() -> Tuple["QtWidgets.QFormLayout", "QtWidgets.QHBoxLayout"]:
    """Cria um ``QFormLayout`` centralizado horizontalmente.

    Retorna ``(form, outer_hbox)`` — o ``outer_hbox`` deve ser adicionado
    ao layout pai; o ``form`` já vive dentro dele centralizado.
    """
    form = QtWidgets.QFormLayout()
    form.setLabelAlignment(ALIGN_RIGHT)
    form.setFormAlignment(ALIGN_CENTER | ALIGN_VCENTER if ALIGN_CENTER else 0x4)
    form.setHorizontalSpacing(16)
    form.setVerticalSpacing(8)
    outer = QtWidgets.QHBoxLayout()
    outer.addStretch(1)
    wrap = QtWidgets.QWidget()
    wrap.setLayout(form)
    wrap.setMaximumWidth(720)
    outer.addWidget(wrap)
    outer.addStretch(1)
    return form, outer


def _color_for_bg(hex_color: str) -> str:
    try:
        c = hex_color.lstrip("#")
        r, g, b = int(c[0:2], 16), int(c[2:4], 16), int(c[4:6], 16)
        lum = 0.299 * r + 0.587 * g + 0.114 * b
        return "#000000" if lum > 150 else "#ffffff"
    except Exception:
        return "#ffffff"


def _tooltip(widget: Any, text: str) -> None:
    """Aplica tooltip de forma compatível (normaliza wrap em html)."""
    widget.setToolTip(f"<div style='max-width:420px; padding:4px;'>{text}</div>")


# ══════════════════════════════════════════════════════════════════════════
# Dialog — Novo experimento / Abrir
# ══════════════════════════════════════════════════════════════════════════


class NewExperimentDialog(QtWidgets.QDialog):
    """Diálogo para criar um novo experimento ``.exp.json``."""

    def __init__(self, parent: Optional[QtWidgets.QWidget] = None) -> None:
        super().__init__(parent)
        self.setWindowTitle("Novo experimento")
        self.setMinimumWidth(560)
        self._result: Optional[ExperimentState] = None

        form = QtWidgets.QFormLayout()
        form.setLabelAlignment(ALIGN_RIGHT)
        form.setHorizontalSpacing(12)

        self.edit_name = _qline(
            "Experimento " + QtCore.QDate.currentDate().toString("yyyy-MM-dd")
        )
        self.edit_desc = QtWidgets.QPlainTextEdit()
        self.edit_desc.setPlaceholderText(
            "Descrição livre do experimento — objetivo, hipóteses, observações…"
        )
        self.edit_desc.setMaximumHeight(80)

        default_dir = str(Path.cwd() / "sm_experiments")
        self.edit_dir = _qline(default_dir, "Pasta do experimento")
        btn_dir = QtWidgets.QPushButton("Procurar…")
        btn_dir.clicked.connect(self._browse_dir)
        row_dir = QtWidgets.QHBoxLayout()
        row_dir.addWidget(self.edit_dir, 1)
        row_dir.addWidget(btn_dir)
        wrap_dir = QtWidgets.QWidget()
        wrap_dir.setLayout(row_dir)

        form.addRow("Nome:", self.edit_name)
        form.addRow("Descrição:", self.edit_desc)
        form.addRow("Diretório de saída:", wrap_dir)

        btnbox = QtWidgets.QDialogButtonBox()
        btn_ok = btnbox.addButton(
            "Criar experimento", QtWidgets.QDialogButtonBox.ButtonRole.AcceptRole
        )
        btn_cancel = btnbox.addButton(
            "Cancelar", QtWidgets.QDialogButtonBox.ButtonRole.RejectRole
        )
        btn_ok.setProperty("role", "primary")
        btn_ok.clicked.connect(self._on_accept)
        btn_cancel.clicked.connect(self.reject)

        root = QtWidgets.QVBoxLayout(self)
        root.addWidget(_heading("Criar novo experimento"))
        root.addWidget(
            _heading(
                "Um experimento agrupa todos os parâmetros (geometria, filtro, geração, "
                "benchmark, preferências) em um único arquivo .exp.json reabrível.",
                role="section",
            )
        )
        root.addLayout(form)
        root.addWidget(btnbox)

    def _browse_dir(self) -> None:
        path = QtWidgets.QFileDialog.getExistingDirectory(
            self,
            "Selecionar pasta de experimentos",
            self.edit_dir.text() or str(Path.cwd()),
        )
        if path:
            self.edit_dir.setText(path)

    def _on_accept(self) -> None:
        name = self.edit_name.text().strip() or "experimento_sem_nome"
        dir_path = self.edit_dir.text().strip() or str(Path.cwd() / "sm_experiments")
        os.makedirs(dir_path, exist_ok=True)
        # Slug do nome para o arquivo
        slug = "".join(c if c.isalnum() or c in "_-" else "_" for c in name).strip("_")
        file_path = os.path.join(dir_path, f"{slug or 'experimento'}.exp.json")
        exp = ExperimentState(
            name=name,
            description=self.edit_desc.toPlainText().strip(),
            file_path=file_path,
            output_dir=dir_path,
        )
        try:
            exp.save(file_path)
        except Exception as e:
            QtWidgets.QMessageBox.critical(self, "Falha ao salvar", str(e))
            return
        self._result = exp
        self.accept()

    def result_state(self) -> Optional[ExperimentState]:
        return self._result


# ══════════════════════════════════════════════════════════════════════════
# Welcome — tela inicial (bloqueia acesso até experimento carregado)
# ══════════════════════════════════════════════════════════════════════════


class WelcomeWidget(QtWidgets.QWidget):
    """Tela de boas-vindas exibida antes do experimento ser criado/aberto."""

    request_new = Signal()
    request_open = Signal()

    def __init__(self, parent: Optional[QtWidgets.QWidget] = None) -> None:
        super().__init__(parent)
        lbl_title = QtWidgets.QLabel("Simulation Manager")
        lbl_title.setStyleSheet(
            "font-size: 28px; font-weight: 600; color: #ffffff; padding: 8px 0;"
        )
        lbl_subtitle = QtWidgets.QLabel(
            "Geosteering AI v2.0 · Python Numba JIT + Fortran tatu.x"
        )
        lbl_subtitle.setStyleSheet("color: #a5a5a5; font-size: 14px;")
        lbl_info = QtWidgets.QLabel(
            "Para começar, crie um novo experimento ou abra um existente. Cada experimento "
            "salva todos os parâmetros (geometria, filtro, geração, benchmark, preferências) "
            "em um arquivo <code>.exp.json</code> reabrível e versionável."
        )
        lbl_info.setWordWrap(True)
        lbl_info.setStyleSheet("color: #d4d4d4; font-size: 13px; padding: 10px 0;")

        btn_new = QtWidgets.QPushButton("➕   Novo experimento")
        btn_new.setProperty("role", "primary")
        btn_new.setMinimumHeight(48)
        btn_new.setStyleSheet("font-size: 14px;")
        btn_new.clicked.connect(self.request_new.emit)

        btn_open = QtWidgets.QPushButton("📂   Abrir experimento…")
        btn_open.setMinimumHeight(48)
        btn_open.setStyleSheet("font-size: 14px;")
        btn_open.clicked.connect(self.request_open.emit)

        # Recentes (se houver)
        recents = self._load_recents()
        box_recents = QtWidgets.QGroupBox("Experimentos recentes")
        rec_layout = QtWidgets.QVBoxLayout(box_recents)
        if recents:
            for path in recents[:8]:
                btn = QtWidgets.QPushButton(f"🗂  {Path(path).name}   —   {path}")
                btn.setProperty("role", "ghost")
                btn.setStyleSheet("text-align:left; color:#d4d4d4;")
                btn.clicked.connect(lambda _=False, p=path: self._open_path(p))
                rec_layout.addWidget(btn)
        else:
            rec_layout.addWidget(QtWidgets.QLabel("(nenhum experimento recente)"))

        root = QtWidgets.QVBoxLayout(self)
        root.setContentsMargins(60, 50, 60, 50)
        root.setSpacing(10)
        root.addWidget(lbl_title)
        root.addWidget(lbl_subtitle)
        root.addWidget(lbl_info)
        row_btns = QtWidgets.QHBoxLayout()
        row_btns.addWidget(btn_new)
        row_btns.addWidget(btn_open)
        row_btns.addStretch(1)
        root.addLayout(row_btns)
        root.addSpacing(20)
        root.addWidget(box_recents)
        root.addStretch(1)

    def _load_recents(self) -> List[str]:
        s = _qsettings()
        raw = s.value("experiment/recents", [])
        if isinstance(raw, str):
            return [raw] if raw else []
        try:
            return [str(x) for x in raw if x]
        except Exception:
            return []

    def _open_path(self, path: str) -> None:
        # emitido via attribute hack — parent ouvirá
        self.property_selected_path = path
        self.request_open.emit()


def _push_recent(path: str) -> None:
    s = _qsettings()
    raw = s.value("experiment/recents", [])
    if isinstance(raw, str):
        recents = [raw] if raw else []
    else:
        try:
            recents = [str(x) for x in raw if x]
        except Exception:
            recents = []
    recents = [p for p in recents if p != path]
    recents.insert(0, path)
    s.setValue("experiment/recents", recents[:10])


# ══════════════════════════════════════════════════════════════════════════
# Aba 1 — Parâmetros (centralizada + tooltips)
# ══════════════════════════════════════════════════════════════════════════


class ParametersPage(QtWidgets.QWidget):
    """Página de parâmetros da simulação e geração estocástica (centralizada)."""

    def __init__(self, parent: Optional[QtWidgets.QWidget] = None) -> None:
        super().__init__(parent)

        # ═══ Grupo 1 — Geometria da Ferramenta ═══════════════════════════
        grp_geom = QtWidgets.QGroupBox("Geometria da Ferramenta")
        form_geom, wrap_geom = _centered_form()

        self.spin_nf = _spin_int(1, 1, 32)
        self.spin_nang = _spin_int(1, 1, 32)
        self.spin_ntr = _spin_int(1, 1, 32)
        self.edit_freqs = _qline("20000", "Ex.: 20000, 40000")
        self.edit_angles = _qline("0", "Ex.: 0, 30, 60")
        self.edit_trs = _qline("1.0", "Ex.: 0.5, 1.0, 1.5")
        self.spin_h1 = _spin_float(10.0, 0.1, 500.0, 0.5, 3, " m")
        self.spin_tj = _spin_float(120.0, 1.0, 5000.0, 1.0, 2, " m")
        self.spin_pmed = _spin_float(0.2, 0.01, 10.0, 0.01, 3, " m")

        _tooltip(
            self.spin_nf,
            (
                "<b>Número de frequências (nf)</b><br/>"
                "Quantidade de frequências a serem propagadas no mesmo modelo. "
                "Deve corresponder ao comprimento da lista em 'Frequências (Hz)'. "
                "Usado para simulações multi-espectrais e compensação de fase."
            ),
        )
        _tooltip(
            self.spin_nang,
            (
                "<b>Número de ângulos (ntheta)</b><br/>"
                "Quantidade de ângulos de dip (inclinação relativa do poço em relação "
                "às camadas). Cada ângulo multiplica o custo da simulação."
            ),
        )
        _tooltip(
            self.spin_ntr,
            (
                "<b>Número de pares Transmissor–Receptor (TR)</b><br/>"
                "Quantidade de configurações geométricas T-R distintas a serem "
                "calculadas. Reside no primeiro eixo do tensor H de saída."
            ),
        )
        _tooltip(
            self.edit_freqs,
            (
                "<b>Frequências operacionais do LWD (Hz)</b><br/>"
                "Lista separada por vírgulas. Exemplos típicos da indústria: "
                "400 Hz, 2 kHz, 6 kHz, 20 kHz, 40 kHz, 100 kHz, 400 kHz, 2 MHz. "
                "Maior frequência → maior sensibilidade a camadas finas, menor profundidade."
            ),
        )
        _tooltip(
            self.edit_angles,
            (
                "<b>Ângulos de dip (graus)</b><br/>"
                "Inclinação do poço relativa à normal das camadas. 0° = perfil vertical (atravessa perpendicular); "
                "90° = perfil horizontal (paralelo às camadas). Lista separada por vírgulas."
            ),
        )
        _tooltip(
            self.edit_trs,
            (
                "<b>Espaçamentos Transmissor–Receptor (m)</b><br/>"
                "Lista separada por vírgulas. Valores típicos: 0.5 m (short), 1 m, 1.5 m, "
                "8.19 m, 20.43 m (deep). TR maior → maior profundidade de investigação, "
                "menor resolução vertical."
            ),
        )
        _tooltip(
            self.spin_h1,
            (
                "<b>Altura h1 (m) — topo do eixo de medição</b><br/>"
                "Distância do primeiro ponto-médio T-R até a primeira interface "
                "geológica. Em buildValidamodels.py é computada como "
                "(tj − Σespessuras)/2 para centralizar as medidas."
            ),
        )
        _tooltip(
            self.spin_tj,
            (
                "<b>Janela de investigação tj (m)</b><br/>"
                "Extensão total do eixo de medição ao longo do poço. Combinada com "
                "p_med, define n_pos = ⌈tj / (p_med · cos(dip))⌉ posições."
            ),
        )
        _tooltip(
            self.spin_pmed,
            (
                "<b>Passo entre medidas p_med (m)</b><br/>"
                "Distância entre posições consecutivas do ponto-médio T-R. "
                "Amostragem típica: 0.1 m (fina), 0.2 m (padrão), 0.5 m (rápida)."
            ),
        )

        form_geom.addRow("Nº de frequências (nf):", self.spin_nf)
        form_geom.addRow("Nº de ângulos (ntheta):", self.spin_nang)
        form_geom.addRow("Nº de pares T-R:", self.spin_ntr)
        form_geom.addRow("Frequências (Hz):", self.edit_freqs)
        form_geom.addRow("Ângulos de dip (graus):", self.edit_angles)
        form_geom.addRow("Espaçamentos T-R (m):", self.edit_trs)
        form_geom.addRow("Altura h1:", self.spin_h1)
        form_geom.addRow("Janela de investigação tj:", self.spin_tj)
        form_geom.addRow("Passo entre medidas p_med:", self.spin_pmed)

        layout_geom = QtWidgets.QVBoxLayout(grp_geom)
        layout_geom.addLayout(wrap_geom)

        # ═══ Grupo 2 — Geração Estocástica ═══════════════════════════════
        grp_gen = QtWidgets.QGroupBox("Geração Estocástica de Modelos")
        form_gen, wrap_gen = _centered_form()

        self.spin_nmodels = _spin_int(2000, 1, 10_000_000, 100)
        self.combo_generator = QtWidgets.QComboBox()
        for g in GENERATORS_AVAILABLE:
            self.combo_generator.addItem(g)
        self.combo_generator.setCurrentText("sobol")
        self.check_aniso = QtWidgets.QCheckBox("Perfil anisotrópico (TIV)")
        self.check_aniso.setChecked(True)
        self.spin_lambda_min = _spin_float(1.0, 1.0, 5.0, 0.05, 3)
        self.spin_lambda_max = _spin_float(1.4142, 1.0, 5.0, 0.05, 4)
        self.spin_rho_min = _spin_float(1.0, 0.001, 1e6, 1.0, 3, " Ω·m")
        self.spin_rho_max = _spin_float(1800.0, 0.001, 1e6, 10.0, 3, " Ω·m")
        self.combo_rho_distr = QtWidgets.QComboBox()
        self.combo_rho_distr.addItems(["loguni", "uniform"])
        self.spin_min_thick = _spin_float(0.5, 0.01, 100.0, 0.1, 2, " m")
        self.spin_nlayers_min = _spin_int(3, 3, 200)
        self.spin_nlayers_max = _spin_int(31, 3, 200)
        self.spin_nlayers_fixed = _spin_int(0, 0, 200)

        _tooltip(
            self.spin_nmodels,
            (
                "<b>Quantidade de modelos</b><br/>"
                "Total de perfis geológicos estocásticos a gerar. Cada perfil será "
                "simulado independentemente. Valores típicos: 100–30 000."
            ),
        )
        _tooltip(
            self.combo_generator,
            (
                "<b>Gerador de números aleatórios</b><br/>"
                "• <b>sobol</b> (★ padrão): QMC de baixa discrepância (scipy.qmc.Sobol), "
                "melhor cobertura espacial de perfis. Recomendado para ML.<br/>"
                "• <b>halton</b>: QMC base-prima.<br/>"
                "• <b>niederreiter</b>: aproximado via Halton.<br/>"
                "• <b>mersenne_twister</b>: PRNG clássico NumPy.<br/>"
                "• <b>uniform</b>: alias PRNG U[0,1].<br/>"
                "• <b>normal</b>: PRNG log-normal mapeado via CDF.<br/>"
                "• <b>box_muller</b>: transformação analítica U→N."
            ),
        )
        _tooltip(
            self.check_aniso,
            (
                "<b>Perfil anisotrópico (TIV)</b><br/>"
                "Se ativo, aplica ρᵥ = λ²·ρₕ com λ sorteado em [λ_min, λ_max]. "
                "Se inativo, força ρᵥ = ρₕ (perfil isotrópico)."
            ),
        )
        _tooltip(
            self.spin_lambda_min,
            (
                "<b>Fator de anisotropia λ mínimo</b><br/>"
                "Limite inferior de λ = √(ρᵥ/ρₕ). Deve ser ≥ 1.0 para respeitar "
                "a física TIV (ρᵥ ≥ ρₕ em camadas laminadas)."
            ),
        )
        _tooltip(
            self.spin_lambda_max,
            (
                "<b>Fator de anisotropia λ máximo</b><br/>"
                "Limite superior de λ. Valores típicos: 1.4 (fraca), 1.7 (moderada), "
                "2.0+ (forte). √2 ≈ 1.4142 é o padrão de benchmarks."
            ),
        )
        _tooltip(
            self.spin_rho_min,
            (
                "<b>Resistividade horizontal ρₕ mínima (Ω·m)</b><br/>"
                "Limite inferior da distribuição. Valores típicos: 0.3 Ω·m (água salgada), "
                "1–10 (folhelhos), 10–100 (arenitos saturados)."
            ),
        )
        _tooltip(
            self.spin_rho_max,
            (
                "<b>Resistividade horizontal ρₕ máxima (Ω·m)</b><br/>"
                "Limite superior. Valores típicos: 1 000 (HC convencional), 10 000+ (tight gas)."
            ),
        )
        _tooltip(
            self.combo_rho_distr,
            (
                "<b>Distribuição de ρₕ</b><br/>"
                "• <b>loguni</b> (padrão): log-uniforme em [min, max] — cobre várias "
                "ordens de magnitude igualmente.<br/>"
                "• <b>uniform</b>: uniforme linear — concentra massa nos valores altos."
            ),
        )
        _tooltip(
            self.spin_min_thick,
            (
                "<b>Espessura mínima por camada (m)</b><br/>"
                "Piso mínimo para cada camada interna, aplicado após o stick-breaking. "
                "Evita camadas degeneradas (<< λ/4 do filtro Hankel)."
            ),
        )
        _tooltip(
            self.spin_nlayers_min,
            (
                "<b>Número mínimo de camadas (inclui os 2 semi-espaços)</b><br/>"
                "Sorteio uniforme de n_camadas em [min, max] quando 'Nº camadas fixo' = 0."
            ),
        )
        _tooltip(
            self.spin_nlayers_max,
            (
                "<b>Número máximo de camadas</b><br/>"
                "Limite superior da amostragem uniforme de n_camadas."
            ),
        )
        _tooltip(
            self.spin_nlayers_fixed,
            (
                "<b>Nº de camadas fixo (0 = automático)</b><br/>"
                "Se ≥ 3, força todos os perfis a terem exatamente esse número de camadas. "
                "Se 0, sorteia uniformemente em [min, max]."
            ),
        )

        form_gen.addRow("Quantidade de modelos:", self.spin_nmodels)
        form_gen.addRow("Gerador aleatório:", self.combo_generator)
        form_gen.addRow("", self.check_aniso)
        form_gen.addRow("λ mínimo (TIV):", self.spin_lambda_min)
        form_gen.addRow("λ máximo (TIV):", self.spin_lambda_max)
        form_gen.addRow("ρₕ mínimo:", self.spin_rho_min)
        form_gen.addRow("ρₕ máximo:", self.spin_rho_max)
        form_gen.addRow("Distribuição de ρₕ:", self.combo_rho_distr)
        form_gen.addRow("Espessura mínima:", self.spin_min_thick)
        form_gen.addRow("Nº camadas mínimo:", self.spin_nlayers_min)
        form_gen.addRow("Nº camadas máximo:", self.spin_nlayers_max)
        form_gen.addRow("Nº camadas fixo:", self.spin_nlayers_fixed)

        layout_gen = QtWidgets.QVBoxLayout(grp_gen)
        layout_gen.addLayout(wrap_gen)

        # ═══ Grupo 3 — Filtro Hankel ═════════════════════════════════════
        grp_filt = QtWidgets.QGroupBox("Filtros de Hankel")
        form_filt, wrap_filt = _centered_form()
        self.combo_filter = QtWidgets.QComboBox()
        self.combo_filter.addItems(["werthmuller_201pt", "kong_61pt", "anderson_801pt"])
        _tooltip(
            self.combo_filter,
            (
                "<b>Filtro Hankel (transformada inversa J₀/J₁)</b><br/>"
                "Converte kernel espectral ↔ domínio espacial via quadratura log-espaçada.<br/>"
                "• <b>werthmuller_201pt</b> (★ padrão): precisão alta, 201 pontos.<br/>"
                "• <b>kong_61pt</b>: 3.3× mais rápido, precisão moderada (~1e-6).<br/>"
                "• <b>anderson_801pt</b>: precisão máxima (~1e-12), 4× mais lento."
            ),
        )
        form_filt.addRow("Filtro Hankel:", self.combo_filter)
        layout_filt = QtWidgets.QVBoxLayout(grp_filt)
        layout_filt.addLayout(wrap_filt)

        # ═══ Layout raiz ═════════════════════════════════════════════════
        root = QtWidgets.QVBoxLayout()
        root.setContentsMargins(20, 16, 20, 16)
        root.setSpacing(14)
        root.addWidget(_heading("Parâmetros da Simulação"))
        root.addWidget(
            _heading(
                "Configure a geometria da ferramenta LWD, o filtro Hankel e os "
                "parâmetros de geração estocástica de perfis TIV. Passe o mouse "
                "sobre cada campo para ver uma explicação detalhada.",
                role="section",
            )
        )
        root.addWidget(grp_geom)
        root.addWidget(grp_gen)
        root.addWidget(grp_filt)
        root.addStretch(1)

        container = QtWidgets.QWidget()
        container.setLayout(root)
        scroll = QtWidgets.QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(_frame_shape("NoFrame"))
        scroll.setWidget(container)

        outer = QtWidgets.QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.addWidget(scroll)

    # API pública
    def collect_freqs(self) -> List[float]:
        return _parse_float_list(self.edit_freqs.text(), [20000.0])[
            : self.spin_nf.value()
        ]

    def collect_angles(self) -> List[float]:
        return _parse_float_list(self.edit_angles.text(), [0.0])[: self.spin_nang.value()]

    def collect_trs(self) -> List[float]:
        return _parse_float_list(self.edit_trs.text(), [1.0])[: self.spin_ntr.value()]

    def build_gen_config(self) -> GenConfig:
        fixed = self.spin_nlayers_fixed.value()
        return GenConfig(
            total_depth=float(self.spin_tj.value()),
            n_layers_min=int(self.spin_nlayers_min.value()),
            n_layers_max=int(self.spin_nlayers_max.value()) + 1,
            n_layers_fixed=int(fixed) if fixed >= 3 else None,
            rho_h_min=float(self.spin_rho_min.value()),
            rho_h_max=float(self.spin_rho_max.value()),
            rho_h_distribution=self.combo_rho_distr.currentText(),
            anisotropic=bool(self.check_aniso.isChecked()),
            lambda_min=float(self.spin_lambda_min.value()),
            lambda_max=float(self.spin_lambda_max.value()),
            min_thickness=float(self.spin_min_thick.value()),
            generator=self.combo_generator.currentText(),
        )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "nf": self.spin_nf.value(),
            "nang": self.spin_nang.value(),
            "ntr": self.spin_ntr.value(),
            "freqs": self.edit_freqs.text(),
            "angles": self.edit_angles.text(),
            "trs": self.edit_trs.text(),
            "h1": self.spin_h1.value(),
            "tj": self.spin_tj.value(),
            "p_med": self.spin_pmed.value(),
            "n_models": self.spin_nmodels.value(),
            "generator": self.combo_generator.currentText(),
            "aniso": self.check_aniso.isChecked(),
            "lambda_min": self.spin_lambda_min.value(),
            "lambda_max": self.spin_lambda_max.value(),
            "rho_min": self.spin_rho_min.value(),
            "rho_max": self.spin_rho_max.value(),
            "rho_distr": self.combo_rho_distr.currentText(),
            "min_thick": self.spin_min_thick.value(),
            "nlayers_min": self.spin_nlayers_min.value(),
            "nlayers_max": self.spin_nlayers_max.value(),
            "nlayers_fixed": self.spin_nlayers_fixed.value(),
            "filter": self.combo_filter.currentText(),
        }

    def from_dict(self, d: Dict[str, Any]) -> None:
        if not d:
            return
        try:
            self.spin_nf.setValue(int(d.get("nf", 1)))
            self.spin_nang.setValue(int(d.get("nang", 1)))
            self.spin_ntr.setValue(int(d.get("ntr", 1)))
            self.edit_freqs.setText(str(d.get("freqs", "20000")))
            self.edit_angles.setText(str(d.get("angles", "0")))
            self.edit_trs.setText(str(d.get("trs", "1.0")))
            self.spin_h1.setValue(float(d.get("h1", 10.0)))
            self.spin_tj.setValue(float(d.get("tj", 120.0)))
            self.spin_pmed.setValue(float(d.get("p_med", 0.2)))
            self.spin_nmodels.setValue(int(d.get("n_models", 2000)))
            self.combo_generator.setCurrentText(d.get("generator", "sobol"))
            self.check_aniso.setChecked(bool(d.get("aniso", True)))
            self.spin_lambda_min.setValue(float(d.get("lambda_min", 1.0)))
            self.spin_lambda_max.setValue(float(d.get("lambda_max", 1.4142)))
            self.spin_rho_min.setValue(float(d.get("rho_min", 1.0)))
            self.spin_rho_max.setValue(float(d.get("rho_max", 1800.0)))
            self.combo_rho_distr.setCurrentText(d.get("rho_distr", "loguni"))
            self.spin_min_thick.setValue(float(d.get("min_thick", 0.5)))
            self.spin_nlayers_min.setValue(int(d.get("nlayers_min", 3)))
            self.spin_nlayers_max.setValue(int(d.get("nlayers_max", 31)))
            self.spin_nlayers_fixed.setValue(int(d.get("nlayers_fixed", 0)))
            self.combo_filter.setCurrentText(d.get("filter", "werthmuller_201pt"))
        except Exception:
            pass


# ══════════════════════════════════════════════════════════════════════════
# Aba 2 — Simulador (merged save checkbox + fix stop/start)
# ══════════════════════════════════════════════════════════════════════════


class SimulatorPage(QtWidgets.QWidget):
    """Página de escolha do backend, paralelismo e execução."""

    request_start = Signal()
    request_stop = Signal()

    def __init__(self, parent: Optional[QtWidgets.QWidget] = None) -> None:
        super().__init__(parent)
        ncpu = os.cpu_count() or 8

        grp_backend = QtWidgets.QGroupBox("Backend")
        form_bk = QtWidgets.QFormLayout(grp_backend)
        form_bk.setLabelAlignment(ALIGN_RIGHT)
        self.combo_backend = QtWidgets.QComboBox()
        self.combo_backend.addItems(["numba", "fortran"])
        _tooltip(
            self.combo_backend,
            (
                "<b>Backend do simulador</b><br/>"
                "• <b>numba</b>: Python JIT-compilado com AOT cache. Mais rápido em lote grande "
                "(warmup único por worker). Exporta .dat/.out.<br/>"
                "• <b>fortran</b>: tatu.x legado OpenMP. Cada modelo reescreve model.in + subprocess."
            ),
        )
        self.lbl_fortran_path = QtWidgets.QLabel("(definido em Preferências)")
        self.lbl_python_path = QtWidgets.QLabel(sys.executable)
        for lbl in (self.lbl_fortran_path, self.lbl_python_path):
            lbl.setStyleSheet("color:#a5a5a5; font-family:Menlo, Consolas, monospace;")
        form_bk.addRow("Simulador selecionado:", self.combo_backend)
        form_bk.addRow("Binário Fortran (tatu.x):", self.lbl_fortran_path)
        form_bk.addRow("Interpretador Python:", self.lbl_python_path)

        grp_par = QtWidgets.QGroupBox(
            "Paralelismo — Central Master-Plan · Parallel Execution"
        )
        par_form = QtWidgets.QFormLayout(grp_par)
        par_form.setLabelAlignment(ALIGN_RIGHT)
        self.spin_workers = _spin_int(max(1, ncpu // 4), 1, 256)
        self.spin_threads = _spin_int(max(2, ncpu // max(1, ncpu // 4)), 1, 256)
        _tooltip(
            self.spin_workers,
            (
                "<b>Nº de workers sandbox</b><br/>"
                "Processos isolados executados em paralelo (ProcessPoolExecutor). Cada worker "
                "tem seu próprio warmup JIT (Numba) ou cópia do tatu.x (Fortran)."
            ),
        )
        _tooltip(
            self.spin_threads,
            (
                "<b>Nº de threads por worker</b><br/>"
                "Define NUMBA_NUM_THREADS/OMP_NUM_THREADS dentro do subprocesso. "
                "Workers × Threads ≤ nº de CPU lógicas recomendado."
            ),
        )
        self.lbl_ncpu = QtWidgets.QLabel(
            f"CPU cores disponíveis: {ncpu}   |   Sistema: {platform.system()} {platform.release()}"
        )
        par_form.addRow("Nº de workers sandbox:", self.spin_workers)
        par_form.addRow("Nº de threads por worker:", self.spin_threads)
        par_form.addRow("", self.lbl_ncpu)

        grp_out = QtWidgets.QGroupBox("Saída")
        out_form = QtWidgets.QFormLayout(grp_out)
        out_form.setLabelAlignment(ALIGN_RIGHT)
        self.edit_output_dir = _qline("", "Diretório de saída")
        self.btn_browse_out = QtWidgets.QPushButton("Procurar…")
        self.btn_browse_out.clicked.connect(self._browse_out)
        row_out = QtWidgets.QHBoxLayout()
        row_out.addWidget(self.edit_output_dir, 1)
        row_out.addWidget(self.btn_browse_out)
        wrap_out = QtWidgets.QWidget()
        wrap_out.setLayout(row_out)

        # ── Checkbox única (.dat + .out) ────────────────────────────────
        self.check_save_artifacts = QtWidgets.QCheckBox(
            "Salvar artefatos Fortran-compat (.dat binário 22-col + .out ASCII)"
        )
        self.check_save_artifacts.setChecked(True)
        _tooltip(
            self.check_save_artifacts,
            (
                "<b>Salvar .dat + .out</b><br/>"
                "Por convenção do Geosteering AI, o .dat (binário 22 colunas) só é "
                "útil quando acompanhado do .out (metadados ASCII homônimo). Esta "
                "opção salva os dois arquivos juntos. Ativada por padrão."
            ),
        )
        out_form.addRow("Diretório:", wrap_out)
        out_form.addRow("", self.check_save_artifacts)

        grp_exec = QtWidgets.QGroupBox("Execução")
        exec_row = QtWidgets.QHBoxLayout(grp_exec)
        self.btn_start = QtWidgets.QPushButton("▶  Iniciar Simulação")
        self.btn_start.setProperty("role", "primary")
        self.btn_stop = QtWidgets.QPushButton("■  Parar")
        self.btn_stop.setProperty("role", "danger")
        self.btn_stop.setEnabled(False)
        self.progress = QtWidgets.QProgressBar()
        self.progress.setRange(0, 100)
        self.lbl_throughput = QtWidgets.QLabel("Throughput: — mod/h")
        self.lbl_throughput.setStyleSheet("font-weight:600; color:#ffffff;")
        exec_row.addWidget(self.btn_start)
        exec_row.addWidget(self.btn_stop)
        exec_row.addWidget(self.progress, 1)
        exec_row.addWidget(self.lbl_throughput)
        self.btn_start.clicked.connect(self.request_start.emit)
        self.btn_stop.clicked.connect(self.request_stop.emit)

        self.log_view = QtWidgets.QPlainTextEdit()
        self.log_view.setObjectName("LogView")
        self.log_view.setReadOnly(True)
        self.log_view.setPlaceholderText("Log de execução aparecerá aqui.")
        self.log_view.setMaximumBlockCount(5000)

        root = QtWidgets.QVBoxLayout(self)
        root.setContentsMargins(20, 16, 20, 16)
        root.setSpacing(12)
        root.addWidget(_heading("Simulador — Execução Paralela"))
        root.addWidget(
            _heading(
                "Selecione o backend, defina o paralelismo por workers sandbox e "
                "acompanhe o throughput em tempo real.",
                role="section",
            )
        )
        root.addWidget(grp_backend)
        root.addWidget(grp_par)
        root.addWidget(grp_out)
        root.addWidget(grp_exec)
        root.addWidget(self.log_view, 1)

    def _browse_out(self) -> None:
        path = QtWidgets.QFileDialog.getExistingDirectory(
            self,
            "Selecionar diretório de saída",
            self.edit_output_dir.text() or str(Path.cwd()),
        )
        if path:
            self.edit_output_dir.setText(path)

    def set_fortran_path(self, path: str) -> None:
        self.lbl_fortran_path.setText(path or "(indefinido)")

    def set_python_path(self, path: str) -> None:
        self.lbl_python_path.setText(path or sys.executable)

    def set_output_dir(self, path: str) -> None:
        if path and not self.edit_output_dir.text():
            self.edit_output_dir.setText(path)

    def append_log(self, msg: str) -> None:
        self.log_view.appendPlainText(msg)

    def set_running(self, running: bool) -> None:
        """Atualiza o estado dos botões Start/Stop.

        CORREÇÃO: ``running=False`` SEMPRE reabilita Start. Garantia de que
        após Stop (ou erro) o usuário possa reiniciar sem travar a UI.
        """
        self.btn_start.setEnabled(not running)
        self.btn_stop.setEnabled(running)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "backend": self.combo_backend.currentText(),
            "workers": self.spin_workers.value(),
            "threads": self.spin_threads.value(),
            "output_dir": self.edit_output_dir.text(),
            "save_artifacts": self.check_save_artifacts.isChecked(),
        }

    def from_dict(self, d: Dict[str, Any]) -> None:
        if not d:
            return
        try:
            self.combo_backend.setCurrentText(d.get("backend", "numba"))
            self.spin_workers.setValue(int(d.get("workers", 2)))
            self.spin_threads.setValue(int(d.get("threads", 4)))
            self.edit_output_dir.setText(str(d.get("output_dir", "")))
            self.check_save_artifacts.setChecked(bool(d.get("save_artifacts", True)))
        except Exception:
            pass


# ══════════════════════════════════════════════════════════════════════════
# Aba 3 — Benchmark (+ Config C uniforme + Config D per-model dialog)
# ══════════════════════════════════════════════════════════════════════════


class ConfigDRowEditor(QtWidgets.QDialog):
    """Editor de parâmetros canônicos per-model (uma linha de Config D)."""

    def __init__(
        self,
        model_name: str,
        current: Dict[str, Any],
        parent: Optional[QtWidgets.QWidget] = None,
    ) -> None:
        super().__init__(parent)
        self.setWindowTitle(f"Parâmetros canônicos — {model_name}")
        self.setMinimumWidth(520)
        self._model = model_name
        self._result: Optional[Dict[str, Any]] = None

        default = default_canonical_config(model_name)
        eff = {**default, **(current or {})}

        form = QtWidgets.QFormLayout()
        form.setLabelAlignment(ALIGN_RIGHT)
        form.setHorizontalSpacing(12)

        self.edit_freqs = _qline(
            ", ".join(f"{f:g}" for f in eff["freqs_hz"]),
            "Ex.: 20000, 40000",
        )
        self.edit_trs = _qline(
            ", ".join(f"{t:g}" for t in eff["tr_list_m"]),
            "Ex.: 1.0, 8.19, 20.43",
        )
        self.edit_dips = _qline(
            ", ".join(f"{d:g}" for d in eff["dip_list_deg"]),
            "Ex.: 0, 30",
        )
        self.spin_h1 = _spin_float(float(eff["h1"]), 0.01, 500.0, 0.5, 4, " m")
        self.spin_pmed = _spin_float(float(eff["p_med"]), 0.01, 10.0, 0.01, 3, " m")

        for w, tip in [
            (self.edit_freqs, "Frequências (Hz) específicas do modelo canônico."),
            (self.edit_trs, "Espaçamentos T-R (m) específicos do modelo canônico."),
            (self.edit_dips, "Ângulos de dip (°) específicos do modelo canônico."),
            (self.spin_h1, "Altura h1 do modelo (m)."),
            (self.spin_pmed, "Passo entre medidas p_med (m)."),
        ]:
            _tooltip(w, tip)

        form.addRow("Frequências (Hz):", self.edit_freqs)
        form.addRow("Espaçamentos TR (m):", self.edit_trs)
        form.addRow("Ângulos de dip (graus):", self.edit_dips)
        form.addRow("Altura h1:", self.spin_h1)
        form.addRow("Passo p_med:", self.spin_pmed)

        lbl_desc = QtWidgets.QLabel(default.get("description", ""))
        lbl_desc.setStyleSheet("color:#a5a5a5; padding:6px 0;")
        lbl_desc.setWordWrap(True)

        btnbox = QtWidgets.QDialogButtonBox()
        btn_reset = btnbox.addButton(
            "↻  Restaurar padrão", QtWidgets.QDialogButtonBox.ButtonRole.ResetRole
        )
        btn_ok = btnbox.addButton(
            "Salvar", QtWidgets.QDialogButtonBox.ButtonRole.AcceptRole
        )
        btn_cancel = btnbox.addButton(
            "Cancelar", QtWidgets.QDialogButtonBox.ButtonRole.RejectRole
        )
        btn_ok.setProperty("role", "primary")
        btn_ok.clicked.connect(self._on_accept)
        btn_cancel.clicked.connect(self.reject)
        btn_reset.clicked.connect(self._on_reset)

        root = QtWidgets.QVBoxLayout(self)
        root.addWidget(_heading(f"Config D — {model_name}"))
        root.addWidget(lbl_desc)
        root.addLayout(form)
        root.addWidget(btnbox)

    def _on_reset(self) -> None:
        default = default_canonical_config(self._model)
        self.edit_freqs.setText(", ".join(f"{f:g}" for f in default["freqs_hz"]))
        self.edit_trs.setText(", ".join(f"{t:g}" for t in default["tr_list_m"]))
        self.edit_dips.setText(", ".join(f"{d:g}" for d in default["dip_list_deg"]))
        self.spin_h1.setValue(float(default["h1"]))
        self.spin_pmed.setValue(float(default["p_med"]))

    def _on_accept(self) -> None:
        freqs = _parse_float_list(self.edit_freqs.text(), [20000.0])
        trs = _parse_float_list(self.edit_trs.text(), [1.0])
        dips = _parse_float_list(self.edit_dips.text(), [0.0])
        if not freqs or not trs or not dips:
            QtWidgets.QMessageBox.warning(
                self,
                "Valores inválidos",
                "Frequências, TR e dips não podem ser vazios.",
            )
            return
        self._result = {
            "freqs_hz": freqs,
            "tr_list_m": trs,
            "dip_list_deg": dips,
            "h1": float(self.spin_h1.value()),
            "p_med": float(self.spin_pmed.value()),
        }
        self.accept()

    def result_override(self) -> Optional[Dict[str, Any]]:
        return self._result


class ConfigDDialog(QtWidgets.QDialog):
    """Janela dedicada — tabela per-model de parâmetros canônicos (Config D).

    Exibe a tabela com colunas ``Habilitar | Modelo | Freqs | TR · Dip | Ação``.
    O botão "Customizar…" de cada linha abre um :class:`ConfigDRowEditor`.
    """

    def __init__(
        self,
        selected_models: List[str],
        overrides: Dict[str, Dict[str, Any]],
        parent: Optional[QtWidgets.QWidget] = None,
    ) -> None:
        super().__init__(parent)
        self.setWindowTitle("Config D — parâmetros canônicos per-model")
        self.setMinimumSize(880, 440)
        self._overrides: Dict[str, Dict[str, Any]] = dict(overrides or {})
        self._checks: Dict[str, QtWidgets.QCheckBox] = {}

        lbl_info = QtWidgets.QLabel(
            "Cada modelo canônico pode ser habilitado individualmente e "
            "rodado com seus próprios parâmetros (freq/TR/dip/h1/p_med). "
            "Os valores padrão vêm dos scripts <i>bench_numba_vs_fortran_local.py</i> "
            "e <i>buildValidamodels.py</i>. Clique em 'Customizar…' para editar."
        )
        lbl_info.setStyleSheet("color:#a5a5a5; padding-bottom:6px;")
        lbl_info.setWordWrap(True)

        self.table = QtWidgets.QTableWidget(len(CANONICAL_BENCHMARK_MODELS), 5)
        self.table.setHorizontalHeaderLabels(
            ["Habilitar", "Modelo", "Freqs (Hz)", "TR (m) · Dip (°)", "Ação"]
        )
        self.table.verticalHeader().setVisible(False)
        hdr = self.table.horizontalHeader()
        hdr.setStretchLastSection(False)
        hdr.setSectionResizeMode(0, QtWidgets.QHeaderView.ResizeMode.ResizeToContents)
        hdr.setSectionResizeMode(1, QtWidgets.QHeaderView.ResizeMode.ResizeToContents)
        hdr.setSectionResizeMode(2, QtWidgets.QHeaderView.ResizeMode.Stretch)
        hdr.setSectionResizeMode(3, QtWidgets.QHeaderView.ResizeMode.Stretch)
        hdr.setSectionResizeMode(4, QtWidgets.QHeaderView.ResizeMode.ResizeToContents)
        self.table.setMinimumHeight(260)
        self.table.setEditTriggers(QtWidgets.QAbstractItemView.EditTrigger.NoEditTriggers)
        for row, m in enumerate(CANONICAL_BENCHMARK_MODELS):
            cb = QtWidgets.QCheckBox()
            cb.setChecked(m in selected_models)
            self._checks[m] = cb
            wrap_cb = QtWidgets.QWidget()
            layout_cb = QtWidgets.QHBoxLayout(wrap_cb)
            layout_cb.setContentsMargins(8, 2, 8, 2)
            layout_cb.addWidget(cb)
            layout_cb.addStretch(1)
            self.table.setCellWidget(row, 0, wrap_cb)
            self.table.setItem(row, 1, QtWidgets.QTableWidgetItem(m))
            eff = {**default_canonical_config(m), **self._overrides.get(m, {})}
            self._refresh_row(row, eff)
            btn_edit = QtWidgets.QPushButton("Customizar…")
            btn_edit.clicked.connect(
                lambda _=False, mname=m, r=row: self._edit_row(mname, r)
            )
            self.table.setCellWidget(row, 4, btn_edit)

        btnbox = QtWidgets.QDialogButtonBox()
        btn_ok = btnbox.addButton(
            "Aplicar", QtWidgets.QDialogButtonBox.ButtonRole.AcceptRole
        )
        btn_cancel = btnbox.addButton(
            "Cancelar", QtWidgets.QDialogButtonBox.ButtonRole.RejectRole
        )
        btn_ok.setProperty("role", "primary")
        btn_ok.clicked.connect(self.accept)
        btn_cancel.clicked.connect(self.reject)

        root = QtWidgets.QVBoxLayout(self)
        root.addWidget(_heading("Config D — parâmetros canônicos per-model"))
        root.addWidget(lbl_info)
        root.addWidget(self.table, 1)
        root.addWidget(btnbox)

    def _refresh_row(self, row: int, params: Dict[str, Any]) -> None:
        freqs = params.get("freqs_hz", [])
        trs = params.get("tr_list_m", [])
        dips = params.get("dip_list_deg", [])
        freqs_txt = ", ".join(f"{f/1000:g} kHz" for f in freqs)
        tr_dip = (
            "TR=["
            + ", ".join(f"{t:g}" for t in trs)
            + "] · θ=["
            + ", ".join(f"{d:g}" for d in dips)
            + "]"
        )
        item_f = QtWidgets.QTableWidgetItem(freqs_txt)
        item_d = QtWidgets.QTableWidgetItem(tr_dip)
        self.table.setItem(row, 2, item_f)
        self.table.setItem(row, 3, item_d)

    def _edit_row(self, model_name: str, row: int) -> None:
        current = self._overrides.get(model_name, {})
        dlg = ConfigDRowEditor(model_name, current, parent=self)
        if dlg.exec():
            override = dlg.result_override()
            if override:
                self._overrides[model_name] = override
                eff = {**default_canonical_config(model_name), **override}
                self._refresh_row(row, eff)
                self._checks[model_name].setChecked(True)

    def selected_models(self) -> List[str]:
        return [m for m, cb in self._checks.items() if cb.isChecked()]

    def overrides(self) -> Dict[str, Dict[str, Any]]:
        return dict(self._overrides)


class BenchmarkPage(QtWidgets.QWidget):
    """Página de benchmarks — Config A/B/C/D + 30k."""

    request_start = Signal()
    request_stop = Signal()

    def __init__(self, parent: Optional[QtWidgets.QWidget] = None) -> None:
        super().__init__(parent)
        ncpu = os.cpu_count() or 8
        # Estado interno da Config D (persistido mesmo com diálogo fechado)
        self._config_d_models: List[str] = []
        self._config_d_overrides: Dict[str, Dict[str, Any]] = {}

        # ── Experimentos A/B/C/D/30k ──────────────────────────────────────
        grp_exp = QtWidgets.QGroupBox("Experimentos fixos (A / B / C / D / 30k)")
        exp_layout = QtWidgets.QVBoxLayout(grp_exp)
        self.check_cfg_a = QtWidgets.QCheckBox(
            "Config A — 1 frequência (20 kHz) · 1 TR (1 m) · 1 dip (0°) · 600 posições"
        )
        self.check_cfg_b = QtWidgets.QCheckBox(
            "Config B — 2 frequências (20/40 kHz) · 1 TR (1 m) · 2 dips (0°/30°) · 600 posições"
        )
        self.check_cfg_c = QtWidgets.QCheckBox(
            "Config C — 2 freqs (2 kHz, 6 kHz) · 2 TRs (8.19 m, 20.43 m) · "
            "dip 0° · h1 = 10.000 m · p_med = 0.200 m (uniforme para todos "
            "os modelos canônicos selecionados)"
        )
        self.check_cfg_d = QtWidgets.QCheckBox(
            "Config D — parâmetros canônicos per-model customizáveis "
            "(abre janela dedicada)"
        )
        self.check_30k = QtWidgets.QCheckBox(
            "Experimento 30k modelos aleatórios (20 camadas, ρₕ alta)"
        )
        self.check_cfg_a.setChecked(True)
        self.check_cfg_b.setChecked(True)

        _tooltip(
            self.check_cfg_c,
            (
                "<b>Config C — uniforme</b><br/>"
                "Aplica uma única configuração a todos os modelos canônicos selecionados "
                "no grupo 'Modelos canônicos (Config A/B/C)':<br/>"
                "• freqs = [2 kHz, 6 kHz]<br/>"
                "• TR = [8.19 m, 20.43 m]<br/>"
                "• dip = [0°]<br/>"
                "• h1 = 10.000 m, p_med = 0.200 m<br/>"
                "Valores extraídos de <i>buildValidamodels.py</i>."
            ),
        )
        _tooltip(
            self.check_cfg_d,
            (
                "<b>Config D — per-model customizável</b><br/>"
                "Ao marcar, abre uma janela com a tabela de modelos canônicos. "
                "Cada modelo pode ser habilitado individualmente e ter seus parâmetros "
                "(freq/TR/dip/h1/p_med) customizados via 'Customizar…'."
            ),
        )

        exp_layout.addWidget(self.check_cfg_a)
        exp_layout.addWidget(self.check_cfg_b)
        exp_layout.addWidget(self.check_cfg_c)

        # Linha Config D: checkbox + botão para reabrir janela
        row_d = QtWidgets.QHBoxLayout()
        row_d.setContentsMargins(0, 0, 0, 0)
        row_d.addWidget(self.check_cfg_d, 1)
        self.btn_open_cfg_d = QtWidgets.QPushButton("Abrir janela Config D…")
        self.btn_open_cfg_d.setEnabled(False)
        self.btn_open_cfg_d.clicked.connect(self._open_config_d_dialog)
        row_d.addWidget(self.btn_open_cfg_d)
        wrap_d = QtWidgets.QWidget()
        wrap_d.setLayout(row_d)
        exp_layout.addWidget(wrap_d)

        self.lbl_cfg_d_status = QtWidgets.QLabel("Config D: nenhum modelo habilitado")
        self.lbl_cfg_d_status.setStyleSheet(
            "color:#a5a5a5; font-size:11px; padding-left:22px;"
        )
        exp_layout.addWidget(self.lbl_cfg_d_status)

        exp_layout.addWidget(self.check_30k)

        # Config D: ao marcar, abre diálogo imediatamente (se ainda não houve)
        self.check_cfg_d.toggled.connect(self._on_cfg_d_toggled)

        grp_models_ab = QtWidgets.QGroupBox("Modelos canônicos (Config A/B/C)")
        mdl_layout = QtWidgets.QGridLayout(grp_models_ab)
        self.model_checks: Dict[str, QtWidgets.QCheckBox] = {}
        for i, m in enumerate(CANONICAL_BENCHMARK_MODELS):
            cb = QtWidgets.QCheckBox(m)
            cb.setChecked(True)
            self.model_checks[m] = cb
            mdl_layout.addWidget(cb, i // 2, i % 2)

        # ── Backends ────────────────────────────────────────────────────
        grp_bk = QtWidgets.QGroupBox("Backends a comparar")
        bk_layout = QtWidgets.QHBoxLayout(grp_bk)
        self.check_numba = QtWidgets.QCheckBox("Numba JIT (Python otimizado)")
        self.check_numba.setChecked(True)
        self.check_fortran = QtWidgets.QCheckBox("Fortran tatu.x (OpenMP)")
        self.check_fortran.setChecked(True)
        bk_layout.addWidget(self.check_numba)
        bk_layout.addWidget(self.check_fortran)
        bk_layout.addStretch(1)

        # ── Paralelismo ─────────────────────────────────────────────────
        grp_par = QtWidgets.QGroupBox("Paralelismo")
        par_form = QtWidgets.QFormLayout(grp_par)
        par_form.setLabelAlignment(ALIGN_RIGHT)
        self.spin_workers_numba = _spin_int(max(1, ncpu // 4), 1, 256)
        self.spin_threads_numba = _spin_int(4, 1, 256)
        self.spin_workers_fortran = _spin_int(max(1, ncpu // 2), 1, 256)
        self.spin_threads_fortran = _spin_int(2, 1, 256)
        self.spin_n_iter = _spin_int(3, 1, 100)
        self.spin_fort_subset = _spin_int(300, 1, 30000)
        par_form.addRow("Workers — Numba:", self.spin_workers_numba)
        par_form.addRow("Threads por worker — Numba:", self.spin_threads_numba)
        par_form.addRow("Workers — Fortran:", self.spin_workers_fortran)
        par_form.addRow("Threads por worker — Fortran:", self.spin_threads_fortran)
        par_form.addRow("Nº iterações (Config A/B/C):", self.spin_n_iter)
        par_form.addRow("Subset Fortran (30k):", self.spin_fort_subset)

        # ── Execução ────────────────────────────────────────────────────
        grp_exec = QtWidgets.QGroupBox("Execução do Benchmark")
        exec_row = QtWidgets.QHBoxLayout(grp_exec)
        self.btn_start = QtWidgets.QPushButton("▶  Iniciar Benchmark")
        self.btn_start.setProperty("role", "primary")
        self.btn_stop = QtWidgets.QPushButton("■  Parar")
        self.btn_stop.setProperty("role", "danger")
        self.btn_stop.setEnabled(False)
        self.progress = QtWidgets.QProgressBar()
        self.progress.setRange(0, 100)
        self.lbl_current = QtWidgets.QLabel("(aguardando)")
        exec_row.addWidget(self.btn_start)
        exec_row.addWidget(self.btn_stop)
        exec_row.addWidget(self.progress, 1)
        exec_row.addWidget(self.lbl_current)
        self.btn_start.clicked.connect(self.request_start.emit)
        self.btn_stop.clicked.connect(self.request_stop.emit)

        self.log_view = QtWidgets.QPlainTextEdit()
        self.log_view.setObjectName("LogView")
        self.log_view.setReadOnly(True)
        self.log_view.setPlaceholderText("Log de benchmark aparecerá aqui.")
        self.log_view.setMaximumBlockCount(5000)

        self.table = QtWidgets.QTableWidget(0, 8)
        self.table.setHorizontalHeaderLabels(
            [
                "Modelo",
                "Config",
                "Nº modelos",
                "Numba (ms/mod)",
                "Fortran (ms/mod)",
                "Numba (mod/h)",
                "Fortran (mod/h)",
                "Speedup",
            ]
        )
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.setAlternatingRowColors(True)

        grid = QtWidgets.QVBoxLayout(self)
        grid.setContentsMargins(20, 16, 20, 16)
        grid.setSpacing(12)
        grid.addWidget(_heading("Benchmark — Numba vs Fortran"))
        grid.addWidget(
            _heading(
                "Compare throughput e paridade numérica entre os dois simuladores. "
                "Config A/B/C aplicam parâmetros uniformes; Config D permite "
                "customização per-model numa janela dedicada.",
                role="section",
            )
        )
        top = QtWidgets.QHBoxLayout()
        col_left = QtWidgets.QVBoxLayout()
        col_left.addWidget(grp_exp)
        col_left.addWidget(grp_models_ab)
        col_right = QtWidgets.QVBoxLayout()
        col_right.addWidget(grp_bk)
        col_right.addWidget(grp_par)
        top.addLayout(col_left, 1)
        top.addLayout(col_right, 1)
        grid.addLayout(top)
        grid.addWidget(grp_exec)
        grid.addWidget(self.log_view, 1)
        grid.addWidget(self.table, 1)

    # ── Config D dialog management ───────────────────────────────────────
    def _on_cfg_d_toggled(self, checked: bool) -> None:
        """Quando a checkbox Config D é marcada, abre o diálogo da tabela.

        Se desmarcada, apenas desativa o botão 'Abrir janela…'. A seleção
        interna de modelos é preservada (para re-habilitação sem re-configurar).
        """
        self.btn_open_cfg_d.setEnabled(checked)
        if checked and not self._config_d_models:
            # Primeira vez: abre automaticamente para o usuário configurar
            self._open_config_d_dialog()
            if not self._config_d_models:
                # Usuário cancelou; desfaz a checagem silenciosamente
                self.check_cfg_d.blockSignals(True)
                self.check_cfg_d.setChecked(False)
                self.btn_open_cfg_d.setEnabled(False)
                self.check_cfg_d.blockSignals(False)

    def _open_config_d_dialog(self) -> None:
        dlg = ConfigDDialog(
            selected_models=self._config_d_models,
            overrides=self._config_d_overrides,
            parent=self,
        )
        if dlg.exec():
            self._config_d_models = dlg.selected_models()
            self._config_d_overrides = dlg.overrides()
            self._update_cfg_d_status()

    def _update_cfg_d_status(self) -> None:
        if self._config_d_models:
            txt = (
                f"Config D: {len(self._config_d_models)} modelo(s) habilitado(s) — "
                + ", ".join(self._config_d_models)
            )
        else:
            txt = "Config D: nenhum modelo habilitado"
        self.lbl_cfg_d_status.setText(txt)

    # ── API pública ──────────────────────────────────────────────────────
    def selected_models(self) -> List[str]:
        return [m for m, cb in self.model_checks.items() if cb.isChecked()]

    def selected_config_d_models(self) -> List[str]:
        return list(self._config_d_models)

    def config_d_overrides(self) -> Dict[str, Dict[str, Any]]:
        return dict(self._config_d_overrides)

    def append_log(self, msg: str) -> None:
        self.log_view.appendPlainText(msg)

    def set_running(self, running: bool) -> None:
        self.btn_start.setEnabled(not running)
        self.btn_stop.setEnabled(running)

    def populate_table(self, records: List[BenchRecord]) -> None:
        self.table.setRowCount(0)
        for r in records:
            row = self.table.rowCount()
            self.table.insertRow(row)
            vals = [
                r.model_name,
                r.config,
                str(r.n_models),
                format_float(r.numba_ms_per_model, 2),
                format_float(r.fortran_ms_per_model, 2),
                format_float(r.numba_mod_h, 0, thousands=True),
                format_float(r.fortran_mod_h, 0, thousands=True),
                f"{format_float(r.speedup, 2)}×",
            ]
            for col, v in enumerate(vals):
                item = QtWidgets.QTableWidgetItem(v)
                item.setTextAlignment(ALIGN_CENTER if ALIGN_CENTER else 0x4)
                self.table.setItem(row, col, item)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "run_a": self.check_cfg_a.isChecked(),
            "run_b": self.check_cfg_b.isChecked(),
            "run_c": self.check_cfg_c.isChecked(),
            "run_d": self.check_cfg_d.isChecked(),
            "run_d_models": list(self._config_d_models),
            "run_d_overrides": self._config_d_overrides,
            "run_30k": self.check_30k.isChecked(),
            "models_ab": self.selected_models(),
            "bk_numba": self.check_numba.isChecked(),
            "bk_fortran": self.check_fortran.isChecked(),
            "workers_numba": self.spin_workers_numba.value(),
            "threads_numba": self.spin_threads_numba.value(),
            "workers_fortran": self.spin_workers_fortran.value(),
            "threads_fortran": self.spin_threads_fortran.value(),
            "n_iter": self.spin_n_iter.value(),
            "fort_subset": self.spin_fort_subset.value(),
        }

    def from_dict(self, d: Dict[str, Any]) -> None:
        if not d:
            return
        try:
            self.check_cfg_a.setChecked(bool(d.get("run_a", True)))
            self.check_cfg_b.setChecked(bool(d.get("run_b", True)))
            self.check_cfg_c.setChecked(bool(d.get("run_c", False)))
            self.check_30k.setChecked(bool(d.get("run_30k", False)))
            self.check_numba.setChecked(bool(d.get("bk_numba", True)))
            self.check_fortran.setChecked(bool(d.get("bk_fortran", True)))
            self.spin_workers_numba.setValue(int(d.get("workers_numba", 2)))
            self.spin_threads_numba.setValue(int(d.get("threads_numba", 4)))
            self.spin_workers_fortran.setValue(int(d.get("workers_fortran", 4)))
            self.spin_threads_fortran.setValue(int(d.get("threads_fortran", 2)))
            self.spin_n_iter.setValue(int(d.get("n_iter", 3)))
            self.spin_fort_subset.setValue(int(d.get("fort_subset", 300)))
            models_ab = d.get("models_ab", [])
            for m, cb in self.model_checks.items():
                cb.setChecked(m in models_ab or not models_ab)
            # Config D state
            self._config_d_overrides = dict(d.get("run_d_overrides", {}) or {})
            self._config_d_models = list(d.get("run_d_models", []) or [])
            # Toggle checkbox D without firing the dialog
            self.check_cfg_d.blockSignals(True)
            self.check_cfg_d.setChecked(bool(d.get("run_d", False)))
            self.btn_open_cfg_d.setEnabled(self.check_cfg_d.isChecked())
            self.check_cfg_d.blockSignals(False)
            self._update_cfg_d_status()
        except Exception:
            pass


# ══════════════════════════════════════════════════════════════════════════
# Aba 4 — Resultados (+ model selector)
# ══════════════════════════════════════════════════════════════════════════


class ResultsPage(QtWidgets.QWidget):
    """Página de plotagem interativa — simulação + benchmark + seletor de modelo."""

    def __init__(
        self,
        style: PlotStyle,
        parent: Optional[QtWidgets.QWidget] = None,
    ) -> None:
        super().__init__(parent)
        self._style = style
        self._current_sim: Optional[Dict[str, Any]] = None
        self._benchmark_plot_data: Dict[Tuple[str, str], Dict[str, Any]] = {}
        self._sim_models: List[Dict[str, Any]] = []  # cache dos modelos gerados

        # Painel esquerdo — controles
        controls = QtWidgets.QGroupBox("Controles de Plot")
        ctrl_layout = QtWidgets.QFormLayout(controls)
        ctrl_layout.setLabelAlignment(ALIGN_RIGHT)
        ctrl_layout.setHorizontalSpacing(12)

        self.combo_source = QtWidgets.QComboBox()
        self.combo_source.addItems(["Simulação atual", "Benchmark (Numba vs Fortran)"])
        _tooltip(self.combo_source, "Fonte dos dados a plotar.")

        self.combo_model_key = QtWidgets.QComboBox()
        _tooltip(
            self.combo_model_key,
            (
                "Célula específica (modelo × config) a plotar. Em 'Simulação atual', "
                "se múltiplos modelos foram gerados, lista os índices 0..N−1."
            ),
        )

        self.list_components = QtWidgets.QListWidget()
        self.list_components.setSelectionMode(
            QtWidgets.QAbstractItemView.SelectionMode.MultiSelection
            if hasattr(QtWidgets.QAbstractItemView, "SelectionMode")
            else QtWidgets.QAbstractItemView.MultiSelection
        )
        self.list_components.setMaximumHeight(150)
        for c in COMPONENT_NAMES:
            item = QtWidgets.QListWidgetItem(c)
            self.list_components.addItem(item)
            if c in ("Hxx", "Hzz"):
                item.setSelected(True)

        self.combo_plot_kind = QtWidgets.QComboBox()
        self.combo_plot_kind.addItems(
            [
                "Tensor H completo (Re/Im 3×6)",
                "Componentes EM",
                "Perfil de Resistividade",
                "Geosinais (USD/UAD/UHR/UHA)",
                "Anisotropia λ = √(ρᵥ/ρₕ)",
                "Benchmark compare (Numba vs Fortran)",
            ]
        )

        self.combo_kind_mode = QtWidgets.QComboBox()
        self.combo_kind_mode.addItems(PLOT_KINDS)

        self.btn_plot = QtWidgets.QPushButton("Plotar")
        self.btn_plot.setProperty("role", "primary")
        self.btn_save = QtWidgets.QPushButton("Salvar figura…")

        ctrl_layout.addRow("Fonte:", self.combo_source)
        ctrl_layout.addRow("Modelo / célula:", self.combo_model_key)
        ctrl_layout.addRow("Componentes EM:", self.list_components)
        ctrl_layout.addRow("Tipo de plot:", self.combo_plot_kind)
        ctrl_layout.addRow("Modo (Componentes EM):", self.combo_kind_mode)
        ctrl_layout.addRow(self.btn_plot)
        ctrl_layout.addRow(self.btn_save)

        # Painel direito — canvas
        self.canvas = EMCanvas(self, figsize=(14, 9), style=self._style)

        splitter = QtWidgets.QSplitter(ORIENT_H if ORIENT_H else 0x1)
        left_wrap = QtWidgets.QWidget()
        left_layout = QtWidgets.QVBoxLayout(left_wrap)
        left_layout.setContentsMargins(0, 0, 0, 0)
        left_layout.addWidget(controls)
        left_layout.addStretch(1)
        splitter.addWidget(left_wrap)
        splitter.addWidget(self.canvas)
        splitter.setStretchFactor(0, 0)
        splitter.setStretchFactor(1, 1)
        splitter.setSizes([380, 1100])

        root = QtWidgets.QVBoxLayout(self)
        root.setContentsMargins(20, 16, 20, 16)
        root.addWidget(_heading("Resultados — Visualização Interativa"))
        root.addWidget(
            _heading(
                "Plots de componentes EM, perfil ρ, geosinais e comparação Numba vs Fortran. "
                "Selecione o modelo em 'Modelo / célula' quando múltiplos perfis foram gerados.",
                role="section",
            )
        )
        root.addWidget(splitter, 1)

        self.btn_plot.clicked.connect(self._on_plot)
        self.btn_save.clicked.connect(self._on_save)
        self.combo_source.currentIndexChanged.connect(self._refresh_keys)

    def set_style(self, style: PlotStyle) -> None:
        self._style = style
        if self.canvas is not None:
            self.canvas.set_style(style)

    def set_current_simulation(
        self, result: Dict[str, Any], models: Optional[List[Dict[str, Any]]] = None
    ) -> None:
        self._current_sim = result
        self._sim_models = list(models or [])
        self._refresh_keys()

    def set_benchmark_plot_data(
        self, data: Dict[Tuple[str, str], Dict[str, Any]]
    ) -> None:
        self._benchmark_plot_data = data
        self._refresh_keys()

    def _refresh_keys(self) -> None:
        self.combo_model_key.clear()
        if self.combo_source.currentIndex() == 0:
            if self._current_sim is not None:
                H = self._current_sim.get("H_stack")
                n_models = int(H.shape[0]) if (H is not None and H.ndim == 6) else 1
                if n_models <= 1:
                    self.combo_model_key.addItem("(simulação atual — modelo único)")
                else:
                    for i in range(n_models):
                        title = ""
                        if i < len(self._sim_models):
                            md = self._sim_models[i]
                            title = (
                                md.get("title", "")
                                or f'{md.get("n_layers", "?")} camadas'
                            )
                        self.combo_model_key.addItem(
                            f"Modelo #{i + 1}/{n_models} — {title}".strip(" —")
                        )
        else:
            for m, c in self._benchmark_plot_data.keys():
                self.combo_model_key.addItem(f"{m} / Config {c}")

    def _selected_components(self) -> List[str]:
        items = self.list_components.selectedItems()
        return [it.text() for it in items] if items else ["Hxx", "Hzz"]

    def _resolve_current_sim_H(self) -> Tuple[Optional[np.ndarray], Dict[str, Any]]:
        """Retorna (H0 — tensor do modelo selecionado, model_dict) para sim atual."""
        sim = self._current_sim or {}
        H = sim.get("H_stack")
        if H is None or not hasattr(H, "size") or H.size == 0:
            return None, {}
        idx = max(0, self.combo_model_key.currentIndex())
        # Quando só há 1 modelo, combo_model_key.currentIndex() pode ser 0
        if H.ndim == 6:
            idx = min(idx, H.shape[0] - 1)
            H0 = H[idx]
            md = self._sim_models[idx] if idx < len(self._sim_models) else {}
        else:
            H0 = H
            md = sim.get("model", {}) or {}
        return H0, md

    def _on_plot(self) -> None:
        kind = self.combo_plot_kind.currentText()
        kind_mode = self.combo_kind_mode.currentText()
        comps = self._selected_components()

        if self.combo_source.currentIndex() == 0:
            sim = self._current_sim
            if not sim:
                return
            H0, md = self._resolve_current_sim_H()
            if H0 is None:
                return
            z_obs = sim.get("z_obs")
            freqs = sim.get("freqs", [20000.0])
            trs = sim.get("trs", [1.0])
            dips = sim.get("dips", [0.0])
            rho_h = md.get("rho_h", [])
            rho_v = md.get("rho_v", rho_h)
            thicknesses = md.get("thicknesses", [])
            title = md.get("title", "") or f"Modelo {self.combo_model_key.currentText()}"

            if kind == "Tensor H completo (Re/Im 3×6)":
                plot_tensor_full(
                    self.canvas,
                    H0,
                    z_obs,
                    freqs,
                    trs,
                    dips,
                    title=title,
                    thicknesses=thicknesses,
                    rho_h=rho_h,
                    rho_v=rho_v,
                    style=self._style,
                )
            elif kind == "Componentes EM":
                plot_em_profile(
                    self.canvas,
                    H0,
                    z_obs,
                    freqs,
                    trs,
                    dips,
                    comps,
                    title=f"{title} — {', '.join(comps)}",
                    kind=kind_mode,
                    style=self._style,
                    thicknesses=thicknesses,
                )
            elif kind == "Geosinais (USD/UAD/UHR/UHA)":
                plot_geosignals(
                    self.canvas,
                    H0,
                    z_obs,
                    freqs,
                    trs,
                    dips,
                    title=f"Geosinais — {title}",
                    style=self._style,
                    thicknesses=thicknesses,
                )
            elif kind == "Perfil de Resistividade":
                plot_resistivity_profile(
                    self.canvas,
                    rho_h,
                    rho_v,
                    thicknesses,
                    title=title,
                    style=self._style,
                )
            elif kind == "Anisotropia λ = √(ρᵥ/ρₕ)":
                plot_anisotropy(
                    self.canvas,
                    rho_h,
                    rho_v,
                    thicknesses,
                    title=f"Anisotropia — {title}",
                    style=self._style,
                )
            else:
                plot_benchmark_compare(
                    self.canvas,
                    H0,
                    None,
                    z_obs,
                    freqs,
                    trs,
                    dips,
                    comps,
                    title="Somente Numba (sem benchmark ativo)",
                    style=self._style,
                    thicknesses=thicknesses,
                )
        else:
            key_text = self.combo_model_key.currentText()
            if not key_text or "/" not in key_text:
                return
            parts = key_text.split("/")
            model_name = parts[0].strip()
            config = parts[1].replace("Config", "").strip()
            entry = self._benchmark_plot_data.get((model_name, config))
            if entry is None:
                return
            freqs = entry.get("freqs", [20000.0])
            trs = entry.get("trs", [1.0])
            dips = entry.get("dips", [0.0])
            H_n = entry.get("H_numba")
            H_f = entry.get("H_fortran")
            md = entry.get("model", {}) or {}
            thicknesses = md.get("thicknesses", [])
            rho_h = md.get("rho_h", [])
            rho_v = md.get("rho_v", rho_h)
            positions_z = entry.get("positions_z")
            z_obs_2d = None
            if positions_z is not None:
                z_obs_2d = np.broadcast_to(positions_z, (len(dips), positions_z.shape[0]))

            if kind == "Tensor H completo (Re/Im 3×6)" and H_n is not None:
                plot_tensor_full(
                    self.canvas,
                    H_n,
                    z_obs_2d,
                    freqs,
                    trs,
                    dips,
                    title=f"{md.get('title', model_name)} — Config {config}",
                    thicknesses=thicknesses,
                    rho_h=rho_h,
                    rho_v=rho_v,
                    style=self._style,
                )
            elif kind == "Perfil de Resistividade":
                plot_resistivity_profile(
                    self.canvas,
                    rho_h,
                    rho_v,
                    thicknesses,
                    title=f"{md.get('title', model_name)} — Config {config}",
                    style=self._style,
                )
            elif kind == "Anisotropia λ = √(ρᵥ/ρₕ)":
                plot_anisotropy(
                    self.canvas,
                    rho_h,
                    rho_v,
                    thicknesses,
                    title=f"{md.get('title', model_name)} — Config {config}",
                    style=self._style,
                )
            elif kind == "Componentes EM" and H_n is not None:
                plot_em_profile(
                    self.canvas,
                    H_n,
                    z_obs_2d,
                    freqs,
                    trs,
                    dips,
                    comps,
                    title=f"{model_name} — Config {config} (Numba)",
                    kind=kind_mode,
                    style=self._style,
                    thicknesses=thicknesses,
                )
            elif kind == "Geosinais (USD/UAD/UHR/UHA)" and H_n is not None:
                plot_geosignals(
                    self.canvas,
                    H_n,
                    z_obs_2d,
                    freqs,
                    trs,
                    dips,
                    title=f"{model_name} — Config {config}",
                    style=self._style,
                    thicknesses=thicknesses,
                )
            else:
                plot_benchmark_compare(
                    self.canvas,
                    H_n,
                    H_f,
                    z_obs_2d,
                    freqs,
                    trs,
                    dips,
                    comps,
                    title=f"Benchmark — {model_name} · Config {config}",
                    style=self._style,
                    thicknesses=thicknesses,
                )

    def _on_save(self) -> None:
        path, _ = QtWidgets.QFileDialog.getSaveFileName(
            self,
            "Salvar figura",
            "plot.png",
            "PNG (*.png);;PDF (*.pdf);;SVG (*.svg)",
        )
        if path:
            self.canvas.save(path)


# ══════════════════════════════════════════════════════════════════════════
# Aba 5 — Preferências (+ LaTeX + extras)
# ══════════════════════════════════════════════════════════════════════════


class PreferencesPage(QtWidgets.QWidget):
    """Página de preferências: caminhos manuais + plot style + LaTeX."""

    paths_changed = Signal(dict)
    style_changed = Signal(object)

    def __init__(
        self,
        paths: Dict[str, str],
        style: PlotStyle,
        parent: Optional[QtWidgets.QWidget] = None,
    ) -> None:
        super().__init__(parent)
        self._paths = dict(paths)
        self._style = style

        # ─── Paths ───────────────────────────────────────────────────────
        grp_paths = QtWidgets.QGroupBox("Caminhos (segurança · override manual)")
        grp_paths.setToolTip(
            "Caso a detecção automática falhe, defina aqui o caminho absoluto "
            "para geosteering_ai, tatu.x e o interpretador Python."
        )
        paths_form = QtWidgets.QFormLayout(grp_paths)
        paths_form.setLabelAlignment(ALIGN_RIGHT)

        self.edit_pkg = _qline(self._paths.get("geosteering_ai", ""), "…/geosteering_ai")
        self.edit_tatu = _qline(
            self._paths.get("tatu_binary", ""), "…/Fortran_Gerador/tatu.x"
        )
        self.edit_python = _qline(self._paths.get("python_binary", ""), "…/bin/python")
        self.edit_output = _qline(self._paths.get("output_dir", ""), "diretório de saída")

        self.lbl_pkg_status = QtWidgets.QLabel("")
        self.lbl_tatu_status = QtWidgets.QLabel("")
        self.lbl_python_status = QtWidgets.QLabel("")
        for lbl in (self.lbl_pkg_status, self.lbl_tatu_status, self.lbl_python_status):
            lbl.setStyleSheet("color:#a5a5a5; font-size:11px;")

        btn_pkg = QtWidgets.QPushButton("Procurar pasta…")
        btn_pkg.clicked.connect(lambda: self._browse_dir(self.edit_pkg))
        btn_tatu = QtWidgets.QPushButton("Procurar binário…")
        btn_tatu.clicked.connect(lambda: self._browse_file(self.edit_tatu))
        btn_python = QtWidgets.QPushButton("Procurar intérprete…")
        btn_python.clicked.connect(lambda: self._browse_file(self.edit_python))
        btn_output = QtWidgets.QPushButton("Procurar pasta…")
        btn_output.clicked.connect(lambda: self._browse_dir(self.edit_output))
        btn_auto = QtWidgets.QPushButton("↻  Redetectar automaticamente")
        btn_auto.clicked.connect(self._auto_detect)

        def _row(
            edit: "QtWidgets.QLineEdit", btn: "QtWidgets.QPushButton"
        ) -> "QtWidgets.QWidget":
            row = QtWidgets.QHBoxLayout()
            row.addWidget(edit, 1)
            row.addWidget(btn)
            w = QtWidgets.QWidget()
            w.setLayout(row)
            return w

        paths_form.addRow("geosteering_ai:", _row(self.edit_pkg, btn_pkg))
        paths_form.addRow("", self.lbl_pkg_status)
        paths_form.addRow("tatu.x (Fortran):", _row(self.edit_tatu, btn_tatu))
        paths_form.addRow("", self.lbl_tatu_status)
        paths_form.addRow("Python (interpretador):", _row(self.edit_python, btn_python))
        paths_form.addRow("", self.lbl_python_status)
        paths_form.addRow("Diretório de saída:", _row(self.edit_output, btn_output))
        paths_form.addRow("", btn_auto)

        # ─── Plot style ──────────────────────────────────────────────────
        grp_style = QtWidgets.QGroupBox("Estilo de Plot")
        style_form = QtWidgets.QFormLayout(grp_style)
        style_form.setLabelAlignment(ALIGN_RIGHT)

        self.spin_dpi = _spin_int(style.dpi, 50, 600)
        self.spin_font = _spin_int(style.font_size, 6, 32)
        self.combo_font_family = QtWidgets.QComboBox()
        self.combo_font_family.setEditable(True)
        self.combo_font_family.addItems(
            [
                "DejaVu Sans",
                "Helvetica",
                "Arial",
                "SF Pro Display",
                "Inter",
                "Roboto",
                "CMU Serif",
                "Times New Roman",
            ]
        )
        self.combo_font_family.setCurrentText(style.font_family)
        self.spin_lw = _spin_float(style.line_width, 0.3, 6.0, 0.1, 2)
        self.spin_axis_prec = _spin_int(style.axis_precision, 0, 8)
        self.spin_spine_w = _spin_float(style.spine_width, 0.2, 4.0, 0.1, 2)
        self.spin_marker_size = _spin_float(style.marker_size, 1.0, 20.0, 0.5, 2)
        self.check_grid = QtWidgets.QCheckBox("Exibir grid de fundo")
        self.check_grid.setChecked(style.grid)
        self.check_layer_boundary = QtWidgets.QCheckBox("Desenhar interfaces das camadas")
        self.check_layer_boundary.setChecked(style.show_layer_boundaries)
        self.check_minor_ticks = QtWidgets.QCheckBox("Mostrar ticks menores nos eixos")
        self.check_minor_ticks.setChecked(style.minor_ticks)
        self.check_use_latex = QtWidgets.QCheckBox(
            "Renderizar textos e fórmulas com LaTeX (requer TeX instalado)"
        )
        self.check_use_latex.setChecked(style.use_latex)
        _tooltip(
            self.check_use_latex,
            (
                "<b>LaTeX em plots</b><br/>"
                "Ativa <code>rcParams['text.usetex']=True</code>. Requer um ambiente "
                "LaTeX completo no sistema (<code>pdflatex</code>, <code>dvipng</code>). "
                "Se ausente, matplotlib emite warnings e cai em mathtext nativo.<br/>"
                "macOS: <code>brew install --cask mactex-no-gui</code><br/>"
                "Linux: <code>sudo apt install texlive-latex-extra dvipng</code>"
            ),
        )
        self.check_use_mathtext = QtWidgets.QCheckBox(
            "Usar mathtext nativo (Computer Modern, sem dependência externa)"
        )
        self.check_use_mathtext.setChecked(style.use_mathtext)
        self.combo_palette = QtWidgets.QComboBox()
        self.combo_palette.addItems(
            [
                "tab10",
                "tab20",
                "Set1",
                "Set2",
                "viridis",
                "cividis",
                "plasma",
                "magma",
                "coolwarm",
            ]
        )
        self.combo_palette.setCurrentText(style.palette)
        self.combo_legend_loc = QtWidgets.QComboBox()
        self.combo_legend_loc.addItems(
            [
                "best",
                "upper right",
                "upper left",
                "lower right",
                "lower left",
                "center left",
                "center right",
                "upper center",
                "lower center",
                "center",
            ]
        )
        self.combo_legend_loc.setCurrentText(style.legend_location)
        self.combo_title_loc = QtWidgets.QComboBox()
        self.combo_title_loc.addItems(["center", "left", "right"])
        self.combo_title_loc.setCurrentText(style.title_location)
        self.combo_line_style = QtWidgets.QComboBox()
        self.combo_line_style.addItems(["-", "--", "-.", ":"])
        self.combo_line_style.setCurrentText(style.line_style)
        self.combo_marker_style = QtWidgets.QComboBox()
        self.combo_marker_style.addItems(["o", "s", "^", "v", "D", "x", "+", "*"])
        self.combo_marker_style.setCurrentText(style.marker_style)

        self.btn_color_real = self._color_btn(style.color_real)
        self.btn_color_imag = self._color_btn(style.color_imag)
        self.btn_color_rho_h = self._color_btn(style.color_rho_h)
        self.btn_color_rho_v = self._color_btn(style.color_rho_v)
        self.btn_color_numba = self._color_btn(style.color_numba)
        self.btn_color_fortran = self._color_btn(style.color_fortran)
        self.btn_color_layer = self._color_btn(style.color_layer_boundary)
        self.btn_color_bg = self._color_btn(style.background)

        style_form.addRow("Resolução (DPI):", self.spin_dpi)
        style_form.addRow("Tipografia:", self.combo_font_family)
        style_form.addRow("Tamanho da fonte (pt):", self.spin_font)
        style_form.addRow("Espessura da linha:", self.spin_lw)
        style_form.addRow("Espessura dos eixos:", self.spin_spine_w)
        style_form.addRow("Tamanho do marcador:", self.spin_marker_size)
        style_form.addRow("Estilo da linha:", self.combo_line_style)
        style_form.addRow("Estilo do marcador:", self.combo_marker_style)
        style_form.addRow("Paleta multi-curva:", self.combo_palette)
        style_form.addRow("Localização da legenda:", self.combo_legend_loc)
        style_form.addRow("Alinhamento do título:", self.combo_title_loc)
        style_form.addRow("Casas decimais nos eixos:", self.spin_axis_prec)
        style_form.addRow("", self.check_grid)
        style_form.addRow("", self.check_layer_boundary)
        style_form.addRow("", self.check_minor_ticks)
        style_form.addRow("", self.check_use_latex)
        style_form.addRow("", self.check_use_mathtext)
        style_form.addRow("Cor Re(H):", self.btn_color_real)
        style_form.addRow("Cor Im(H):", self.btn_color_imag)
        style_form.addRow("Cor ρₕ:", self.btn_color_rho_h)
        style_form.addRow("Cor ρᵥ:", self.btn_color_rho_v)
        style_form.addRow("Cor Numba (comparação):", self.btn_color_numba)
        style_form.addRow("Cor Fortran (comparação):", self.btn_color_fortran)
        style_form.addRow("Cor das interfaces:", self.btn_color_layer)
        style_form.addRow("Cor de fundo do plot:", self.btn_color_bg)

        self.btn_save = QtWidgets.QPushButton("Salvar preferências")
        self.btn_save.setProperty("role", "primary")
        self.btn_save.clicked.connect(self._on_save)
        self.btn_reset = QtWidgets.QPushButton("Restaurar padrões")
        self.btn_reset.clicked.connect(self._on_reset)

        row_btn = QtWidgets.QHBoxLayout()
        row_btn.addWidget(self.btn_save)
        row_btn.addWidget(self.btn_reset)
        row_btn.addStretch(1)

        root = QtWidgets.QVBoxLayout()
        root.setContentsMargins(20, 16, 20, 16)
        root.setSpacing(12)
        root.addWidget(_heading("Preferências"))
        root.addWidget(
            _heading(
                "Override manual dos caminhos (se a detecção automática falhar), "
                "personalização completa do estilo dos plots e opção de render LaTeX.",
                role="section",
            )
        )
        root.addWidget(grp_paths)
        root.addWidget(grp_style)
        root.addLayout(row_btn)
        root.addStretch(1)

        container = QtWidgets.QWidget()
        container.setLayout(root)
        scroll = QtWidgets.QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(_frame_shape("NoFrame"))
        scroll.setWidget(container)

        outer = QtWidgets.QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.addWidget(scroll)

        self.edit_pkg.textChanged.connect(self._validate_paths)
        self.edit_tatu.textChanged.connect(self._validate_paths)
        self.edit_python.textChanged.connect(self._validate_paths)
        self._validate_paths()

    def _color_btn(self, color: str) -> "QtWidgets.QPushButton":
        btn = QtWidgets.QPushButton(color)
        btn.setStyleSheet(
            f"background:{color}; color:{_color_for_bg(color)}; "
            "border:1px solid #3c3c3c; border-radius:4px; padding:4px 10px;"
        )
        btn.clicked.connect(lambda: self._pick_color(btn))
        return btn

    def _pick_color(self, btn: "QtWidgets.QPushButton") -> None:
        dlg = QtWidgets.QColorDialog(self)
        try:
            dlg.setCurrentColor(QtGui.QColor(btn.text()))
        except Exception:
            pass
        if dlg.exec():
            c = dlg.currentColor().name()
            btn.setText(c)
            btn.setStyleSheet(
                f"background:{c}; color:{_color_for_bg(c)}; "
                "border:1px solid #3c3c3c; border-radius:4px; padding:4px 10px;"
            )

    def _browse_file(self, edit: "QtWidgets.QLineEdit") -> None:
        path, _ = QtWidgets.QFileDialog.getOpenFileName(
            self, "Selecionar arquivo", edit.text() or str(Path.cwd())
        )
        if path:
            edit.setText(path)

    def _browse_dir(self, edit: "QtWidgets.QLineEdit") -> None:
        path = QtWidgets.QFileDialog.getExistingDirectory(
            self, "Selecionar pasta", edit.text() or str(Path.cwd())
        )
        if path:
            edit.setText(path)

    def _auto_detect(self) -> None:
        pkg = find_geosteering_ai_root()
        tatu = find_tatu_binary()
        if pkg:
            self.edit_pkg.setText(str(pkg))
        if tatu:
            self.edit_tatu.setText(str(tatu))
        self.edit_python.setText(sys.executable)

    def _validate_paths(self) -> None:
        def _status(ok: bool, detail: str) -> str:
            color = "#3ecf5f" if ok else "#e5414e"
            mark = "✓" if ok else "✗"
            return f'<span style="color:{color};">{mark} {detail}</span>'

        pkg = Path(self.edit_pkg.text()) if self.edit_pkg.text() else None
        ok_pkg = bool(pkg and (pkg / "__init__.py").is_file())
        self.lbl_pkg_status.setText(
            _status(ok_pkg, "Pacote válido." if ok_pkg else "Pacote não encontrado.")
        )
        tatu = Path(self.edit_tatu.text()) if self.edit_tatu.text() else None
        ok_tatu = bool(tatu and tatu.is_file() and os.access(tatu, os.X_OK))
        self.lbl_tatu_status.setText(
            _status(
                ok_tatu,
                "Binário executável." if ok_tatu else "Binário ausente ou sem permissão.",
            )
        )
        py = Path(self.edit_python.text()) if self.edit_python.text() else None
        ok_py = bool(py and py.is_file())
        self.lbl_python_status.setText(
            _status(ok_py, "Interpretador válido." if ok_py else "Interpretador ausente.")
        )

    def _collect_style(self) -> PlotStyle:
        return PlotStyle(
            dpi=int(self.spin_dpi.value()),
            font_family=self.combo_font_family.currentText().strip() or "DejaVu Sans",
            font_size=int(self.spin_font.value()),
            line_width=float(self.spin_lw.value()),
            grid=self.check_grid.isChecked(),
            grid_alpha=0.35,
            color_real=self.btn_color_real.text(),
            color_imag=self.btn_color_imag.text(),
            color_mag=self.btn_color_real.text(),
            color_phase=self.btn_color_imag.text(),
            color_rho_h=self.btn_color_rho_h.text(),
            color_rho_v=self.btn_color_rho_v.text(),
            color_numba=self.btn_color_numba.text(),
            color_fortran=self.btn_color_fortran.text(),
            color_layer_boundary=self.btn_color_layer.text(),
            axis_precision=int(self.spin_axis_prec.value()),
            show_layer_boundaries=self.check_layer_boundary.isChecked(),
            palette=self.combo_palette.currentText(),
            background=self.btn_color_bg.text(),
            tight_layout=True,
            use_latex=self.check_use_latex.isChecked(),
            use_mathtext=self.check_use_mathtext.isChecked(),
            legend_location=self.combo_legend_loc.currentText(),
            title_location=self.combo_title_loc.currentText(),
            minor_ticks=self.check_minor_ticks.isChecked(),
            spine_width=float(self.spin_spine_w.value()),
            line_style=self.combo_line_style.currentText(),
            marker_size=float(self.spin_marker_size.value()),
            marker_style=self.combo_marker_style.currentText(),
        )

    def _collect_paths(self) -> Dict[str, str]:
        return {
            "geosteering_ai": self.edit_pkg.text().strip(),
            "tatu_binary": self.edit_tatu.text().strip(),
            "python_binary": self.edit_python.text().strip(),
            "output_dir": self.edit_output.text().strip(),
        }

    def _on_save(self) -> None:
        paths = self._collect_paths()
        style = self._collect_style()
        save_paths(paths)
        save_plot_style(style)
        self._paths = paths
        self._style = style
        apply_style(style)
        self.paths_changed.emit(paths)
        self.style_changed.emit(style)
        QtWidgets.QMessageBox.information(
            self, "Preferências", "Preferências salvas com sucesso."
        )

    def _on_reset(self) -> None:
        self._style = PlotStyle()
        self.spin_dpi.setValue(self._style.dpi)
        self.combo_font_family.setCurrentText(self._style.font_family)
        self.spin_font.setValue(self._style.font_size)
        self.spin_lw.setValue(self._style.line_width)
        self.spin_spine_w.setValue(self._style.spine_width)
        self.spin_marker_size.setValue(self._style.marker_size)
        self.spin_axis_prec.setValue(self._style.axis_precision)
        self.check_grid.setChecked(self._style.grid)
        self.check_layer_boundary.setChecked(self._style.show_layer_boundaries)
        self.check_minor_ticks.setChecked(self._style.minor_ticks)
        self.check_use_latex.setChecked(self._style.use_latex)
        self.check_use_mathtext.setChecked(self._style.use_mathtext)
        self.combo_palette.setCurrentText(self._style.palette)
        self.combo_legend_loc.setCurrentText(self._style.legend_location)
        self.combo_title_loc.setCurrentText(self._style.title_location)
        self.combo_line_style.setCurrentText(self._style.line_style)
        self.combo_marker_style.setCurrentText(self._style.marker_style)


# ══════════════════════════════════════════════════════════════════════════
# Janela principal
# ══════════════════════════════════════════════════════════════════════════


class MainWindow(QtWidgets.QMainWindow):
    """Janela principal com QTabWidget no topo + gating por experimento."""

    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle(f"Simulation Manager — Geosteering AI v2.0 ({QT_BINDING})")
        self.setMinimumSize(1280, 820)

        self._paths = load_paths()
        self._plot_style = load_plot_style()
        apply_style(self._plot_style)
        self._experiment: Optional[ExperimentState] = None

        # Páginas
        self.page_params = ParametersPage()
        self.page_sim = SimulatorPage()
        self.page_bench = BenchmarkPage()
        self.page_results = ResultsPage(self._plot_style)
        self.page_prefs = PreferencesPage(self._paths, self._plot_style)

        # Welcome widget (mostrado enquanto _experiment is None)
        self.welcome = WelcomeWidget()
        self.welcome.request_new.connect(self._on_new_experiment)
        self.welcome.request_open.connect(self._on_open_experiment)

        # QStackedWidget: index 0 = welcome, index 1 = tabs
        self.stack = QtWidgets.QStackedWidget()
        self.stack.addWidget(self.welcome)

        self.tabs = QtWidgets.QTabWidget()
        self.tabs.addTab(self.page_params, "📐  Parâmetros")
        self.tabs.addTab(self.page_sim, "▶  Simulador")
        self.tabs.addTab(self.page_bench, "📊  Benchmark")
        self.tabs.addTab(self.page_results, "🖼  Resultados")
        self.tabs.addTab(self.page_prefs, "⚙  Preferências")
        self.stack.addWidget(self.tabs)

        self.setCentralWidget(self.stack)

        self._build_toolbar()

        # Status bar
        self.status = self.statusBar()
        self.lbl_status_exp = QtWidgets.QLabel("Sem experimento")
        self.lbl_status_throughput = QtWidgets.QLabel("Throughput: —")
        self.lbl_status_elapsed = QtWidgets.QLabel("Elapsed: —")
        self.lbl_status_backend = QtWidgets.QLabel(f"Binding: {QT_BINDING}")
        for lbl in (
            self.lbl_status_exp,
            self.lbl_status_throughput,
            self.lbl_status_elapsed,
            self.lbl_status_backend,
        ):
            lbl.setStyleSheet("padding:0 10px;")
        self.status.addPermanentWidget(self.lbl_status_exp)
        self.status.addPermanentWidget(self.lbl_status_throughput)
        self.status.addPermanentWidget(self.lbl_status_elapsed)
        self.status.addPermanentWidget(self.lbl_status_backend)
        self.status.showMessage("Crie ou abra um experimento para começar.")

        self._apply_paths(self._paths)

        self._sim_thread: Optional[SimulationThread] = None
        self._bench_thread: Optional[BenchmarkThread] = None

        self.page_sim.request_start.connect(self._start_simulation)
        self.page_sim.request_stop.connect(self._stop_simulation)
        self.page_bench.request_start.connect(self._start_benchmark)
        self.page_bench.request_stop.connect(self._stop_benchmark)
        self.page_prefs.paths_changed.connect(self._apply_paths)
        self.page_prefs.style_changed.connect(self._apply_style)

    def _build_toolbar(self) -> None:
        toolbar = QtWidgets.QToolBar("main")
        toolbar.setMovable(False)
        toolbar.setIconSize(QtCore.QSize(16, 16))
        QAction = getattr(QtGui, "QAction", None) or QtWidgets.QAction
        self.act_new = QAction("➕  Novo", self)
        self.act_new.triggered.connect(self._on_new_experiment)
        self.act_open = QAction("📂  Abrir…", self)
        self.act_open.triggered.connect(self._on_open_experiment)
        self.act_save = QAction("💾  Salvar", self)
        self.act_save.triggered.connect(self._on_save_experiment)
        self.act_save.setEnabled(False)
        self.act_save_as = QAction("💾  Salvar como…", self)
        self.act_save_as.triggered.connect(self._on_save_experiment_as)
        self.act_save_as.setEnabled(False)
        self.act_close = QAction("✕  Fechar experimento", self)
        self.act_close.triggered.connect(self._on_close_experiment)
        self.act_close.setEnabled(False)
        toolbar.addAction(self.act_new)
        toolbar.addAction(self.act_open)
        toolbar.addSeparator()
        toolbar.addAction(self.act_save)
        toolbar.addAction(self.act_save_as)
        toolbar.addSeparator()
        toolbar.addAction(self.act_close)
        self.addToolBar(toolbar)

    # ── Experimento ──────────────────────────────────────────────────────

    def _unlock_tabs(self, exp: ExperimentState) -> None:
        self._experiment = exp
        self.stack.setCurrentIndex(1)
        self.act_save.setEnabled(True)
        self.act_save_as.setEnabled(True)
        self.act_close.setEnabled(True)
        self.lbl_status_exp.setText(f"Exp: {exp.name}")
        self.status.showMessage(f"Experimento carregado: {exp.file_path}")
        self.setWindowTitle(f"Simulation Manager — {exp.name} ({QT_BINDING})")
        _push_recent(exp.file_path)

    def _on_new_experiment(self) -> None:
        dlg = NewExperimentDialog(self)
        if dlg.exec():
            exp = dlg.result_state()
            if exp is not None:
                # Estado inicial: coleta valores padrão de cada aba
                self._capture_parameters_into(exp)
                exp.save()
                self._unlock_tabs(exp)

    def _on_open_experiment(self) -> None:
        # Permitir clique em "Recentes" pela welcome
        preselected = getattr(self.welcome, "property_selected_path", None)
        if preselected:
            path = preselected
            self.welcome.property_selected_path = None
        else:
            path, _ = QtWidgets.QFileDialog.getOpenFileName(
                self,
                "Abrir experimento",
                str(Path.cwd()),
                "Experimento (*.exp.json);;JSON (*.json)",
            )
        if not path:
            return
        try:
            exp = ExperimentState.from_file(path)
        except Exception as e:
            QtWidgets.QMessageBox.critical(self, "Falha ao abrir", str(e))
            return
        self._restore_parameters_from(exp)
        self._unlock_tabs(exp)

    def _on_save_experiment(self) -> None:
        if self._experiment is None:
            return
        self._capture_parameters_into(self._experiment)
        try:
            self._experiment.save()
            self.status.showMessage(f"Salvo em {self._experiment.file_path}")
        except Exception as e:
            QtWidgets.QMessageBox.critical(self, "Falha ao salvar", str(e))

    def _on_save_experiment_as(self) -> None:
        if self._experiment is None:
            return
        path, _ = QtWidgets.QFileDialog.getSaveFileName(
            self,
            "Salvar experimento como",
            self._experiment.file_path or "experiment.exp.json",
            "Experimento (*.exp.json);;JSON (*.json)",
        )
        if not path:
            return
        self._capture_parameters_into(self._experiment)
        try:
            self._experiment.save(path)
            self.status.showMessage(f"Salvo em {path}")
            self.setWindowTitle(
                f"Simulation Manager — {self._experiment.name} ({QT_BINDING})"
            )
            _push_recent(path)
        except Exception as e:
            QtWidgets.QMessageBox.critical(self, "Falha ao salvar", str(e))

    def _on_close_experiment(self) -> None:
        reply = QtWidgets.QMessageBox.question(
            self,
            "Fechar experimento",
            "Deseja salvar alterações antes de fechar?",
            QtWidgets.QMessageBox.StandardButton.Yes
            | QtWidgets.QMessageBox.StandardButton.No
            | QtWidgets.QMessageBox.StandardButton.Cancel,
        )
        if reply == QtWidgets.QMessageBox.StandardButton.Cancel:
            return
        if reply == QtWidgets.QMessageBox.StandardButton.Yes:
            self._on_save_experiment()
        self._experiment = None
        self.stack.setCurrentIndex(0)
        self.act_save.setEnabled(False)
        self.act_save_as.setEnabled(False)
        self.act_close.setEnabled(False)
        self.lbl_status_exp.setText("Sem experimento")
        self.setWindowTitle(f"Simulation Manager — Geosteering AI v2.0 ({QT_BINDING})")

    def _capture_parameters_into(self, exp: ExperimentState) -> None:
        exp.parameters = {
            "parameters": self.page_params.to_dict(),
            "simulator": self.page_sim.to_dict(),
            "benchmark": self.page_bench.to_dict(),
        }
        if not exp.output_dir and self.page_sim.edit_output_dir.text():
            exp.output_dir = self.page_sim.edit_output_dir.text()

    def _restore_parameters_from(self, exp: ExperimentState) -> None:
        params = exp.parameters or {}
        self.page_params.from_dict(params.get("parameters", {}))
        self.page_sim.from_dict(params.get("simulator", {}))
        self.page_bench.from_dict(params.get("benchmark", {}))
        if exp.output_dir:
            self.page_sim.edit_output_dir.setText(exp.output_dir)

    # ── Paths / Style ─────────────────────────────────────────────────────

    def _apply_paths(self, paths: Dict[str, str]) -> None:
        self._paths = paths
        self.page_sim.set_fortran_path(paths.get("tatu_binary", ""))
        self.page_sim.set_python_path(paths.get("python_binary", ""))
        self.page_sim.set_output_dir(paths.get("output_dir", ""))
        pkg_path = paths.get("geosteering_ai", "")
        if pkg_path and os.path.isdir(pkg_path):
            parent = str(Path(pkg_path).parent)
            if parent not in sys.path:
                sys.path.insert(0, parent)

    def _apply_style(self, style: PlotStyle) -> None:
        self._plot_style = style
        self.page_results.set_style(style)

    def _fortran_binary(self) -> str:
        return self._paths.get("tatu_binary", "")

    # ── Simulação ─────────────────────────────────────────────────────────

    def _start_simulation(self) -> None:
        if self._sim_thread and self._sim_thread.isRunning():
            QtWidgets.QMessageBox.warning(
                self,
                "Simulação em curso",
                "Aguarde o término antes de iniciar outra.",
            )
            return
        try:
            params = self.page_params
            sim = self.page_sim
            freqs = params.collect_freqs() or [20000.0]
            trs = params.collect_trs() or [1.0]
            dips = params.collect_angles() or [0.0]
            import math

            cos_d = max(1e-6, math.cos(math.radians(abs(dips[0]))))
            n_pos = max(
                1,
                int(
                    math.ceil(params.spin_tj.value() / (params.spin_pmed.value() * cos_d))
                ),
            )
            positions_z = np.linspace(
                0.0, params.spin_tj.value(), n_pos, dtype=np.float64
            )

            gen_cfg = params.build_gen_config()
            n_models = int(params.spin_nmodels.value())
            sim.append_log(f"Gerando {n_models} modelos (generator={gen_cfg.generator})…")
            models = generate_models(gen_cfg, n_models=n_models, rng_seed=42)
            sim.append_log(f"  → {len(models)} perfis prontos.")

            output_dir = sim.edit_output_dir.text().strip() or str(
                Path.cwd() / "sm_output"
            )
            os.makedirs(output_dir, exist_ok=True)
            fortran_bin = self._fortran_binary()
            if sim.combo_backend.currentText() == "fortran" and not os.path.isfile(
                fortran_bin
            ):
                QtWidgets.QMessageBox.critical(
                    self,
                    "tatu.x não encontrado",
                    f"O binário Fortran não foi encontrado em {fortran_bin!r}.\n"
                    "Defina o caminho em Preferências.",
                )
                return

            save_flag = sim.check_save_artifacts.isChecked()
            req = SimRequest(
                frequencies_hz=freqs,
                tr_spacings_m=trs,
                dip_degs=dips,
                positions_z=positions_z,
                backend=sim.combo_backend.currentText(),
                n_workers=int(sim.spin_workers.value()),
                n_threads=int(sim.spin_threads.value()),
                hankel_filter=params.combo_filter.currentText(),
                h1=float(params.spin_h1.value()),
                tj=float(params.spin_tj.value()),
                p_med=float(params.spin_pmed.value()),
                fortran_binary=fortran_bin,
                save_raw=save_flag,
                output_dir=output_dir,
                output_filename="sim_output",
            )

            self._sim_thread = SimulationThread(req, models, parent=self)
            self._sim_thread.log.connect(sim.append_log)
            self._sim_thread.progress_update.connect(self._on_sim_progress)
            self._sim_thread.finished_all.connect(
                lambda d: self._on_sim_finished(d, req, models)
            )
            self._sim_thread.error.connect(self._on_sim_error)
            # Reabilita o Start QUANDO o thread terminar (qualquer desfecho),
            # garantindo que parar + iniciar de novo funcione sempre.
            self._sim_thread.finished.connect(lambda: sim.set_running(False))
            sim.set_running(True)
            sim.progress.setValue(0)
            sim.append_log("Iniciando simulação…")
            self._sim_thread.start()
        except Exception as exc:
            QtWidgets.QMessageBox.critical(self, "Erro", str(exc))
            self.page_sim.set_running(False)

    def _stop_simulation(self) -> None:
        if self._sim_thread and self._sim_thread.isRunning():
            self._sim_thread.request_stop()
            self.page_sim.append_log(
                "Solicitação de parada enviada (parada ocorrerá entre chunks)."
            )

    def _on_sim_progress(self, done: int, total: int, mod_h: float) -> None:
        pct = int(100.0 * done / max(total, 1))
        self.page_sim.progress.setValue(pct)
        self.page_sim.lbl_throughput.setText(
            f"Throughput: {format_float(mod_h, 0, thousands=True)} mod/h"
        )
        self.lbl_status_throughput.setText(
            f"Throughput: {format_float(mod_h, 0, thousands=True)} mod/h"
        )
        self.status.showMessage(
            f"{done}/{total} modelos · {format_float(mod_h, 0, thousands=True)} mod/h"
        )
        if done % 100 == 0 or done == total:
            self.page_sim.append_log(
                f"  Progresso: {done}/{total} modelos · "
                f"{format_float(mod_h, 0, thousands=True)} mod/h"
            )

    def _on_sim_finished(
        self,
        result: Dict[str, Any],
        req: "SimRequest",
        models: List[dict],
    ) -> None:
        self.page_sim.progress.setValue(100)
        elapsed = float(result.get("elapsed", 0.0))
        mod_h = float(result.get("throughput_mod_h", 0.0))
        self.page_sim.append_log(
            f"Simulação concluída em {format_float(elapsed, 1)}s — "
            f"{format_float(mod_h, 0, thousands=True)} mod/h"
        )
        self.lbl_status_elapsed.setText(f"Elapsed: {format_float(elapsed, 1)}s")
        try:
            if req.backend == "numba" and self.page_sim.check_save_artifacts.isChecked():
                H_stack = result.get("H_stack")
                z_obs = result.get("z_obs")
                if H_stack is not None and H_stack.size and z_obs is not None:
                    dat_path = os.path.join(req.output_dir, f"{req.output_filename}.dat")
                    write_dat_from_tensor(dat_path, H_stack, z_obs)
                    self.page_sim.append_log(f"  .dat salvo em {dat_path}")
                nmeds = compute_nmeds_per_angle(req.tj, req.p_med, req.dip_degs)
                out_path = os.path.join(req.output_dir, f"{req.output_filename}.out")
                write_out_file(
                    out_path,
                    n_dips=len(req.dip_degs),
                    n_freqs=len(req.frequencies_hz),
                    nmaxmodel=len(models),
                    angles=req.dip_degs,
                    freqs_hz=req.frequencies_hz,
                    nmeds_per_angle=nmeds,
                )
                self.page_sim.append_log(f"  .out salvo em {out_path}")
        except Exception as exc:
            self.page_sim.append_log(f"  [AVISO] Falha ao exportar artefatos: {exc}")

        plot_bundle = {
            "backend": req.backend,
            "H_stack": result.get("H_stack"),
            "z_obs": result.get("z_obs"),
            "freqs": req.frequencies_hz,
            "trs": req.tr_spacings_m,
            "dips": req.dip_degs,
            "model": models[0] if models else {},
        }
        self.page_results.set_current_simulation(plot_bundle, models=models)
        self.tabs.setCurrentWidget(self.page_results)

    def _on_sim_error(self, msg: str) -> None:
        self.page_sim.set_running(False)
        self.page_sim.append_log(f"[ERRO] {msg}")
        QtWidgets.QMessageBox.critical(self, "Erro na simulação", msg[:800])

    # ── Benchmark ─────────────────────────────────────────────────────────

    def _start_benchmark(self) -> None:
        if self._bench_thread and self._bench_thread.isRunning():
            QtWidgets.QMessageBox.warning(
                self,
                "Benchmark em curso",
                "Aguarde o término.",
            )
            return
        try:
            bt = self.page_bench
            params = self.page_params
            fortran_bin = self._fortran_binary()
            if bt.check_fortran.isChecked() and not os.path.isfile(fortran_bin):
                QtWidgets.QMessageBox.critical(
                    self,
                    "tatu.x não encontrado",
                    f"Binário Fortran não encontrado em {fortran_bin!r}.\n"
                    "Defina o caminho em Preferências.",
                )
                return
            output_dir = self.page_sim.edit_output_dir.text().strip() or str(
                Path.cwd() / "sm_output"
            )
            os.makedirs(output_dir, exist_ok=True)

            config_d_models = bt.selected_config_d_models()
            run_d = bt.check_cfg_d.isChecked() and len(config_d_models) > 0

            settings = BenchmarkSettings(
                run_config_a=bt.check_cfg_a.isChecked(),
                run_config_b=bt.check_cfg_b.isChecked(),
                run_config_c=bt.check_cfg_c.isChecked(),
                run_config_d=run_d,
                run_30k=bt.check_30k.isChecked(),
                models=bt.selected_models() or CANONICAL_BENCHMARK_MODELS,
                config_d_models=config_d_models,
                config_d_overrides=bt.config_d_overrides(),
                n_iter=int(bt.spin_n_iter.value()),
                fortran_subset=int(bt.spin_fort_subset.value()),
                n_workers_numba=int(bt.spin_workers_numba.value()),
                n_threads_numba=int(bt.spin_threads_numba.value()),
                n_workers_fortran=int(bt.spin_workers_fortran.value()),
                n_threads_fortran=int(bt.spin_threads_fortran.value()),
                fortran_binary=fortran_bin,
                run_numba=bt.check_numba.isChecked(),
                run_fortran=bt.check_fortran.isChecked(),
                hankel_filter=params.combo_filter.currentText(),
                h1=float(params.spin_h1.value()),
                tj=float(params.spin_tj.value()),
                p_med=float(params.spin_pmed.value()),
                output_dir=output_dir,
            )

            self._bench_thread = BenchmarkThread(settings, parent=self)
            self._bench_thread.log.connect(bt.append_log)
            self._bench_thread.progress.connect(self._on_bench_progress)
            self._bench_thread.finished_all.connect(self._on_bench_finished)
            self._bench_thread.error.connect(self._on_bench_error)
            self._bench_thread.finished.connect(lambda: bt.set_running(False))
            bt.set_running(True)
            bt.progress.setValue(0)
            bt.lbl_current.setText("iniciando…")
            self._bench_thread.start()
        except Exception as exc:
            QtWidgets.QMessageBox.critical(self, "Erro", str(exc))
            self.page_bench.set_running(False)

    def _stop_benchmark(self) -> None:
        if self._bench_thread and self._bench_thread.isRunning():
            self.page_bench.append_log(
                "Parada solicitada — aguardando célula atual terminar…"
            )

    def _on_bench_progress(self, i: int, n: int, label: str) -> None:
        pct = int(100.0 * i / max(n, 1))
        self.page_bench.progress.setValue(pct)
        self.page_bench.lbl_current.setText(label)
        self.status.showMessage(f"Benchmark {i}/{n} — {label}")

    def _on_bench_finished(self, records: list, plot_data: dict) -> None:
        self.page_bench.progress.setValue(100)
        self.page_bench.append_log(f"Benchmark concluído — {len(records)} células.")
        self.page_bench.populate_table(records)
        self.page_results.set_benchmark_plot_data(plot_data)

    def _on_bench_error(self, msg: str) -> None:
        self.page_bench.set_running(False)
        self.page_bench.append_log(f"[ERRO] {msg}")
        QtWidgets.QMessageBox.critical(self, "Erro no benchmark", msg[:800])


# ══════════════════════════════════════════════════════════════════════════
# Entry point
# ══════════════════════════════════════════════════════════════════════════


def main() -> int:
    check_qt_available()
    import multiprocessing

    try:
        multiprocessing.set_start_method("spawn", force=False)
    except RuntimeError:
        pass

    if QtCore is not None:
        enforce_c_locale(None)

    app = QtWidgets.QApplication(sys.argv)
    app.setApplicationName("Simulation Manager")
    app.setOrganizationName("Geosteering AI")
    app.setStyleSheet(APP_STYLESHEET)
    enforce_c_locale(app)

    window = MainWindow()
    window.showMaximized()
    return app.exec() if hasattr(app, "exec") else app.exec_()


if __name__ == "__main__":
    sys.exit(main())
